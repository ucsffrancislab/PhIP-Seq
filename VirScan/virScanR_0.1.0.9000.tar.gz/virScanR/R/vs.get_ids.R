#' Function to grab ids from in a master library ID reference database.
#'
#' Requires a data frame with a master id column and then every other column
#' represents a library. Within each library column, the value will be 1 if the
#' id (in the master id column) belongs in that library and zero otherwise.
#'
#' @param ids_DB_path,ids_DB_table Path to the master library reference database
#'   and, the specific table inside the library, if applicable.
#'
#' @param ids_DB_idColName The name of the column with the ids in it. Default is
#'   "id".
#' @param ids_DB_libColName The name of the library requesting the ids for. Tip,
#'   use \code{\link{mmR::mm.listTableCols}} to see the availabale options.
#'
#' @param returnAs Should the ids be returned as a \code{"vector"} (DEFAULT), a
#'   \code{"data.table","data.frame"} or as a tibble:
#'   \code{"tibble","tbl_df","tbl","data_frame"}
#'
#' @return Returns a vector or data table of some sort (see \code{returnAs})
#'   containing the ids for the requested library.
#'
#' @export
#'
#'
vs.get_ids <- function(ids_DB_path,
                       ids_DB_table = NULL,
                       ids_DB_idColName = "id",
                       ids_DB_libColName = NULL,
                       returnAs = "vector"){
  idsToGet <-
      mmR::mm.fastread(ids_DB_path,
                     ids_DB_table,
                     returnAs = "data_frame")


  toGet <- ids_DB_libColName

  idColIndex <- which(names(idsToGet) == ids_DB_idColName)

  colIndex <- which(names(idsToGet) %in% toGet)
  rowIndex = list()
  for(i in 1:length(colIndex)){
    rowIndex[[i]] <- data.frame(rIndex = which(idsToGet[,colIndex[i]] == 1))
  }

  if(i ==1){
    rowIndex <- rowIndex[[1]]$rIndex
  } else {
    rowIndex <- data.frame(data.table::rbindlist(rowIndex))$rIndex
  }


  idsToGet <- idsToGet[rowIndex,idColIndex]

  if(returnAs == "vector"){

    print(sprintf("returning %s IDs as a vector from libraries: %s",nrow(idsToGet),paste(ids_DB_libColName,collapse = ", ")))
    return(data.frame(idsToGet)[,1])
  } else if(returnAs == "data.table"){

    print(sprintf("returning %s IDs as a data.table() from libraries: %s",nrow(idsToGet),paste(ids_DB_libColName,collapse = ", ")))
    return(data.table::data.table(idsToGet))
  } else if (returnAs == "data.frame"){

    print(sprintf("returning %s IDs as a data.frame() from libraries: %s",nrow(idsToGet),paste(ids_DB_libColName,collapse = ", ")))
    return(data.frame(idsToGet))
  } else if(returnAs %in% c("tibble","tbl","tbl_df","data_frame")){

    print(sprintf("returning %s IDs as a tbl_df() from libraries: %s",nrow(idsToGet),paste(ids_DB_libColName,collapse = ", ")))
    return(dplyr::tbl_df(idsToGet))
  } else {

    print(sprintf("returning %s IDs as a vector from libraries: %s",nrow(idsToGet),paste(ids_DB_libColName,collapse = ", ")))
    return(data.frame(idsToGet)[,1])
  }}





