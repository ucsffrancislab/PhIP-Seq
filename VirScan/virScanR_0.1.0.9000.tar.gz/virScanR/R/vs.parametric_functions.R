
#' Zero inflated Negative Binomial
#' @export
vs.pzinegbin <- function (q,
                          size,
                          munb = NULL,
                          pstr0 = 0,
                          log.p = FALSE,
                          lower.tail = FALSE) {



  prob <- size/(size + munb)

  LLL <- max(length(pstr0), length(size), length(prob), length(q))
  if (length(q) != LLL)
    q <- rep_len(q, LLL)
  if (length(size) != LLL)
    size <- rep_len(size, LLL)
  if (length(prob) != LLL)
    prob <- rep_len(prob, LLL)
  if (length(pstr0) != LLL)
    pstr0 <- rep_len(pstr0, LLL)

  #DO this to help keep some of them that go to 1
  ans_log <- pnbinom(q = q, size = size, prob = prob,log.p = TRUE, lower.tail = lower.tail)

  if(lower.tail == TRUE) {storeAsLogIndex <- which(exp(ans_log)==1)}
  if(lower.tail == FALSE) {storeAsLogIndex <- which(1-exp(ans_log)==1)}

  ans <- exp(ans_log)

  if(lower.tail == TRUE){
    ans <- ifelse(q < 0, 0, pstr0 + (1 - pstr0) * ans)
  } else {
    ans <- 1-ifelse(q < 0, 0, (1-pstr0) + pstr0 * (1-ans))
  }

  prob0 <- prob^size
  deflat.limit <- -prob0/(1 - prob0)
  ans[pstr0 < deflat.limit] <- NaN
  ans[pstr0 > 1] <- NaN

  toReturn <- log(ans)

  if(length(storeAsLogIndex)>0){
    toReturn[storeAsLogIndex] <- ans_log[storeAsLogIndex]
  }

  if(log.p == TRUE){
    return(toReturn)
  } else {
    return(exp(toReturn))
  }
}




