#------------------------------------------------------------------------------#
#MAJOR FUNCTION TO BRING ALL OF THESE TOGETHER IN ONE
#------------------------------------------------------------------------------#
#' Primary function to collect and/or calculate all of the VirScan data.
#'
#' See \code{\link{vs.setParam_collect_calc_VSData}} for the many options that
#' are provided.
#'
#' Utilizes the following functions: \code{\link{vs.pull}},
#' \code{\link{vs.gatherReplicateNamesDF}}, \code{\link{vs.makeGroups}},
#' \code{\link{vs.calc_enrichment_chunks}}, \code{\link{vs.splitReplciateData}},
#' \code{\link{vs.makeBinomP}}, \code{\link{vs.getHits}},
#' \code{\link{vs.combineHits}}. As well as some other internal functions.
#'
#' @param paramsList a list of arguments derived from
#'   \code{\link{vs.setParam_collect_calc_VSData}}
#'
#' @return Returns a list with potentially many data sets, including the counts,
#'   pVals, enrichments, fold-enrichments, etc etc. See
#'   \code{\link{vs.setParam_collect_calc_VSData}} for the many options of what
#'   to keep or not
#'
#' @importFrom magrittr %>%
#' @export
vs.collect_calc_VSData <- function(paramsList, ...){


  #Declare all of the parameters up from
  sampsDF = paramsList$sampsDF
  path = paramsList$path

  useReplicateFullName = paramsList$useReplicateFullName
  counts_table = paramsList$counts_table

  pValsDB_path = paramsList$pValsDB_path
  pVals_table = paramsList$pVals_table

  inputLibDB_path = paramsList$inputLib_path
  inputLib_table = paramsList$inputLib_table
  inputLib_colName = paramsList$inputLib_colName
  newInputLibDF = paramsList$newInputLibDF

  minCountsForFailure = paramsList$minCountsForFailure
  removeFailed = paramsList$removeFailed
  pThresh = paramsList$pThresh
  pThreshEnrich = paramsList$pThreshEnrich
  returnSplitCounts = paramsList$returnSplitCounts
  returnSplitPVals = paramsList$returnSplitPVals
  returnSplitBinomPVals = paramsList$returnSplitBinomPVals
  returnHits = paramsList$returnHits
  returnSplitHits = paramsList$returnSplitHits
  returnSplitEnrichHits = paramsList$returnSplitEnrichHits
  calculateEnrichments = paramsList$calculateEnrichments
  calculateEnrichmentByChunks = paramsList$calculateEnrichmentByChunks
  calculateEnrichmentsStaggered = paramsList$calculateEnrichmentsStaggered
  combineStaggeredHits = paramsList$combineStaggeredHits
  removeUncombinedHits = paramsList$removeUncombinedHits
  returnGroupedIDs = paramsList$returnGroupedIDs
  propExtremesToRemove = paramsList$propExtremesToRemove
  convertZeroInput_To = paramsList$convertZeroInput_To
  convertZeroCounts_To = paramsList$convertZeroCounts_To
  returnSplitEnrichments = paramsList$returnSplitEnrichments
  returnSplitEnrichmentsLn = paramsList$returnSplitEnrichmentsLn
  returnSplitEnrichPVal = paramsList$returnSplitEnrichPVal
  returnEnrichHits = paramsList$returnEnrichHits
  groupSize = paramsList$groupSize
  returnIDsWithHits = paramsList$returnIDsWithHits
  returnBackgroundCounts = paramsList$returnBackgroundCounts
  pThreshForBackground = paramsList$pThreshForBackground
  returnCountsAll = paramsList$returnCountsAll
  returnPValsAll = paramsList$returnPValsAll
  returnEnrichmentsAll = paramsList$returnEnrichmentsAll
  returnEnrichmentsLnAll = paramsList$returnEnrichmentsLnAll
  returnEnrichMetrics = paramsList$returnEnrichMetrics
  returnBinomPValsAll = paramsList$returnBinomPValsAll
  returnEnrichPValAll = paramsList$returnEnrichPValAll
  returnEnrichHitsAll = paramsList$returnEnrichHitsAll
  returnCountsNonHitsZero = paramsList$returnCountsNonHitsZero
  combineConservatively = paramsList$combineConservatively
  paramsToReturn <- paramsList


  counts <- vs.pull(path = path,
                                    table = counts_table,
                                    sampsDF = sampsDF,
                                    columns = NULL,
                                    allRows = TRUE,
                                    includeInputCounts = TRUE,
                                    inputLibDB_path = inputLibDB_path, #Need not be entered
                                    inputLib_table = inputLib_table,
                                    inputLib_colName = inputLib_colName,
                                    newInputLibDF = newInputLibDF,
                                    returnColsNotAvailable = TRUE,
                                    keepInputLibNameIntact = FALSE,
                                    convert_NAs_To = 0,
                                    type = NULL)

  countsNotAvailable = counts$columns_not_available
  #countsNotAvailable <- sampsDF$full_name[which(!sampsDF$full_name %in% names(counts))]

  counts = counts$table

  sampsDF_original <- sampsDF$full_name
  sampsDF <- vs.removeColsNotInVirScanFromSampsDF.int(sampsDF, names(counts))

  print("obtained counts")
  if(length(countsNotAvailable)>0){
    print(paste0("WARNING: Count data not available for:"))
    print(countsNotAvailable)
  }
  print(
    paste0(
      100 * (1-length(countsNotAvailable) / length(sampsDF_original)),
      " % of counts samples available"))


  if(is.null(pValsDB_path)){
    pValsDB_path = path
  }

  #Check to see if there are any PVals in the dataset.
  if(!is.null(pVals_table)){

          allPValFullNames <-
            mmR::mm.listTableCols(path = path,
                                  table = pVals_table)


          p_Available <-
            sampsDF %>%
            dplyr::filter(full_name %in% allPValFullNames) %>%
            dplyr::select(full_name)

          if(nrow(p_Available)>0){
            pVals <- vs.pull(path = pValsDB_path,
                                             table = pVals_table,
                                             sampsDF = sampsDF,
                                             columns = NULL,
                                             ids = counts$id,
                                             includeInputCounts = FALSE,
                                             returnColsNotAvailable = TRUE,
                                             convert_NAs_To = 1,
                                             type = NULL)

            pValsNotAvailable <- pVals$columns_not_available
            pVals <- pVals$table

          } else {
            pVals <- counts %>% dplyr::select(id)
            pValsNotAvailable = sampsDF$full_name
          }
  } else { #if pVals_table is NULL.
    pVals <- data.frame(id = counts[,"id"])
    pValsNotAvailable = sampsDF$full_name
  }

  print("obtained PValues")

  if(length(pValsNotAvailable)>0){

    print(paste0("P-Values not not calculated for: "))
    print(pValsNotAvailable)
    print("Setting these samples to P = 1")

    pVals <- vs.appendDataCols.int(data = pVals,
                                   missingNames = pValsNotAvailable,
                                   valueToInsert = 1)
  }


  

  sameColsRows <- vs.checkSameSamples(pVals = pVals, counts = counts[,-2])


  rep12 = NULL
  failed = NULL
  countsReplicateSplit = NULL
  pValsReplicateSplit = NULL
  binomPVals = NULL
  hits = NULL
  idsWHits = NULL
  countsNonHitsZero = NULL
  backgroundCountDF = NULL

  enrichmentsAll = enrichmentsAll2 = NULL
  pValEnrichmentsAll = pValEnrichmentsAll2 = NULL
  enrichSplitPVal = enrichSplitPVal2 = NULL
  enrichHits = enrichHits2 = NULL
  enrichHitsSplit = enrichHitsSplit2 = NULL
  groupedIDs = groupedIDs2 = NULL


  #A data frame with all of the enrichments
  enrichments = enrichments2 = NULL

  #the above, but split into a list of 2 data frames
  # one from the first rep, one for the second replicate
  enrichSplit = enrichSplit2 = NULL

  #Every Sample
  enrichHitsAll = enrichHitsAll2 = NULL
  #Just first replicate: 1 if both reps 1; 0 if 0 or 1 reps 1
  enrichHits = enrichHits2 = NULL


  #A dataframe with normalizer information.
  enrichNormalizer = enrichNormalizer2 = NULL

  #list with all the metrics for each individual
  enrichMetrics = enrichMetrics2 = NULL

  #ln_fold_enrichments
  enrichLn = enrichLn2 = NULL
  enrichSplitLn = enrichSplitLn2 = NULL

  #p-value for the ln_fold_enrichments
  enrichProb = enrichProb2 = NULL
  enrichProbSplit = enrichProbSplit2 = NULL

  lnEnrichmentsAll = lnEnrichmentsAll2 = NULL


  if( ! identical( c(sameColsRows[1,1],sameColsRows[1,2]),c(TRUE,TRUE))){
    stop(print("STOP! COLS AND ROWS NOT SAME IN COUNTS AND PVALS"))
  }

  #Combine rep1 and rep2 names and remove failed runs
  rep12 <- vs.gatherReplicateNames(sampsDF,
                                   useReplicateFullName = TRUE)

  #Get failed runs
  failed <- vs.getFailedRunNames(counts = counts,
                                 minCountsForFailure = minCountsForFailure,
                                 replicateNamesDF = rep12)
  #Remove failed runs
  if(removeFailed == TRUE){
    rep12 <-
      vs.rmFailuresFromReplicateNamesDF(replicateNamesDF = rep12,
                                        failedDF = failed)

    toRemoveCounts <- which(names(counts) %in% failed$full_name)
    if(length(toRemoveCounts)>0){
      counts <- counts[,-toRemoveCounts]
    }

    toRemoveP <- which(names(pVals) %in% failed$full_name)
    if(length(toRemoveP)>0){
      pVals <- pVals[,-toRemoveP]
    }
  }

  #Calculate Enrichments?
  if(calculateEnrichments == TRUE){

    if(calculateEnrichmentByChunks == FALSE){
      groupSize = nrow(counts)
      print("Calculating enrichments without grouping by input")
    } else {
      print(paste("Calculating Enrichments by Chunks of ",groupSize))
    }

    #Creating grouping of the IDs...
    #can also do this directly inside vs.calc_enrichment_chunks
    groupedIDs <- vs.makeGroups(dataToGroup = counts,
                                groupSize = groupSize,
                                idCol = "id",
                                groupingCol = "input",
                                staggerChunk = FALSE,
                                returnData = FALSE,
                                returnAs = "tibble")

    enrichments <-
      vs.calc_enrichment_chunks(
        countData = counts,
        groupedIDs = groupedIDs,
        groupSize = NULL,
        propExtremesToRemove = propExtremesToRemove,
        convertZeroInput_To = convertZeroInput_To,
        convertZeroCounts_To = convertZeroCounts_To,
        staggerChunk = FALSE)


    #Should the groups be staggered to calculate enrichments?
    if(calculateEnrichmentsStaggered == TRUE & calculateEnrichmentByChunks == TRUE){

      print("Calculating Second Stagger Enrichments")

      #Creating staggered grouping of the IDs...
      #can also do this directly inside vs.calc_enrichment_chunks
      groupedIDs2 <- vs.makeGroups(dataToGroup = counts,
                                   groupSize = groupSize,
                                   idCol = "id",
                                   groupingCol = "input",
                                   staggerChunk = TRUE,
                                   returnData = FALSE,
                                   returnAs = "tibble")


      enrichments2 <-
        vs.calc_enrichment_chunks(
          countData = counts,
          groupedIDs = groupedIDs2,
          groupSize = groupSize,
          propExtremesToRemove = propExtremesToRemove,
          convertZeroInput_To = convertZeroInput_To,
          convertZeroCounts_To = convertZeroCounts_To,
          staggerChunk = TRUE)

    } #End Calculate Enrchicments Staggerd


    #Fold Enrichments
    #Split the enrichments if requested by user
    enrichSplit = NULL
    if(returnSplitEnrichments == TRUE){
      enrichSplit <- vs.splitReplicateData(table = enrichments$enriched,
                                           nonSampleColsNames = c("id","input"),
                                           replicateNamesDF = rep12)
    }

    #Now that it's split, tidy up and remove this if not requested by user
    enrichmentsAll = NULL
    if(returnEnrichmentsAll == FALSE){
      enrichments$enriched = NULL
    } else {
      enrichmentsAll <- enrichments$enriched
      enrichments$enriched = NULL
    }

    #Natural Log of Enrichments
    #Split LN enrichments if requested by user
    enrichSplitLn = NULL
    if(returnSplitEnrichmentsLn == TRUE){
      enrichSplitLn <- vs.splitReplicateData(table = enrichments$lnEnriched,
                                             nonSampleColsNames = c("id","input"),
                                             replicateNamesDF = rep12)
    }

    #Now that it's split, tidy up and remove this if not requested by user
    lnEnrichmentsAll = NULL
    if(returnEnrichmentsLnAll == FALSE){
      enrichments$lnEnriched = NULL
    } else {
      lnEnrichmentsAll <- enrichments$lnEnriched
      enrichments$lnEnriched = NULL
    }

    #P-value of enrichments
    #Split LN enrichments if requested by user
    enrichSplitPVal = NULL
    if(returnSplitEnrichPVal == TRUE){
      enrichSplitPVal <- vs.splitReplicateData(table = enrichments$probEnriched,
                                               nonSampleColsNames = c("id","input"),
                                             replicateNamesDF = rep12)
    }


    #Hits based on enrichments
    if(returnEnrichHits == TRUE | returnSplitEnrichHits == TRUE){
      enrichHitsAll <- vs.makeBinomP(pVals = enrichments$probEnriched,
                                     pThresh = pThreshEnrich,
                                     greaterThan = FALSE,
                                     nonSampleCols = c("id","input"))

      enrichHits <- vs.getHits(pVals = enrichHitsAll,
                               replicateNamesDF = rep12,
                               pThresh = pThreshEnrich,
                               alreadyBinomial = TRUE,
                               combineConservatively = combineConservatively,
                               greaterThan = FALSE,
                               nonSampleCols = c("id","input"))

      if(returnSplitEnrichHits == TRUE){
        enrichHitsSplit <- vs.splitReplicateData(table = enrichHitsAll,
                                                 replicateNamesDF = rep12,
                                                 nonSampleColsNames = c("id","input"))
      } else {
        enrichHitsSplit = NULL
      }

      if(returnEnrichHitsAll == FALSE){
        enrichHitsAll = NULL
      }

      if(returnEnrichHits == FALSE){
        enrichHits = NULL
      }

    }

    #Now that it's split, tidy up and remove this if not requested by user
    pValEnrichmentsAll = NULL
    if(returnEnrichPValAll == FALSE){
      enrichments$probEnriched = NULL
    } else {
      pValEnrichmentsAll = enrichments$probEnriched
      enrichments$probEnriched = NULL
    }

    groupedIDs = NULL
    if(returnGroupedIDs == TRUE){
      groupedIDs = enrichments$groupedIDs
    }
    enrichments$groupedIDs = NULL

    enrichMetrics = NULL
    if(returnEnrichMetrics == TRUE){
      enrichMetrics <- enrichments$normalizer
    }
    enrichments$normalizers = NULL

    #Do same but for staggered chunks
    if(calculateEnrichmentsStaggered == TRUE & calculateEnrichmentByChunks == TRUE){
      #Fold Enrichments
      #Split the enrichments if requested by user
      enrichSplit2 = NULL
      if(returnSplitEnrichments == TRUE){
        enrichSplit2 <- vs.splitReplicateData(table = enrichments2$enriched,
                                              nonSampleColsNames = c("id","input"),
                                             replicateNamesDF = rep12)
      }

      #Now that it's split, tidy up and remove this if not requested by user
      enrichmentsAll2 = NULL
      if(returnEnrichmentsAll == FALSE){
        enrichments2$enriched = NULL
      } else {
        enrichmentsAll2 <- enrichments2$enriched
        enrichments2$enriched = NULL
      }

      #Natural Log of Enrichments
      #Split LN enrichments if requested by user
      enrichSplitLn2 = NULL
      if(returnSplitEnrichmentsLn == TRUE){
        enrichSplitLn2 <- vs.splitReplicateData(table = enrichments2$lnEnriched,
                                                nonSampleColsNames = c("id","input"),
                                               replicateNamesDF = rep12)
      }

      #Now that it's split, tidy up and remove this if not requested by user
      lnEnrichmentsAll2 = NULL
      if(returnEnrichmentsLnAll == FALSE){
        enrichments2$lnEnriched = NULL
      } else {
        lnEnrichmentsAll2 <- enrichments2$lnEnriched
        enrichments2$lnEnriched = NULL
      }

      #P-value of enrichments
      #Split LN enrichments if requested by user
      enrichSplitPVal2 = NULL
      if(returnSplitEnrichPVal == TRUE){
        enrichSplitPVal2 <- vs.splitReplicateData(table = enrichments2$probEnriched,
                                                  nonSampleColsNames = c("id","input"),
                                                 replicateNamesDF = rep12)
      }

      #Hits based on enrichments
      if(returnEnrichHits == TRUE | returnSplitEnrichHits == TRUE){
        enrichHitsAll2 <- vs.makeBinomP(pVals = enrichments2$probEnriched,
                                        pThresh = pThreshEnrich,
                                        greaterThan = FALSE,
                                        nonSampleCols = c("id","input"))

        enrichHits2 <- vs.getHits(pVals = enrichHitsAll2,
                                  replicateNamesDF = rep12,
                                  pThresh = pThreshEnrich,
                                  alreadyBinomial = TRUE,
                                  greaterThan = FALSE,
                                  nonSampleCols = c("id","input"))

        if(returnSplitEnrichHits == TRUE){
          enrichHitsSplit2 <- vs.splitReplicateData(table = enrichHitsAll2,
                                                    replicateNamesDF = rep12,
                                                    nonSampleColsNames = c("id","input"))
        } else {
          enrichHitsSplit2 = NULL
        }

        if(returnEnrichHitsAll == FALSE){
          enrichHitsAll2 = NULL
        }

        if(returnEnrichHits == FALSE){
          enrichHits2 = NULL
        }

      }

      #Now that it's split, tidy up and remove this if not requested by user
      pValEnrichmentsAll2 = NULL
      if(returnEnrichPValAll == FALSE){
        enrichments2$probEnriched = NULL
      } else {
        pValEnrichmentsAll2 = enrichments2$probEnriched
        enrichments2$probEnriched = NULL
      }


      groupedIDs2 = NULL
      if(returnGroupedIDs == TRUE){
        groupedIDs2 = enrichments2$groupedIDs
      }
      enrichments2$groupedIDs = NULL

      enrichMetrics2 = NULL
      if(returnEnrichMetrics == TRUE){
        enrichMetrics2 <- enrichments2$normalizer
      }
      enrichments2$normalizer = NULL


    } #Finish staggered bit

    ############################
    #NOTE NOTE NOTE NOTE
    #combineStaggeredHits = TRUE
    #combineConservatively = TRUE
    #removeUncombinedHits = TRUE
    if(calculateEnrichmentsStaggered == TRUE &
       calculateEnrichmentByChunks == TRUE &
       returnEnrichHits == TRUE &
       combineStaggeredHits == TRUE) {


      if(removeUncombinedHits == FALSE){
        enrichHits1 <- enrichHits
      }
      namesHits <- names(enrichHits)

      enrichHits <- vs.combineHits(hits1 = enrichHits,
                                   hits2 = enrichHits2)

      try(names(enrichHits) <- namesHits)

      if(removeUncombinedHits == TRUE){
        enrichHits2 = NULL
      }

    }
    ############################ End Combining enrich hits staggered


  } #End calculating enrichment stuff


  #break into list of 2: replicates 1 and replicates 2
  countsReplicateSplit = NULL
  if(returnSplitCounts == TRUE){
    countsReplicateSplit <- vs.splitReplicateData(counts = counts,
                                                  replicateNamesDF = rep12)
  }

  pValsReplicateSplit = NULL
  if(returnSplitPVals == TRUE){
    pValsReplicateSplit <- vs.splitReplicateData(pVals = pVals,
                                                 replicateNamesDF = rep12)
  }

  binomPVals = NULL
  if(returnBinomPValsAll == TRUE){
    binomPVals <- vs.makeBinomP(pVals = pVals,
                                pThresh = pThresh,
                                greaterThan = TRUE,
                                nonSampleCols = c("id"))
  }

  pValsBinomSplit = NULL
  if(returnSplitBinomPVals == TRUE){
    pValsBinomSplit <- vs.splitReplicateData(pVals = binomPVals,
                          replicateNamesDF = rep12)
  }


  hits = NULL
  if(returnHits == TRUE){
    if(returnBinomPValsAll == TRUE){ #utilize binomPVals already made
      hits <- vs.getHits(pVals = binomPVals,
                         pThresh = pThresh,
                         greaterThan = TRUE,
                         nonSampleCols = c("id"),
                         alreadyBinomial = TRUE,
                         replicateNamesDF = rep12)
    } else {
      hits <- vs.getHits(pVals = pVals,
                         pThresh = pThresh,
                         greaterThan = TRUE,
                         nonSampleCols = c("id"),
                         alreadyBinomial = FALSE,
                         replicateNamesDF = rep12)
    }
  }

  if(returnCountsAll == FALSE){counts = NULL}
  if(returnPValsAll  == FALSE){pVals = NULL}
  if(returnEnrichmentsAll  == FALSE){enrichmentsAll = enrichmentsAll2 = NULL}
  if(returnEnrichHitsAll  == FALSE){ enrichHitsAll = enrichHitsAll2 = NULL}
  if(returnEnrichHits == FALSE){enrichHits = enrichHits2 = NULL}
  if(returnEnrichMetrics == FALSE){enrichMetrics = enrichMetrics2 = NULL}




  toReturn <-
    list(counts = counts,
         countsSplit = countsReplicateSplit,

         pVals = pVals,
         pValsSplit = pValsReplicateSplit,

         pValsBinom = binomPVals,
         pValsBinomSplit = pValsBinomSplit,

         enrichments = enrichmentsAll,
         enrichments2 = enrichmentsAll2,

         lnEnrichments = lnEnrichmentsAll,
         lnEnrichments2 = lnEnrichmentsAll2,

         pValEnrichments = pValEnrichmentsAll,
         pValEnrichments2 = pValEnrichmentsAll2,

         enrichSplit = enrichSplit,
         enrichSplit2 = enrichSplit2,

         enrichSplitLn = enrichSplitLn,
         enrichSplitLn2 = enrichSplitLn2,

         enrichSplitPVal = enrichSplitPVal,
         enrichSplitPVal2 = enrichSplitPVal2,

         enrichHits = enrichHits,
         enrichHits2 = enrichHits2,

         enrichHitsAll = enrichHitsAll,
         enrichHitsAll2 = enrichHitsAll2,

         enrichHitsSplit = enrichHitsSplit,
         enrichHitsSplit2 = enrichHitsSplit2,

         enrichMetrics = enrichMetrics,
         enrichMetrics2 = enrichMetrics2,

         groupedIDs = groupedIDs,
         groupedIDs2 = groupedIDs2,

         hits = hits,

         replicatesDF = rep12,
         failedDF = failed,

         countsNotAvailable = countsNotAvailable,
         pValsNotAvailable = pValsNotAvailable,

         fxn_inputs = paramsToReturn

    )
  j = 0
  for(i in 1:length(toReturn)){
    j = j+1
    if(is.null(toReturn[[j]])){
      toReturn[[j]] = NULL
      j = j-1
    }
  }

  #data <- toReturn

  return(toReturn)
}
