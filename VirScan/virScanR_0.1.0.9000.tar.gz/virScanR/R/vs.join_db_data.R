#' A quick function to map some data to data not yet read in.
#'
#' @param data Some data - must have an "id" column to do the mapping
#'
#' @param path The path to the database Could be a "sqlite" data base or csv
#'   or xls or xlsx.
#'
#' @param table The name of the table inside the SQL database to join on or,
#'   alternatively, the worksheet name, or position, if working in xls or xlsx
#'
#' @param data2 If the second data set is already in R, you can just supply it
#'   here as a variable name. This should remain NULL if reading from outside R.
#'
#' @param data2Cols Which columns to return from the second data source when
#'   joining
#'
#' @param idCols Which is/are the mapping variable. Defaults to "id"
#' @param header Should the first row be considered the variable name (TRUE)
#'
#' @param type What is the type of the data base that the data to join on.
#'   Examples include: "SQLite", "xls","xlsx",".csv",".gz"
#'
#'
#' @importFrom magrittr %>%
#'
#' @examples
#' data <- data.frame(id = 1:10, y = 1:10)
#' path <- './../../../00 labAndSampKeys/SQLdatabases/virScanData.sqlite'
#' path1 <- "./../../../03.2 measles de Swart/virScan/Results/exploring/Lib1Samp1.xlsx"
#' table = "meta"
#' data2Cols  = c("id","Species")
#' idCols = "id"
#' type = "SQLite"
#'
#'
#' vs.join_db_data(data = data,
#'     path = path,
#'     table = "meta",
#'     data2Cols = c("id","Species"),
#'     idCols = "id",
#'     header = TRUE,
#'     type = "SQLite")
#'
#' @export
vs.join_db_data <- function(data,
                            path = NULL,
                            table = "meta",
                            data2 = NULL,
                            data2Cols = c("id","Species"),
                            idCols = "id",
                            header = TRUE,
                            type = NULL){

  db = NULL
  if(!is.null(data2)){
    data2 = data2
  } else if(!file.exists(path)) {

    stop("No File Exists at Path Provided.
         Input data to join directly using data2
         or correct the path to the database")

  } else if(virScanRSQL::sql.isSQLite(path)){

    db = virScanRSQL::sql.connect(path)
    data2 = virScanRSQL::sql.connectTable(db, table)

  } else if(type %in% c("xlsx","xls", "csv","gz") |
            (mmR::mm.stringEnd(path,3) %in%
             c("xls","lsx", "csv",".gz"))){

    data2 <- mmR::mm.fastread(path = path,
                              xl_sheet = table,
                              header = header)
  } else {
    stop("File to join was not properly read in.")
  }



  return(
    data %>%
      left_join(
        data2 %>%
          select(c(idCols,data2Cols)) %>%

          {if (!is.null(db)) collect(.) else .} %>%

          tbl_df(),
        by = idCols))

  if(type == "SQLite"){
    virScanRSQL::sql.disconnect(db)
  }
}




