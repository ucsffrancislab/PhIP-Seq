#------------------------------------------------------------------------------#
#------------------------------------------------------------------------------#
#' Function to set up the parameters to feed to \code{vs.makeSampsDF}
#'
#' Reads the sample meta data sheet and filters for the desired criteria.
#' The sample meta data sheet must have at minimum a \code{'samplesKey'} and a
#' \code{'virScanKey'} sheet with a column called \code{'unique_sample_id'} that links the
#' samples in samplesKey with the virScan runs in virScankey.
#'
#' Additionally, the virScanKey sheet must contain the following columns at minimum:
#' \code{inputLib, libAmpDate, protocol, plateName, labLead, PI, studyName,
#' fullName, replicate_fullname} or leave those arguments NULL in this fxn.
#'
#' @param keysList Instead of entering a path, you can enter a keysList that was
#'   made using the \code{\link{vs.getKeysList()}} function
#'
#' @param path,virScanPath,samplePath,noSampleData If not using keysList, Path
#'   to sample meta data Excel workbook. If the experimental setup and the
#'   samples meta data are in two different files, then keep \code{path = NULL}
#'   and fill in \code{virScanPath,samplePath} to direct to the virScan data and
#'   the sample meta data, respectively. If there is no sample data to join,
#'   then set \code{noSampleData = TRUE}.
#'
#' @param table_name_vs,table_name_samp the tables within the excel workbook
#'   that includes the full experimtnal setups and the samples meta data,
#'   respectively. Defaults are "VirScanKey" and "SamplesKey". If path or path2
#'   leads to csvs, then don't need to fill out the respective table names.
#'
#' @param pi,study_name,project_name,project_name2 Can specify based on the
#'   virScanKey data
#'
#' @param unique_methods_long_id Can be a vector of strings. Appropriate when
#'   calculating fold-enrichment from beads. Essentially this is the overall
#'   conditions used: Unique combination of library(s) used, amplification date,
#'   date combined, when combining two libraries, and the protocol, such as
#'   double or single IP, IgM, etc.... (If calculating fold enrichment off of
#'   input library, then specify input_id instead)
#'
#' @param fully_comparable_long_id Collects sampels will all same methods and
#'   same dilutions of the serum. Perhaps useful for downstream data analysis,
#'   but not for calculating foldenrichments - since beadsOnly will not have any
#'   dilutions, etc.
#'
#' @param plate_name,lab_lead These are all possible vectors of strings to include
#'   for the desired samples. Can use as many as needed to get desired selection
#'   of samples output. The should match the columns in the sample meta data
#'   sheet
#'
#' @param input_id Can be a vector of strings. The input library
#'   that was used. This only considers the input library and the amplification
#'   or combination date. Most useful when calculating fold-enrichment off of
#'   input library rather than beadsOnly. Refer to the inputLibKeys file.
#'
#'
#'
#' @param input_name,amp_or_combined_date,dilution_other_change,input_full_description,protocol,assay_date,time_series Other columns to potentially choose on.
#'
#' @param tube_id If want to specify just some tubeIDs
#' @param individual If want to specify just some individuals
#' @param includeBeads,includeLibrary Should the beads or library associated
#'   with the samples be included?
#'   included?
#' @param unique_sample_id_colName (Deprecated, Defaults to "unique_sample_id")
#'   Useful if the replicates haven't already been formulated.
#'
#' @param returnOnlyBeads,returnOnlyLibrary Should just the beads or the library
#'   be returned?
#'
#' @export
vs.setParams_makeSampsDF <- function(keysList = NULL,

                                     virScanPath = NULL,
                                     samplePath = NULL,
                                     noSampleData = FALSE,
                                     table_name_vs = "virScanKey",
                                     table_name_samp = "samplesKey",

                                     pi = NULL,
                                     study_name = NULL,
                                     project_name = NULL,
                                     project_name2 = NULL,
                                     unique_methods_long_id = NULL,
                                     input_id = NULL,
                                     fully_comparable_long_id = NULL,
                                     plate_name = NULL,
                                     lab_lead = NULL,

                                     only_samps_w_replicates = FALSE,

                                     input_name = NULL,
                                     amp_or_combined_date = NULL,
                                     dilution_other_change = NULL,
                                     input_full_description = NULL,
                                     protocol = NULL,
                                     assay_date = NULL,

                                     tube_id = NULL,
                                     individual = NULL,
                                     time_series = NULL,
                                     unique_sample_id_colName = "unique_sample_id",
                                     includeBeads = FALSE,
                                     includeLibrary = FALSE,
                                     returnOnlyBeads = FALSE,
                                     returnOnlyLibrary = FALSE,
                                     splitByMethods = FALSE,
                                     splitByInput = FALSE){
  paramsList <-
    list(keysList = keysList,

         virScanPath = virScanPath,
         samplePath = samplePath,
         noSampleData = noSampleData,

         table_name_vs = table_name_vs,
         table_name_samp = table_name_samp,

         pi = pi,
         study_name = study_name,
         project_name = project_name,
         project_name2 = project_name2,
         unique_methods_long_id = unique_methods_long_id,
         input_id = input_id,
         fully_comparable_long_id = fully_comparable_long_id,
         plate_name = plate_name,
         lab_lead = lab_lead,

         only_samps_w_replicates = only_samps_w_replicates,
         input_name = input_name,
         amp_or_combined_date = amp_or_combined_date,
         dilution_other_change = dilution_other_change,
         input_full_description = input_full_description,
         protocol = protocol,
         assay_date = assay_date,

         tube_id = tube_id,
         individual = individual,
         time_series = time_series,

         unique_sample_id = unique_sample_id_colName,
         includeBeads = includeBeads,
         includeLibrary = includeLibrary,
         returnOnlyBeads = returnOnlyBeads,
         returnOnlyLibrary = returnOnlyLibrary,
         splitByMethods = splitByMethods,
         splitByInput = splitByInput)

  return(paramsList)
}






#-------------------------------------------------------------------------------
#vs.makeSampsDF
#-------------------------------------------------------------------------------
#' Collect sample \code{full_names} and their replicates given parameters list
#'
#' @importFrom magrittr %>%
#'
#' @param paramsList A list made using \code{\link{vs.setParams_sampsDF()}}
#' @param returnAllCols Should all of the columns from the database be returned
#'   (TRUE) or just the full_name and replicate_full_name columns?
#'
#' @export
vs.makeSampsDF <- function(paramsList,
                           keysList = NULL,
                           returnAllCols = FALSE,
                           includeBeads = NULL,
                           includeLibrary = NULL,
                           returnOnlyBeads = NULL,
                           returnOnlyLibrary = NULL){


  if(is.null(keysList)) keysList = paramsList$keysList
  if(is.null(includeBeads)) includeBeads = paramsList$includeBeads
  if(is.null(includeLibrary)) includeLibrary = paramsList$includeLibrary
  if(is.null(returnOnlyBeads)) returnOnlyBeads = paramsList$returnOnlyBeads
  if(is.null(returnOnlyLibrary)) returnOnlyLibrary = paramsList$returnOnlyLibrary

  virScanPath = paramsList$virScanPath
  samplePath = paramsList$samplePath
  noSampleData = paramsList$noSampleData

  table_name_vs = paramsList$table_name_vs
  table_name_samp = paramsList$table_name_samp


  pi = paramsList$pi
  study_name = paramsList$study_name
  project_name = paramsList$project_name
  project_name2 = paramsList$project_name2
  unique_methods_long_id = paramsList$unique_methods_long_id
  input_id = paramsList$input_id
  plate_name = paramsList$plate_name
  lab_lead = paramsList$lab_lead

  only_samps_w_replicates = paramsList$only_samps_w_replicates
  input_name = paramsList$input_name
  amp_or_combined_date = paramsList$amp_or_combined_date
  dilution_other_change = paramsList$dilution_other_change
  input_full_description = paramsList$input_full_description
  protocol = paramsList$protocol
  assay_date = paramsList$assay_date

  tube_id = paramsList$tube_id
  individual = paramsList$individual
  time_series = paramsList$time_series

  unique_sample_id = paramsList$unique_sample_id
  splitByMethods = paramsList$splitByMethods
  splitByInput = paramsList$splitByInput


  if(returnOnlyBeads == TRUE) {includeBeads = TRUE}
  if(returnOnlyLibrary == TRUE) {includeLibrary = TRUE}


  virScanInfo = NULL
  sampInfo = NULL

  if(is.null(keysList)){

    if(is.null(virScanPath)){
      virScanPath = path
      samplePath = path
    }


    suppressWarnings(
      virScanInfo <- mmR::mm.fastread(path = virScanPath,table = table_name_vs))


    if(noSampleData == FALSE){
      suppressWarnings(
        sampInfo <- mmR::mm.fastread(path = samplePath, table = table_name_samp))
    }

  }

  if(!is.null(keysList)){
    virScanInfo = keysList[[table_name_vs]]
    sampInfo = keysList[[table_name_samp]]
  }


  suppressWarnings(
    if(!is.null(unique_sample_id)){
      if(unique_sample_id %in% names(virScanInfo)){
        virScanInfo <-
          virScanInfo %>%
          dplyr::mutate(unique_sample_id = as.character(unique_sample_id))
      }
    }
  )



  suppressWarnings(
    if(!is.null(unique_sample_id)){

      if(noSampleData == FALSE){
        if(unique_sample_id %in% names(sampInfo)){
          sampInfo <-
            sampInfo %>%
            dplyr::mutate(unique_sample_id = as.character(unique_sample_id))
        }
      }
    }
  )


  #NEed to store a copy for retriveing the input library later.
  libraryOnly <- virScanInfo %>% dplyr::filter(library_sample ==1)
  beadsOnly  <- virScanInfo %>% dplyr::filter(beads_only ==1)


  #Get all samples that used all same protocol and supplies

  if(!is.null(unique_methods_long_id)){
    virScanInfo <- virScanInfo[virScanInfo$unique_methods_long_id %in% unique_methods_long_id , ]
  }

  if(!is.null(input_id)){
    virScanInfo <- virScanInfo[virScanInfo$input_id %in% input_id , ]
  }


  if(!is.null(input_name)){
    virScanInfo <- virScanInfo[virScanInfo$input_name %in% input_name , ]
  }

  if(!is.null(amp_or_combined_date)){
    virScanInfo <- virScanInfo[virScanInfo$amp_or_combined_Date %in% amp_or_combined_date , ]
  }

  if(!is.null(input_full_description)){
    virScanInfo <- virScanInfo[virScanInfo$input_full_description %in% input_full_description , ]
  }

  if(!is.null(protocol)){
    virScanInfo <- virScanInfo[virScanInfo$protocol %in% protocol , ]
  }

  if(!is.null(assay_date)){
    virScanInfo <- virScanInfo[virScanInfo$assay_date %in% assay_date , ]
  }

  if(!is.null(plate_name)){
    virScanInfo <- virScanInfo[virScanInfo$plate_name %in% plate_name , ]
  }

  if(!is.null(lab_lead)){
    virScanInfo <- virScanInfo[virScanInfo$lab_lead %in% lab_lead , ]
  }


  if(!is.null(pi)){
    virScanInfo <- virScanInfo[virScanInfo$pi %in% pi , ]
  }

  if(!is.null(study_name)){
    virScanInfo <- virScanInfo[virScanInfo$study_name %in% study_name , ]
  }


  if(!is.null(project_name)){
    virScanInfo <- virScanInfo[virScanInfo$project_name %in% project_name , ]
  }


  if(!is.null(project_name2)){
    virScanInfo <- virScanInfo[virScanInfo$project_name2 %in% project_name2 , ]
  }



  if(!is.null(tube_id)){
    virScanInfo <- virScanInfo[virScanInfo$tube_id %in% tube_id , ]
  }

  if(!is.null(individual)){
    virScanInfo <- virScanInfo[virScanInfo$individual %in% individual , ]
  }


  #------------------------#
  #Library Only section
  #Capture Library

  input_used <-
    unique((virScanInfo %>% select(input_full_description))$input_full_description)


  libraryOnly <-
    libraryOnly  %>%
    dplyr::filter(input_full_description %in% input_used)


  nLib <- 0
  try(nLib <- nrow(libraryOnly))

  #Remove beads and library from overall
  virScanInfo <- virScanInfo[ ! virScanInfo$full_name %in% libraryOnly$full_name, ]

  if(includeLibrary == FALSE){
    libraryOnly = NULL
    nLib = 0
  }
  #------------------------#

  #------------------------#
  #BEADS ONLY SECTION
  #Capture beads

  methods_used <-
    unique((virScanInfo %>% select(unique_methods_long_id)))$unique_methods_long_id

  beadsOnly <-
    beadsOnly %>%
    dplyr::filter(unique_methods_long_id %in% methods_used)

  nBead <- 0
  try(nBead <- nrow(beadsOnly))

  #Remove beads and library from overall
  virScanInfo <- virScanInfo[ ! virScanInfo$full_name %in% beadsOnly$full_name, ]

  if(includeBeads == FALSE){
    beadsOnly = NULL
    nBead = 0
  }





  try(nSamples <- nrow(virScanInfo))
  if(returnOnlyBeads | returnOnlyLibrary){
    virScanInfo = NULL
    nSamples = 0
    if(returnOnlyBeads){libraryOnly = NULL; nLib =0}
    if(returnOnlyLibrary){beadsOnly = NULL; nBead = 0}
  }


  if(only_samps_w_replicates == TRUE){

    if("replicate_full_name" %in% names(virScanInfo)){
      virScanInfo <-
        virScanInfo %>%
        dplyr::filter(!is.na(replicate_full_name))
    }

  }



  virScanInfo =
    dplyr::bind_rows(
      list(virScanInfo,
           beadsOnly,
           libraryOnly)
      ) %>% unique()


  if(nrow(virScanInfo) == 0){
    stop("No samples fitting your criteria found")
  }

  if(noSampleData == FALSE){
    if("time_point" %in% names(sampInfo)){
      getSampInfo <- c("unique_sample_id", "time_point")
    } else {
      getSampInfo <- "unique_sample_id"
    }

    virScanInfo <-
      virScanInfo %>%
      dplyr::left_join(sampInfo %>%
                         dplyr::select(getSampInfo),
                       by = "unique_sample_id") %>%
      dplyr::filter(!is.na(full_name)) %>%
      unique()
  }








  allNames <- names(virScanInfo)
  namesFirst <-
    c("PI",
      "study_name",
      "project_name",
      "project_name2",
      "unique_methods_long_id",
      "protocol",
      "input_id",
      "individual",
      "dilution_other_change",
      "full_name",
      "replicate_full_name",
      "amp_or_combined_date",
      "plate_name")

  keepNamesFirst <- namesFirst[which(namesFirst %in% allNames)]
  allNames2 <- allNames[-which(allNames %in% keepNamesFirst)]
  namesOrdered <- c(keepNamesFirst, allNames2)

  try(print(sprintf(
    "Returning %s samples: Samples: %s + Beads: %s + input Library: %s",
    nrow(virScanInfo), nrow(virScanInfo) - nBead - nLib,nBead,nLib))
  )

  if(returnAllCols == TRUE){

    toReturn <- virScanInfo %>% dplyr::select(namesOrdered)

  } else {

    toReturn <-
      virScanInfo %>%
      select(full_name,
             replicate_full_name,
             unique_methods_long_id,
             input_id,
             beads_only,
             library_sample)

  }

  if(splitByMethods == TRUE){
    return(mmR::mm.split_to_list(toReturn,by = "unique_methods_long_id"))
  }

  if(splitByInput == TRUE & splitByMethods == FALSE) {
    return(mmR::mm.split_to_list(toReturn,by = "input_id"))
  }

  if(splitByInput == FALSE & splitByMethods == FALSE) {
    return(toReturn)
  }

}
