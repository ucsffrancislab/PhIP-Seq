
#" function to create an example excel workbook to fill in for sample meta data
#' works best if writexl package is installed. Else will write csv files separately.
#' @param path Directory where to place example workbook or csvs
#' @param overwrite TRUE to overwtie previously created file? Default = FALSE.
#' @importFrom magrittr %>%
#' @export

vs.create_example_sampleMetaData <- function(path = NULL,overwrite = FALSE){

  
  
  
  # example_enterVirScanData <- mm.fastread("./other data/example_sampleData.xlsx", table = "enterVirScanData")
  # example_enterIndividualData <- mm.fastread("./other data/example_sampleData.xlsx", table = "enterIndividualData")
  # example_enterSampleData <- mm.fastread("./other data/example_sampleData.xlsx", table = "enterSampleData")
  # example_inputLibKeys <- mm.fastread("./other data/example_sampleData.xlsx", table = "inputLibKey")
  # # 
  # save(example_enterVirScanData, file = "./inst/extdata/example_enterVirScanData.rda")
  # save(example_enterIndividualData, file = "./inst/extdata/example_enterIndividualData.rda")
  # save(example_enterSampleData, file = "./inst/extdata/example_enterSampleData.rda")
  # save(example_inputLibKeys, file = "./inst/extdata/example_inputLibKeys.rda")
  
  
  
  load(system.file("extdata", "example_enterIndividualData.rda", package = "virScanR"))
  load(system.file("extdata", "example_enterSampleData.rda", package = "virScanR"))
  load(system.file("extdata", "example_enterVirScanData.rda", package = "virScanR"))
  load(system.file("extdata", "example_inputLibKeys.rda", package = "virScanR"))

  exampleWkbk <- list(
    enterSampleData = example_enterSampleData,
    enterIndividualData = example_enterIndividualData,
    enterVirScanData = example_enterVirScanData,
    inputLibKey = example_inputLibKeys)


  exampleWkbk$enterSampleData[nrow(exampleWkbk$enterSampleData)+1,] <-
    c("REQUIRED",
      "REQUIRED",
      "REQUIRED",
      "REQUIRED",
      "1 if part of a series of serial samples",
      rep(NA,(ncol(exampleWkbk$enterSampleData)-5)))

  exampleWkbk$enterIndividualData[nrow(exampleWkbk$enterIndividualData)+1,] <-
    c("REQUIRED","REQUIRED","REQUIRED - should match entry in enterSampleData",
      "1 if individual has >1 sample across time included",
      "1 if individual part of a birth cohort",
      "add Xm if months, X if years",
      rep(NA,(ncol(exampleWkbk$enterIndividualData)-6)))


  exampleWkbk$enterVirScanData[nrow(exampleWkbk$enterVirScanData)+1,] <-
    c("REQUIRED",
      "REQUIRED",
      "REQUIRED - should match entry in enterSampleData",
      "Dilution or change made to SAMPLE - NOT INPUT - Changes in input conc/vol should be reflected under protocol (i.e. doubleIP vs. singleIP, etc",
      "REQUIRED-see inputLibKey",
      "REQUIRED-see inputLibKey",
      "1 if beads_only sample",
      "1 if input library sample",
      NA,
      "REQUIRED-unless using custom_full_name - see custom_full_name column",
      "REQUIRED-unless using custom_full_name - see custom_full_name column",
      "REQUIRED-unless using custom_full_name - see custom_full_name column",
      NA,NA,NA,
      "ONLY if the sample name in the data base is not: plate_name.RowCol (i.e. plate1.A2 or mjm14.H12",
      NA,NA,NA,NA,
      "Useful",
      rep(NA,11))

  exampleWkbk$enterVirScanData[nrow(exampleWkbk$enterVirScanData)+1,] <-
    c("Fill out pi,study_name,tube_id to match the same spelling/capitalization as enterSampleData and enterIndividualData. input_id is a special id given to each input - see inputLibKey page. This will allow the correct samples to be retrieved later. Protocol should be farely standard - i.e. doubleIP, singleIP, but anything is fine as long as it's consistent with any other samples that used the same protocol. KEY thing to note - virScanR expects BUT DOES NOT REQUIRE that the samples names in the counts database are in the format plate_name.rowCol (such as plate1.G8). If a different naming system was used for your samples, that is fine - BUT YOU MUST FILL OUT THE 'custom_full_name' COLUMN here. Also, if you have technical replicates, the software can automatically detect them. To do this it uses the tube_id as well as the pi + study_name + input_id + protocol + dilution_other_change and finds matching samples. HOWEVER, if you want to force a specific replciate (for instance if there are more than 2 replicates and you want to specify how they get paired), then fill in either 'custom_replicate_full_name' with the sample name of the replicate in the actual counts database, OR if in the plate_name.rowCol format, then can fill out 'custom_replicate_plate_name','custom_replicate_row','custom_replicate_column' (note that ALL 3 must be filled out if using plateName.rowCol format). Everything else should be self explanatory. The more you fill out, the more directed your searches can be in the future!",rep(NA,ncol(exampleWkbk$enterVirScanData)-1))

  if(is.null(path)) {
    directory = "."
  } else if(!dir.exists((path))) {
    directory = "."
  } else {directory = path}


  currentdt <- format(Sys.time(), "%y%m%d_%H_%M")

  if(requireNamespace("writexl", quietly = TRUE)==TRUE){
    exampleWkbk$inputLibKey = vs.make_example_inputLibKey_template.int()
    writexl::write_xlsx(x = exampleWkbk,
                        file.path(directory,paste0("example_sampleData_",currentdt,".xlsx")))


    #data.table::fwrite(IDDF_inputCounts, paste0(newIDdataFrameAndBeadsCounts,format(Sys.time(), "%y%m%d_%H_%M"),".csv"))

    print("example_sampleData.xlsx written to path, or to working directory if path not specified. Please use this as a template when entering new sample or virScan meta data")
  } else {

    if( !dir.exists(file.path(directory,"example_enterMetaData_csvs"))){
      dir.create(file.path(directory,"example_enterMetaData_csvs"))
    }

    write.csv(exampleWkbk$enterIndividualData,
              file.path(directory,
                        "example_enterMetaData_csvs",
                        paste0("example_enterIndividualData_",currentdt,".csv")))

    write.csv(exampleWkbk$enterSampleData,
              file.path(directory,
                        "example_enterMetaData_csvs",
                        paste0("example_enterSampleData_",currentdt,".csv")))

    write.csv(exampleWkbk$enterVirScanData,
              file.path(directory,
                        "example_enterMetaData_csvs",
                        paste0("example_enterVirScanData_",currentdt,".csv")))
    write.csv(exampleWkbk$inputLibKey,
              file.path(
                directory,
                "example_enterMetaData_csvs",
                paste0("example_inputLibKey_",currentdt,".csv")))

    print("It appears package 'writexl' is not installed. Please install it to get the full excel template. For now, example csv files for entering sample and virScan meta data placed in a folder called 'example_enterMetaData_csvs' in path, or in the current working directory if path is not specified. Please note, the formulas in inputLibKey will not show up in these csvs. Install writexl or if you need the formulas, email me at michael.j.mina@gmail.com")

  }

}






#' Function to make a template inputLibKey
#' @importFrom magrittr %>%


vs.make_example_inputLibKey_template.int <- function(){
  instructions <- "DELETE this instructions after reading. 1) Fill out only columns B through H. 2) If using only a single library, fill out ONLY columns B and C and leave D through H blank. 3) If the input library is a combination of 2 or more base libraries, first ensure that the base libraries are already input into column B (the input library name) and column C (the amplification date of that library; yymmdd format). 4) Once the base libraries are input, copy down the formula in column A then refer to the individual base libraries that are combined by their 'input_id_base' name in column A. See examples. If there are two libraries, then only columns D and E should be filled out. 3 libraries would need columns D, E, F filled out, and four libraries combined D,E,F,G. In column H, add the date that the libraries are all combined. Then copy down the formulas in column A,I,J,K,L,M."
  
  dat <-
    data.frame(input_id_base = rep("",8),
               input_lib_name = c("vir2", "vir3", "vir3",  "ZKV", "A11","","",instructions),
               amp_date =       c(160114, 171111, 180913, 160805,100,"","",""),
               combo_input_id_base1 = c("","","","","","vir2_160114","vir3_180913",""),
               combo_input_id_base2 = c("","","","","","A11_100"    ,"ZKV_160805",""),
               combo_input_id_base3 = c("","","","","","ZKV_160805","",""),
               combo_input_id_base4 = c("","","","","","","",""),
               combined_date = c("","","","","",100, 181015,""))  %>%
    
    
    dplyr::mutate(n_libs_combined =
             writexl::xl_formula(
               paste0('=IF(OR(D',dplyr::row_number()+1,' = " ",ISBLANK(D',dplyr::row_number()+1,')), 0, IF(OR(F',dplyr::row_number()+1,' = " ",ISBLANK(F',dplyr::row_number()+1,')), 2, IF(OR(G',dplyr::row_number()+1,' = " ",ISBLANK(G',dplyr::row_number()+1,')), 3, 4)))'))) %>%

    dplyr::mutate(input_id_base =
             writexl::xl_formula(
               paste0('=IF(I',dplyr::row_number()+1,'>0,"combination",B',dplyr::row_number()+1,'&"_"&C',dplyr::row_number()+1,')'))) %>%
           
    dplyr::mutate(input_name =
             writexl::xl_formula(paste0(
               '=IF(I',dplyr::row_number()+1,'=2,      VLOOKUP(D',dplyr::row_number()+1,', A$1:B10000,2,FALSE)&"+"&VLOOKUP(E',dplyr::row_number()+1,', A$1:B10000,2,FALSE),    IF(I',dplyr::row_number()+1,'=3,     VLOOKUP(D',dplyr::row_number()+1,', A$1:B10000,2,FALSE)&"+"&VLOOKUP(E',dplyr::row_number()+1,', A$1:B10000,2,FALSE)&"+"&VLOOKUP(F',dplyr::row_number()+1,', A$1:B10000,2,FALSE),  IF(I',dplyr::row_number()+1,'=4,     VLOOKUP(D',dplyr::row_number()+1,', A$1:B10000,2,FALSE)&"+"&VLOOKUP(E',dplyr::row_number()+1,', A$1:B10000,2,FALSE)&"+"&VLOOKUP(F',dplyr::row_number()+1,', A$1:B10000,2,FALSE)&"+"&VLOOKUP(G',dplyr::row_number()+1,', A$1:B10000,2,FALSE),B',dplyr::row_number()+1,')))'))) %>%
           
    dplyr::mutate(input_id = writexl::xl_formula(paste0('=IF(I',dplyr::row_number()+1,'=0,A',dplyr::row_number()+1,',CONCATENATE(J',dplyr::row_number()+1,',"_c",H',dplyr::row_number()+1,'))'))) %>%
           
           
    dplyr::mutate(full_description = writexl::xl_formula(paste0('=IF(I',dplyr::row_number()+1,'=0,K',dplyr::row_number()+1,',IF(I',dplyr::row_number()+1,'=2,D',dplyr::row_number()+1,'&"+"&E',dplyr::row_number()+1,'&"_c"&H',dplyr::row_number()+1,',IF(I',dplyr::row_number()+1,'=3,D',dplyr::row_number()+1,'&"+"&E',dplyr::row_number()+1,'&"+"&F',dplyr::row_number()+1,'&"_c"&H',dplyr::row_number()+1,',IF(I',dplyr::row_number()+1,'=4,D',dplyr::row_number()+1,'&"+"&E',dplyr::row_number()+1,'&"+"&F',dplyr::row_number()+1,'&"+"&G',dplyr::row_number()+1,'&"_c"&H',dplyr::row_number()+1,'))))'))) %>%
    
    dplyr::mutate(amp_or_combined_date = writexl::xl_formula(paste0('=IF(I',dplyr::row_number()+1,'=0,C',dplyr::row_number()+1,',H',dplyr::row_number()+1,')')))
  
  return(
    dat %>% dplyr::select(input_id_base,input_lib_name,amp_date,combo_input_id_base1,combo_input_id_base2,combo_input_id_base3,combo_input_id_base4,combined_date,n_libs_combined,input_name,input_id,full_description,amp_or_combined_date))
  
}
