#' Calculates the rowWise summary  of a group of columns after removing the outliers.
#'
#' Calculates the rowMeans of a group of columns after removing the outliers.
#' Outliers can be defined by the parameter \code{outlierLimit}.
#'
#' @param outlierLimit How many IQRs above the third or below the first quartile
#'   should the data be considered an outlier. Default is 1.5. In other words,
#'   if the IQR (i.e. 75%-25% quartile) is 100 and the first and third quartiles
#'   is are 200 and 300, then anything abobe 450 or below 50 would be considered
#'   an outlier.
#' @param noOutlierRemoval Just perform summary function but dont remove outliers.Essentially just runs vs.rowFXN
#'   See also \code{\link{vs.rowFXN}}.
#'
#' @return Returns either a dataframe with ncol(data)+1 columns, the last being
#'   the "summary" column, or a vector.
#' @inheritParams vs.rowFXN
#'
#' @importFrom magrittr %>%
#' @export

vs.rowFXN_NoOutlier <- function(data,
                                rowFun = NULL,
                                name = "rowSummary",
                                overwrite_name = FALSE,
                                cores = parallel::detectCores(),
                                na.rm = TRUE,
                                extraParams = NULL,
                                returnAsVector = TRUE,
                                cols_to_not_evaluate = NULL,
                                cols_to_evaluate = NULL,
                                returnNotEvaluated = TRUE,
                                outlierLimit = 1.5,
                                noOutlierRemoval = FALSE,
                                convertTo = NA,
                                makeShallowCopy = TRUE,
                                returnName = FALSE,
                                ...){


  if(noOutlierRemoval == TRUE){
    return(
      vs.rowFXN(data = data,
                rowFun = rowFun,
                name = name,
                overwrite_name = overwrite_name,
                cores = cores,
                na.rm = na.rm,
                extraParams = extraParams,
                returnAsVector = returnAsVector,
                cols_to_not_evaluate = cols_to_not_evaluate,
                cols_to_evaluate = cols_to_evaluate,
                makeShallowCopy = makeShallowCopy,
                returnName = returnName)
    )
  } else {
    whatClassAll <- class(data)
    whatClass <- whatClassAll[1]

    if(whatClass != "data.table"){
      data = data.table::setDT(data)
    }

    if(makeShallowCopy == TRUE) data = data.table::copy(data)
    #Split data into a df to evaluate and a df to not evaluate.
    #and keep original column orders in a third list element.
    data <-
      vs.split_cols_to_and_not_to_evaluate(data = data,
                                           cols_to_not_evaluate = cols_to_not_evaluate,
                                           cols_to_evaluate = cols_to_evaluate,
                                           returnNotEvaluated = returnNotEvaluated)


      data$dataEval <-
        vs.outliers_to_XX_rowWise(data = data$dataEval,
                                  outlierLimit = outlierLimit,
                                  convertTo = convertTo,
                                  cores = cores)



    if(returnAsVector == TRUE){
      return(vs.rowFXN(data = data$dataEval,
                       rowFun = rowFun,
                       name = name,
                       overwrite_name = overwrite_name,
                       cores = cores,
                       extraParams = extraParams,
                       na.rm = na.rm,
                       returnAsVector = TRUE,
                       cols_to_not_evaluate = NULL,
                       cols_to_evaluate = NULL,
                       makeShallowCopy = FALSE,
                       returnName = FALSE
      ))
    } else {


      data$dataEval <-
        vs.rowFXN(data = data[["dataEval"]],
                  rowFun = rowFun,
                  name = name,
                  overwrite_name = overwrite_name,
                  cores = cores,
                  extraParams = extraParams,
                  na.rm = na.rm,
                  returnAsVector = returnAsVector,
                  cols_to_not_evaluate = NULL,
                  cols_to_evaluate = NULL,
                  makeShallowCopy = makeShallowCopy,
                  returnName = TRUE
        )

      if(returnNotEvaluated == TRUE){
        #check to ensure the new name added in the dataEval is not already in the unevaluated
        baseName <- data$dataEval$name
        newName = baseName
        tick = 0
        while(newName %in% names(data$dataNoEval)){
          tick = tick+1
          newName = paste0(baseName,".",tick)
        }
        if(newName != baseName & baseName == name){
          warning(sprintf("Designated column name %s already used in unevaluated columns. New column name set to %s",baseName,newName))
        } else if(newName != baseName & baseName != name){
          warning(sprintf("Designated column name %s already used in both evaluated and unevaluated columns. New column name set to %s",baseName,newName))
        }

        if(newName != baseName){
          dataEvalNames <- names(data$dataEval$data)
          nameChangeIndex <- which(dataEvalNames == baseName)
          dataEvalNames[nameChangeIndex] <- newName
          names(data$dataEval$data) <- dataEvalNames
        }

        originalColOrder <- c(data$originalColOrder, newName)

        data <-
          data.table::setDT(
            cbind(data$dataNoEval,data$dataEval$data)
          )[,..originalColOrder]
      } else {
        data <- data$dataEval$data
      }

      if(whatClass == "data.table"){
        if(returnName == TRUE){
          return(list(data = data, name = name))
        } else {
          return(data)
        }
      } else {
        data.table::setDF(data)
        data.table::setattr(data, "class", whatClassAll)
        if(returnName == TRUE){
          return(list(data = data, name = name))
        } else {
          return(data)
        }
      }
    }
  }
}




