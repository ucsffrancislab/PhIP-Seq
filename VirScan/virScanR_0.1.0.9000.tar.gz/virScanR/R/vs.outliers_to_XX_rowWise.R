#-------------------------------------------------------------------------------
#Internal function to setup and trim for column summary function
#-------------------------------------------------------------------------------
#' Function to remove outliers rowWise using outlier limits. .
#' @param data Data to remove outliers from. Each column must be numeric.
#' @param outlierLimit How many IQRs above the third or below the first quartile
#'   should the data be considered an outlier. Default is 1.5. In other words,
#'   if the IQR (i.e. 25%-75% quartile) is 100 and the first and third quartiles
#'   are 200 and 300, then anything abobe 450 or below 50 would be considered
#'   an outlier.
#' @param convertTo What value to convertTo if data is outlier? NA is default.
#' @param cores How many cores to use for parallel processing.
#' @importFrom magrittr %>%
#' @export
vs.outliers_to_XX_rowWise <-
  function(data,
           outlierLimit = 1.5,
           convertTo = NA,
           cores = parallel::detectCores(),
           ...){

    whatClass <- class(data)[1]

    if(whatClass != "data.table") data <- data.table::data.table(data)
    #---------------------------------------------------------------------------


  if(cores>1 &
     (requireNamespace(package = "parallel")==TRUE)){

    datanames <- data.table::copy(names(data))

    suppressWarnings(
    data[ ,
          index := c(1:.N)
          ][ ,
             group := rep(c(1:cores),
                          length = .N)
             ])

    ranges <-
      data.table::rbindlist(
        parallel::mclapply(X = c(1:cores),
                           FUN = function(X) {
                             toQuant <- data.table::copy(data[group == X, ]) #HERE

                             myFun <- function(data1){
                               toReturn <- t(apply(data1,1,quantile,probs = c(.25,.75),na.rm = TRUE))
                               return(list(toReturn[,1],toReturn[,2]))
                             }

                             toQuant[,c("ll","ul") := myFun(.SD), .SDcols = datanames]
                           },
                           mc.cores = parallel::detectCores()
        )
      )[order(index),.(index,ll,ul)][,
                                     range := ul-ll
                                     ][,
                                       extRange := outlierLimit * range
                                       ][,lowerLim := ll-extRange
                                         ][,upperLim := ul + extRange]

    data[,c("index","group") := NULL]


  } else { #if not in parallel



    myFun <- function(data1){
      toReturn <- t(apply(data1,1,quantile,probs = c(.25,.75),na.rm = TRUE))
      return(list(toReturn[,1],toReturn[,2]))
    }

    ranges <-
      data.table::copy(data)[,
                             c("ll","ul") := myFun(.SD)
                             ][,
                               .(ll,ul)
                               ][,range := ul-ll
                                 ][,
                                   extRange := outlierLimit * range
                                   ][,lowerLim := ll-extRange
                                     ][,upperLim := ul + extRange]

  }




    if(cores>1 &
       (requireNamespace(package = "parallel")==TRUE)){
      toReturn <- data[ ,                               #HERE
                 parallel::mclapply(.SD,
                                    FUN = function(X,ll,ul,convertTo){
                                      indexLL <- which(X < ranges$lowerLim)
                                      indexUL <- which(X > ranges$upperLim)
                                      index <- c(indexLL,indexUL)
                                      X[index] <-
                                        ifelse(is.na(convertTo),
                                               NA,
                                               ifelse(is.null(convertTo),
                                                      NULL,convertTo))
                                      return(X)
                                    },
                                    ll = ll,
                                    ul = ul,
                                    convertTo = convertTo,
                                    mc.cores = cores)
                 ]
    } else {

      toReturn <-
        data[ ,                               #HERE
            lapply(.SD,
              FUN = function(X,ll,ul,convertTo){
                indexLL <- which(X < ranges$lowerLim)
                indexUL <- which(X > ranges$upperLim)
                index <- c(indexLL,indexUL)
                X[index] <-
                  ifelse(is.na(convertTo),
                         NA,
                         ifelse(is.null(convertTo),
                                NULL,convertTo))
                return(X)
                },
              ll = ll,
              ul = ul,
              convertTo = convertTo)
            ]
    }
    return(toReturn)
  }
