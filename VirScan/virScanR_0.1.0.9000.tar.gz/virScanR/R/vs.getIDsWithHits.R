#------------------------------------------------------------------------------#
#Returns only ID names for IDs that had greater than maxHits
#
#pValsWide <- sampPvals
#pThresh = 2.3
#maxHits = 0
#------------------------------------------------------------------------------#
#' @importFrom magrittr %>%
#' @export
vs.getIDsWithHits <- function(hitsDF,
                              pThresh = 2.3,
                              maxHits = 0){

  temp <- data.frame(col1 = unique(hitsDF[,2]))


  if(nrow(temp)<4){
    #doNothing here
  } else {
    hitsDF <- vs.makeBinomP(hitsDF,
                            pThresh = pThresh)
  }


  return(
    hitsDF %>%
      dplyr::select(id) %>%
      dplyr::mutate(
        nHits = apply(hitsDF %>% dplyr::select(-id) ,1,sum,na.rm=TRUE)
      ) %>%
      dplyr::filter(nHits > maxHits) %>%
      dplyr::select(id)
  )
}
