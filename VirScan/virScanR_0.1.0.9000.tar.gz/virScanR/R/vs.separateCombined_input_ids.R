#' Function to pull those input_ids that are combinations of 2 or single input
#' libraries and provide a breakdown of what single 'input_id's they are made
#' of. This is useful towards evaluating each portion of a combination library
#' virScan run separately.
#'
#' @param keysList,inputLibKey Provide either a keysList (derived from
#'   \code{\link{virScanR::vs.getKeysList}}) or an inputLibKey, which should be
#'   dataframe 'inputLibKey' in the samplesMeta data excel sheet.
#'
#' @importFrom magrittr %>%
#'
#' @export
vs.separateCombinedInput_ids <- function(keysList = NULL,inputLibKey = NULL){
  if(!is.null(keysList)){
    inputLibKey <- keysList$inputLibKey
  }


  return(
    tidyr::gather(inputLibKey,combo,lib,combo_input_id_base1:combo_input_id_base4) %>%
    arrange(input_id) %>%
    filter(!is.na(lib)) %>%
    select(input_id, component_input_id = lib))
}

