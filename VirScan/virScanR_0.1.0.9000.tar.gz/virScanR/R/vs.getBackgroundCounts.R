#------------------------------------------------------------------------------#
#Gets background counts... or hit COunts if reverse = TRUE.
#------------------------------------------------------------------------------#
#' Get background counts
#'
#' requires having the pvalues, the counts themselves and a pthershold, below
#' which we are sure that it is not a hit. the algorithm figures out from the
#' pVals which might be considered hits (useing the very conservative
#' pThreshForBackground), then makes any counts that were considered 'hits' at
#' the background threshold equal to zero and returns the rest.
#'
#' @param pVals Requires a pVals data frame from which to determine if a id is a
#'   hit or not. Requires replicates.
#'
#' @param counts the counts data to evaluate
#'
#' @param replicateNamesDF a replicate DF data frame required to determine if
#'   something is a hit, by combining two p-vals together.
#'
#' @param pThreshForBackground The threshold above which to consider something a
#'   hit. Probably this should be much more conservative.
#'
#' @param reverse Should it return the id counts for those that are considered
#'   hits, rather than nonhits.
#'
#' @return Returns the counts data, with those that are considered hits set to
#'   zero, or if reverse is set to TRUE, those that are considered non-hits set
#'   to zero
#'
#' @importFrom magrittr %>%
#' @export
vs.getBackgroundCounts <- function(pVals,
                                   counts,
                                   replicateNamesDF,
                                   pThreshForBackground = 1.5,
                                   reverse = FALSE,
                                   ...){


  hitsDF <- vs.getHits(pVals = pVals,
                       replicateNamesDF = replicateNamesDF,
                       pThresh = pThreshForBackground,
                       alreadyBinomial = FALSE)

  idsWithHits <- vs.getIDsWithHits(hitsDF = hitsDF,
                                   pThresh = pThreshForBackground,
                                   maxHits = 0)

  if(reverse == FALSE){
    idsNoHits <-
      pVals %>%
      dplyr::select(id) %>%
      dplyr::filter(!id %in% idsWithHits$id)
  } else {
    idsNoHits <-
      pVals %>%
      dplyr::select(id) %>%
      dplyr::filter(id %in% idsWithHits$id)
  }

  temp <-
    data.frame(
      counts = apply(counts %>%
                       dplyr::filter(id %in% idsNoHits$id) %>%
                       dplyr::select(-id),2,sum,na.rm = TRUE))
  temp$full_name = names(counts)[-1]


  rep1 <-
    temp %>%
    dplyr::filter(full_name %in% c(temp$full_name[1], replicateNamesDF$rep1)) %>%
    dplyr::select(rep1 = full_name, counts1 = counts)
  rep2 <-
    temp %>%
    dplyr::filter(full_name %in% c(temp$full_name[1], replicateNamesDF$rep2)) %>%
    dplyr::select(rep2 = full_name, counts2 = counts)

  temp <-
    rep1 %>%
    dplyr::left_join(replicateNamesDF %>%
                       dplyr::select(rep1, rep2), by = "rep1") %>%
    dplyr::left_join(rep2, by = "rep2")

  toReturn <- list(temp %>% dplyr::select(full_name = rep1, rep1 = counts1),
                   temp %>% dplyr::select(full_name = rep2, rep2 = counts2))

  toReturn[[2]][1,] = toReturn[[1]][1,]
  return(toReturn)
}
