#------------------------------------------------------------------------------#
#vs.getHits
#returns a single data frame with specimens that were a hit
#------------------------------------------------------------------------------#
#' Takes a data frame of pValues and returns a data frame of hits.
#'
#' @param replicateNamesDF A data frame with either of: (1) two columns, one
#'   called "full_name" and the other "replicate_full_name" or; (2) two columns,
#'   one called "rep1" and the other called "rep2".  In both cases, the first
#'   column (i.e. "full_name" or "rep1") will be considered the first replicate,
#'   and "rep2" or "replicate_fullname" will be the second replicate.  These
#'   columns should be found in the pVals data frame that is provided.
#'
#'
#' @importFrom magrittr %>%
#' @export
vs.getHits <- function(pVals,
                       replicateNamesDF,
                       pThresh = 2.3,
                       greaterThan = FALSE,
                       nonSampleCols = "id",
                       alreadyBinomial = FALSE,
                       combineConservatively = TRUE,
                       colNamesToReturn = NULL,
                       convert_NAs_to = NULL,
                       ...){


  if(alreadyBinomial == FALSE){
    pVals <- vs.makeBinomP(pVals = pVals,
                           pThresh = pThresh,
                           greaterThan = greaterThan,
                           nonSampleCols = nonSampleCols)
  }

  if(is.null(names(pVals[[1]]))){
    suppressWarnings(
    pSplit <-
      vs.splitReplicateData(table = pVals,
                            nonSampleColsNames = nonSampleCols,
                            replicateNamesDF = replicateNamesDF)
    )
  } else {
    pSplit = pVals
  }

  if(is.character(pSplit)){ #if pSplit Fails
    stop("Could not split into equal data sets by the supplied sampsDF")
  }

  toReturn <-
    vs.combineData(dat1 = pSplit[[1]],
                   dat2 = pSplit[[2]],
                   nonSampleCols1 = nonSampleCols,
                   arrangeByName = FALSE,
                   arrangeByColOrder = TRUE,
                   colNamesToReturn = colnames(pSplit[[1]]),
                   combineConservatively =combineConservatively,
                   isIntegerData = TRUE,
                   calcFun = "binomial",
                   convert_NAs_to = convert_NAs_to)


  if(!is.null(colNamesToReturn)){
    if(length(colNamesToReturn) == ncol(toReturn)){
      colnames(toReturn) <- colNamesToReturn
    }
  }

  return(toReturn)
}
