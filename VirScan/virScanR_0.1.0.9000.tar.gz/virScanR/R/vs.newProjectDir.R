#--------------------------------------------------------------------
# Set up directories for data and output #####
#--------------------------------------------------------------------
#' Create Required Directories
#'
#' @description Creates the following folders to \code{path} or to \code{getwd}.
#'     Will check if the directories exist and if they do, will not do anything.
#'     If they do not, will create the following folders:
#'     2 data
#'     3 output
#'     3 output/figures
#'     3 output/saved_models
#'     3 output/top features
#'     If using RStudio Projects, the path should already be identified
#'     appropriately.
#' @param path The path that you want the directories to be made in. If this is
#'   NULL or not entered, it will default to the current working directory.
#' @return Just creates the directories
#' @examples
#'  createDirectories()
#'  createDirectories(path = NULL)
#'  createDirectories(path = "./place/directories/here")
#'  @export


createDirectories <- function(path = NULL) {

    if (is.null(path)) {
        path1 <- getwd()
    } else {
        path1 = path
    }

    dataFolder <- file.path(path1, "2 data")
    if (file.exists(dataFolder)) {
    } else {
        dir.create(dataFolder)
    }

    outputFile <- file.path(path1, "3 output")
    if (file.exists(outputFile)) {
    } else {
        dir.create(outputFile)
    }

    figDir <- file.path(path1, "3 output", "figures")
    if (file.exists(figDir)) {
    } else {
        dir.create(figDir)
    }

    modelDir <- file.path(path1, "3 output", "saved_models")
    if (file.exists(modelDir)) {
    } else {
        dir.create(modelDir)
    }

    featureDir <- file.path(path1, "3 output", "top features")
    if (file.exists(featureDir)) {
    } else {
        dir.create(featureDir)
    }
}
