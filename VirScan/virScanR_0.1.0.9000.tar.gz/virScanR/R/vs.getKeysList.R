#------------------------------------------------------------------------------#
#------------------------------------------------------------------------------#
#' #Functino to return the "IndividualsKey, SamplesKey, VirScanKey and
#' inputLibKey from an Excel sheet given the path.
#'
#' @param path The path to the excel workbook containing the datasets
#' @param return_allSamplsInDBInfo,dataPath if TRUE will return a list with all
#'   of the data that is recorded in virScanKey and it's location in the
#'   database repository. The second element of the list will include all of the
#'   samples for which there are meta data but no actual data. Requires dataPath
#'   to be filled out. This should be a path to the parent directory where all
#'   of the counts data is stored. It can be stored across directories or
#'   databases within the parent directory
#' @importFrom magrittr %>%
#' @export
vs.getKeysList <- function(
  path = NULL,

  table_name_samp = "enterSampleData",
  table_name_ind = "enterIndividualData",
  table_name_vs = "enterVirScanData",
  table_name_libKey = "inputLibKeys",

  samplePath = NULL,
  individualPath = NULL,
  virScanPath = NULL,
  inputLibKeyPath = NULL,

  remove_duplicates = TRUE,
  return_duplicates = TRUE,
  return_allSamplsInDBInfo = FALSE,
  dataPath = NULL,
  combine_all = TRUE,
  ...){


  # path = "./../../00_labAndSampKeys/1_virScanData/sampleData/sampleMetaData.xlsx"
  # inputLibKeyPath = "./../../00_labAndSampKeys/1_virScanData/sampleData/inputLibKey.xlsx"
  #
  # table_name_samp = "enterSampleData"
  # table_name_ind = "enterIndividualData"
  # table_name_vs = "enterVirScanData"
  # table_name_libKey = "inputLibKeys"
  #
  # samplePath = NULL
  # individualPath = NULL
  # virScanPath = NULL
  # inputLibKeyPath = NULL
  #
  # remove_duplicates = TRUE
  # return_duplicates = TRUE

  


  allDat <-
    vs.gatherSampleMetaData(path = path,
                             table_name_samp = table_name_samp,
                             table_name_ind = table_name_ind,
                             table_name_vs = table_name_vs,
                             table_name_libKey = table_name_libKey,
                             samplePath = samplePath,
                             individualPath = individualPath,
                             virScanPath = virScanPath,
                             inputLibKeyPath = inputLibKeyPath,
                             remove_duplicates = remove_duplicates,
                             return_duplicates = return_duplicates)


  indInfo = sampInfo = virScanInfo = inputlibInfo = combined_input_libs =  NULL

  suppressWarnings(
    try(
      indInfo <- allDat$indData[, c("pi",
                                                      "study_name",
                                                      "individual",
                                                      "time_series",
                                                      "birth_cohort",
                                                      "age",
                                                      "sex",
                                                      "group",
                                                      "diagnosis",
                                                      "country",
                                                      "state",
                                                      "population",
                                                      "dob",
                                                      "height",
                                                      "weight",
                                                      "lab_lead",
                                                      "project_name")]))


  suppressWarnings(
    try(
      sampInfo <- allDat$sampData[ ,c("pi","study_name","individual","unique_sample_id",
                                                  "tube_id","time_series",
                                                  "time_point","collect_date",
                                                  "diagnosis","specimen_type",
                                                  "specimen_source",
                                                  "project_name","lab_lead",
                                                  "age", "original_tube_id")]))

  suppressWarnings(
    try(
      virScanInfo <- allDat$vsData[,c("pi",
                                                 "study_name",
                                                 "project_name",
                                                 "project_name2",
                                                 "unique_methods_long_id",
                                                 "fully_comparable_long_id",
                                                 "plate_name",
                                                 "lab_lead",
                                                 "input_id",
                                                 "input_name",
                                                 "input_full_description",
                                                 "amp_or_combined_date",
                                                 "dilution_other_change",
                                                 "protocol",
                                                 "assay_date",
                                                 "tube_id",
                                                 "individual",
                                                 "beads_only",
                                                 "library_sample",
                                                 "empty_sample",
                                                 "full_name",
                                                 "replicate_full_name",
                                                 "unique_sample_id")]))

  suppressWarnings(
     try(
       inputlibInfo <- allDat$libKey[,c("input_id",
                                        "n_libs_combined",
                                        "full_description",
                                        "input_name",
                                        "amp_or_combined_date",
                                        "combo_input_id_base1",
                                        "combo_input_id_base2",
                                        "combo_input_id_base3",
                                        "combo_input_id_base4")]))


  suppressWarnings(
    try(
      combined_input_libs <-
        vs.separateCombinedInput_ids(inputLibKey = inputlibInfo)))

  allCombined = NULL
  if(combine_all == TRUE &
     !is.null(virScanInfo) &
     !is.null(indInfo) &
     !is.null(sampInfo)){

    try(
      allCombined <-
      virScanInfo %>%
        dplyr::mutate(individual = as.character(individual)) %>%
      #joing virScanKey to individualsKey to get diagnosis - could add other things.
        left_join(indInfo %>%
                    dplyr::mutate(individual = as.character(individual)) %>%
                  dplyr::select(pi,
                                individual,
                                diagnosis1=diagnosis,
                                time_series1=time_series,
                                birth_cohort1 = birth_cohort,
                                age1 = age,
                                sex,
                                group,
                                country,
                                state,
                                population,dob),
                by = c("pi","individual")) %>% 
        dplyr::mutate(unique_sample_id = as.character(unique_sample_id)) %>% 
      #joing both to samples key to get unique time points, collect dates, etc.
      left_join(sampInfo %>%
                  mutate(unique_sample_id = as.character(unique_sample_id)) %>%
                  select(pi,
                         diagnosis2 = diagnosis,
                         age2 = age,
                         time_point,
                         collect_date,
                         specimen_type,
                         specimen_source,
                         original_tube_id,
                         unique_sample_id),
                by = c("pi","unique_sample_id")) %>%

      arrange(pi,study_name,individual,time_point) %>%
        unique() %>% 
        mutate(individual = ifelse(beads_only ==1,"beads",ifelse(library_sample ==1,"library",individual))) 
    )
  }

  if(return_duplicates){
    duplicates_individuals = allDat$ind_dups
    duplicates_samples = allDat$samp_dups
    duplicates_virScan = allDat$vs_dups
  } else {
    duplicates_individuals = NULL
    duplicates_samples = NULL
    duplicates_virScan = NULL
  }

  allSampsInDB = NULL
  if(return_allSamplsInDBInfo){
    allSampsInDB <- mmR::mm.findData(path = dataPath,
                                     colsToFind = virScanInfo$full_name,
                                     splitToList = FALSE)
  }



  return(list(allCombined = allCombined,
              individualsKey = indInfo,
              samplesKey = sampInfo,
              virScanKey = virScanInfo,
              inputLibKey = inputlibInfo,
              combined_input_libsKey = combined_input_libs,
              duplicates_individuals = duplicates_individuals,
              duplicates_samples = duplicates_individuals,
              duplicates_virScan = duplicates_individuals,
              allSampsInDB = allSampsInDB
              ))
}
