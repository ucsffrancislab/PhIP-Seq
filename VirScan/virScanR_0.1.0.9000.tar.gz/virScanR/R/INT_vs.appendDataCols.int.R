#------------------------------------------------------------------------------#
#Internal function
#------------------------------------------------------------------------------#
#' @importFrom magrittr %>%
vs.appendDataCols.int <- function(data,
                                  missingNames,
                                  valueToInsert){

  if(length(missingNames) == 0){

    print("No Missing Names Entered")
    return(data)

  } else {

    toAppend <-
      matrix(nrow = nrow(data),
             ncol = length(missingNames),
             data = valueToInsert) %>%
      data.frame()
    names(toAppend) <- missingNames
    return(cbind(data, toAppend) %>% dplyr::tbl_df())
  }

}
