#' Set up an example file structure for virScanR. 
#' 
#' Provides an initial file structure, complete with example templates for 
#' all of the needed or useful database set ups for using virScanR.
#' @param path The directory where to place the database directory/subdirectories
#' @importFrom magrittr %>%
#' @export
vs.start <-function(path = ".", dataBaseName = "virScan"){
  #path = "~/Desktop"
  if(mmR::mm.fileType(path) != "directory"){
    stop("Please set path to be a directory where you'd like the subdirectories to be built")
  }
  if(!dir.exists(path)){
    path = "."
  }

  topDir <- file.path(path,dataBaseName)
  topDir <- mmR::mm.quiet(mmR::mm.update_filename_if_existing(file = topDir),quiet = TRUE)

  vData <- file.path(topDir,"00_labAndSampKeys",paste0("1_",dataBaseName,"Data"))
  dir.create(file.path(vData,"counts"), recursive = TRUE)
  dir.create(file.path(vData,"meta"))
  dir.create(file.path(vData,"sampleData"))

  
  vir2 <- as.character(1:1000)
  vir3 <- as.character(1:1100)
  ZKV <- as.character(paste0("ZKV_",c(1:100)))
  A11 <- as.character(1:100)
  
  suppressWarnings(
    countsData <-
    data.frame(
      id = vir2,
      plate1.A1 = round(runif(n = 1000, min = 0, max = 200),digits = 0),
      plate1.A2 = round(runif(n = 1000, min = 0, max = 200),digits = 0),
      plate1.B1 = round(runif(n = 1000, min = 0, max = 200),digits = 0),
      plate1.B2 = round(runif(n = 1000, min = 0, max = 200),digits = 0)) %>% 
    
    dplyr::full_join(
    data.frame(
      id = c(vir3,ZKV),
      plate2.A1 = round(runif(n = 1200, min = 0, max = 200),digits = 0),
      plate2.A2 = round(runif(n = 1200, min = 0, max = 200),digits = 0),
      plate2.B1 = round(runif(n = 1200, min = 0, max = 200),digits = 0),
      plate2.B2 = round(runif(n = 1200, min = 0, max = 200),digits = 0),
      X13.A2 = round(runif(n = 1200, min = 0, max = 200),digits = 0),
      X14.H11 = round(runif(n = 1200, min = 0, max = 200),digits = 0),
      plate3.A1= round(runif(n = 1200, min = 0, max = 200),digits = 0),
      plate3.A2= round(runif(n = 1200, min = 0, max = 200),digits = 0),
      plate3.A3= round(runif(n = 1200, min = 0, max = 200),digits = 0)), 
    by = "id") %>%
  
  dplyr::full_join(
    data.frame(
      id = ZKV,
  plate5.A1= round(runif(n = 100, min = 0, max = 200),digits = 0),
  plate5.A2= round(runif(n = 100, min = 0, max = 200),digits = 0),
  plate5.A3= round(runif(n = 100, min = 0, max = 200),digits = 0)),
  by = "id") %>%
  
  dplyr::full_join(
    data.frame(
      id = A11,
      plate10.G7= round(runif(n = 100, min = 0, max = 200),digits = 0),
      plate10.G8= round(runif(n = 100, min = 0, max = 200),digits = 0),
      plate10.G9= round(runif(n = 100, min = 0, max = 200),digits = 0),
      plate10.G10= round(runif(n = 100, min = 0, max = 200),digits = 0)), 
    by = "id"))
  
  
  
  mmR::mm.fastwrite(countsData,
               path = file.path(vData,
                                "counts",
                                paste0("allCounts_",
                                       format(Sys.time(), "%y%m%d"),
                                       ".csv")))

  
  countsData <-
    data.frame(
      id = 1:100,
      plate72.A1 = round(runif(n = 100, min = 0, max = 200),digits = 0),
      plate72.A2 = round(runif(n = 100, min = 0, max = 200),digits = 0),
      plate72.A3 = round(runif(n = 100, min = 0, max = 200),digits = 0),
      plate72.A4 = round(runif(n = 100, min = 0, max = 200),digits = 0),
      plate72.A5 = round(runif(n = 100, min = 0, max = 200),digits = 0))

  mmR::mm.quiet(mmR::mm.fastwrite(data = countsData,
               path = file.path(vData,
                                "counts",
                                paste0("bacLib_counts_181104.xlsx"))))

  
  
  mmR::mm.quiet(
    toAddTo <- 
      vs.create_example_input_ids_key_db(
        path = file.path(vData)))
  
  Sys.sleep(time = 1.1)

  
  mmR::mm.quiet(vs.add_new_libraries_to_input_ids_key_db(
    current_ids_key_db_path = toAddTo,
    new_ids_vec_list = list(vir2,vir3,ZKV,A11),
    new_library_input_names = c("vir2","vir3","ZKV","A11"),
    overwrite_existing_input_name_col = FALSE,
    ids_col_name = "id",
    append_current_date_time = TRUE,
    replace_prior_date_time = TRUE,
    archiveExisting = TRUE,
    archiveWithCompression = TRUE,
    write_to_disk = TRUE))


  mmR::mm.quiet(
    vs.create_example_sampleMetaData(
      path = file.path(vData,"sampleData")))
  
  
  sprintf("Created new directories at %s",topDir)
}


