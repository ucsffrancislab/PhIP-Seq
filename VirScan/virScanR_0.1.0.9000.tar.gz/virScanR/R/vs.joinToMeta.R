#' A quick function to map some data with an 'id' column to the meta data or other
#'
#' @param data Some data - must have an "id" column to do the mapping
#'
#' @param path The path to the meta data. Could be a "sqlite" data base or csv
#'   or xls or xlsx.
#'
#' @param metaTable The name of the table inside the SQL database
#'
#' @param metaData If the metaData is already in R, you can just supply it here
#'   as a variable name. This should remain NULL if reading from outside R.
#'
#' @param metaSheet If the path leads to a xls or xlsx workbook, then this needs
#'   to be the name or the number of the worksheet inside the workbook
#'
#' @param metaCols Which columns to return from the meta data when joining
#'
#' @param idCol Which is the mapping variable. Defaults to "id"
#'
#'
#' @param type What is the type of the data base that the meta data is contained in.
#'
#'
#'
#' @importFrom magrittr %>%
#' @export
vs.joinToMeta <- function(data,
                          path = NULL,
                          metaTable = "meta",
                          metaData = NULL,
                          metaSheet = 1,
                          metaCols = c("id","Species"),
                          idCol = "id",
                          type = NULL){

  db = NULL

  if(!is.null(metaData)){

    meta <- metaData

  } else if(type == "SQLite"){

    db = virScanRSQL::sql.connect(path)
    meta = virScanRSQL::sql.connectTable(db, metaTable)

  } else if(type == "xlsx" |
            type == "xls" |
            (mmR::mm.stringEnd(path,3) %in%
             c("xls","lsx", "csv",".gz"))){

    meta <- mmR::mm.fastread(path = path,
                             xl_sheet = metaSheet,
                             header = TRUE)
  }


  return(
    data %>%
      left_join(

        meta %>%
          select(c(idCol,metaCols)) %>%

          {if (!is.null(db)) collect(.) else .} %>%

          tbl_df(),
        by = idCol))

  if(type == "SQLite"){
    virScanRSQL::sql.disconnect(db)
  }
}
