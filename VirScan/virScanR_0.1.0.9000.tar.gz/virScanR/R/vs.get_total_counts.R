#' Provides the total counts of each sample run, potentially joined to all of the sample data stored in keys from vs.getKeysList
#'
#' @param counts a data frame with all of the counts per sample
#' @param keys the keys list made from vs.getKeysList()
#' @param joinToKey whether to join the counts to the key
#' @param idCol what is the idCol (so it won't be summed). Default = "id".
#' @export
vs.get_total_counts <- function(counts,
                                keys = NULL,
                                joinToKey = TRUE,
                                idCol = "id"){
  if(idCol %in% names(counts)){
    totals <- apply(counts %>% select(-idCol), MARGIN = 2, FUN = sum, na.rm = TRUE)
  } else {
    totals <- apply(counts, MARGIN = 2, FUN = sum, na.rm = TRUE)
  }

  toReturn <- data.table::data.table(full_name = names(totals))
  toReturn[,count := totals]
  data.table::setkeyv(toReturn,cols = "count")
  data.table::setkey(toReturn, NULL)


  if(joinToKey & !is.null(keys)){
    return(toReturn %>%
             left_join(keys$allCombined, by = "full_name"))
  } else {
    return(toReturn)
  }
}
