#------------------------------------------------------------------------------#
#vs.setParam_collect_calc_VSData
#------------------------------------------------------------------------------#
#' Set paramateres for \link{vs.collect_calc_VSData}
#'
#' @param sampsDF DF: the samples DF - Must contain a column called "fullName" and a column called "replicate_fullname". This is most easily retrived using \code{\link{vs.setParams_sampsDF}}.
#'
#' @param path STRING: The path to the SQL database to collect the samples
#'
#' @param counts_table STRINGs: names of the tables to look in for counts
#'  @param pVals_table pvalues (i.e. from a different pipeline, or if already saved and just trying to retreive them... etc)
#'
#' @param inputLib_table
#'the inputLib_table that is used for grouping the enrichment groups together. This should be a table of input libraries. Or, if want to just give
#'
#' @param pVals_table STRING: name of table to retreive p Values
#'
#' @param inputLib_table STRING
#'
#'
#'
#'
#' @importFrom magrittr %>%
#' @export
vs.setParam_collect_calc_VSData <-
  function(sampsDF = NULL, #the Samples DF... from vs.makeSampsDF
           path = NULL,

           counts_table = "allCounts", #which counts table in SQL to look in

           pValsDB_path = NULL, #path to the pVal. Keep as NULL if same as counts
           pVals_table = "pValInputLibCombined", #which pVal table

           inputLibDB_path = NULL, #path to input Lib DB. keep as null if same as counts Path
           inputLib_table = "inputLibs", #which inputLib table to look for input Lib
           inputLib_colName = "inputCombined", #which input library to calculate enrichment
           newInputLibDF = NULL, #alternatively, can supply your own input Library

           ids = NULL, #which virScan or other 'ids' to capture?

           minCountsForFailure = 2e5, #minimum number of counts for a sample to be considered failed run
           removeFailed = TRUE, #should the failed runs be removed

           pThresh = 2.3, #only for the python pValues (likely deprecated soon)
           pThreshEnrich = 0.005,

           combineConservatively = TRUE,
           calculateEnrichments = TRUE, #should fold enrichments be calculated
           calculateEnrichmentByChunks = TRUE, #if so, should it use chunks
           calculateEnrichmentsStaggered = FALSE, #should a second set of
           #staggered chunks also be
           #calculated? These are 50%
           #overlapped chunks, to ensure
           #we're not getting a bias of
           #hits at the higher end of
           #each chunk.
           combineStaggeredHits = TRUE,
           removeUncombinedHits = TRUE,
           groupSize = 600, #the chunk size to use for grouping enrichment calculations
           returnGroupedIDs = TRUE,
           propExtremesToRemove = .1, #when fitting the distribution to
           #calculate P-values for a given
           #chunk - can remove the extreme
           #tails to not bias the distribution
           #with outliers.

           convertZeroInput_To = NULL, #converts any input counts of zero to this value.
           convertZeroCounts_To = NULL, #Same but for actual counts (i.e. .001)

           returnHits = TRUE, #Should python Hits be returned (using pThresh)
           returnEnrichHits = TRUE, #Same but for hits from enrichments

           returnSplitEnrichHits = FALSE,
           returnSplitHits = FALSE,

           returnIDsWithHits = FALSE, #Return a DF with the IDs with python Hits
           returnBackgroundCounts = TRUE, #return a DF of counts for IDs that
           #none of the samples had a hit for.
           #Useful for normalizing procedures
           pThreshForBackground = 1.5, #What -log10(pValue) should be considred
           #a definite non-hit" for the background
           #counts


           returnSplitCounts = TRUE, #should two similar counts dataframes be
           #returned, one for each replicate
           returnSplitPVals = TRUE,  #Same, but for python Pvalues
           returnSplitEnrichments = TRUE, #same but for the enrichments
           returnSplitEnrichmentsLn = TRUE,
           returnSplitEnrichPVal = TRUE,


           returnCountsAll = FALSE, #should all the counts be returned in a single DF
           returnPValsAll = FALSE, #same but for PVals

           returnEnrichmentsAll = FALSE, #same but for Enrichment
           returnEnrichmentsLnAll = FALSE,
           returnEnrichPValAll = FALSE,

           returnEnrichMetrics = FALSE, #Should the enrichment Metrics be returned.
           #Returns as a single dataframe per sample, and with one row per ID...
           #so very expensive!


           returnBinomPValsAll = FALSE, #Should a DF with all the samples python
           #pValues be returned, but  with 0's and 1's instead of the actual
           #python pValues. returnHits does something similar, but only returns
           #the first replicate, and with a 1 if both replicates were hits, or
           #zero if either was zero.

           returnSplitBinomPVals = FALSE,

           returnEnrichHitsAll = FALSE, #Same as above but for enrichments
           returnCountsNonHitsZero = FALSE,
           showDefaults = FALSE){ #Return a data frame with all of the
    #counts, but with all of the non-hits (based on python P-values) are set
    #to zero.

    if(is.vector(sampsDF)){
      sampsDF <- data.frame("full_name" = sampsDF)
    }


    paramsList <-
      list(sampsDF = sampsDF,
           path = path,
           counts_table = counts_table,

           pValsDB_path = pValsDB_path,

           pVals_table = pVals_table,
           inputLibDB_path = inputLibDB_path,


           inputLib_table = inputLib_table,
           inputLib_colName = inputLib_colName,
           newInputLibDF = newInputLibDF,

           ids = ids,

           minCountsForFailure = minCountsForFailure,
           removeFailed = removeFailed,
           pThresh = pThresh,
           pThreshEnrich = pThreshEnrich,
           calculateEnrichments = calculateEnrichments,
           calculateEnrichmentByChunks = calculateEnrichmentByChunks,
           calculateEnrichmentsStaggered = calculateEnrichmentsStaggered,
           combineConservatively = combineConservatively,
           combineStaggeredHits = combineStaggeredHits,
           removeUncombinedHits = removeUncombinedHits,
           groupSize = groupSize,
           returnGroupedIDs = returnGroupedIDs,
           propExtremesToRemove = propExtremesToRemove,
           convertZeroInput_To = convertZeroInput_To,
           convertZeroCounts_To = convertZeroCounts_To,
           returnHits = returnHits,
           returnEnrichHits = returnEnrichHits,
           returnSplitEnrichHits = returnSplitEnrichHits,
           returnSplitHits = returnSplitHits,

           returnIDsWithHits = returnIDsWithHits,
           returnBackgroundCounts = returnBackgroundCounts,
           pThreshForBackground = pThreshForBackground,


           returnSplitCounts = returnSplitCounts,
           returnSplitPVals = returnSplitPVals,

           returnSplitEnrichments = returnSplitEnrichments,
           returnSplitEnrichmentsLn = returnSplitEnrichmentsLn,
           returnSplitEnrichPVal = returnSplitEnrichPVal,

           returnCountsAll = returnCountsAll,
           returnPValsAll = returnPValsAll,

           returnEnrichmentsAll = returnEnrichmentsAll,
           returnEnrichmentsLnAll = returnEnrichmentsLnAll,
           returnEnrichPValAll = returnEnrichPValAll,
           returnEnrichMetrics = returnEnrichMetrics,

           returnBinomPValsAll = returnBinomPValsAll,
           returnSplitBinomPVals = returnSplitBinomPVals,

           returnEnrichHitsAll = returnEnrichHitsAll,
           returnCountsNonHitsZero = returnCountsNonHitsZero)









    if(showDefaults == TRUE){

      newDF <- data.frame(arg = matrix(nrow = length(paramsList)))

      rownames(newDF) <- names(paramsList)

      for(i in 1:nrow(newDF)){

        if(is.null(paramsList[[i]])) {
          newDF[i,1] <- "NULL"
        } else {
          newDF[i,1] <- paramsList[[i]]
        }
      }
      return(newDF)
    } else {
      return(paramsList)
  }
}




