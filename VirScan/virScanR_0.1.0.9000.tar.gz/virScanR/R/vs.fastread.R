#------------------------------------------------------------------------------#
#vs.fastread2
#------------------------------------------------------------------------------#
#' Read in a virScan data from SQL, csv, gz, xls, xlsx
#'
#' ses \code{\link{mmR::mm.fastread}} to read in a .gz or a .csv file. It
#' automatically detects what type of database it is and pulls the data. This
#' differs from mmR::mm.fastread only in that it expects an "id" column and has
#' a couple of other virScan related arguments.
#'
#' @family database connections
#'
#' @param path String: The path to the .gz or .csv file, including the name plus
#'   extension
#' @param table Table or number of the table to collect - only used if path
#'   leads to a SQL DB or the table name or numer to collect from if this is an
#'   Excel workbook
#'
#' @param xl_sheet Like \code{table} can be a string or a sheet number of the
#'   actual worksheet in an excel file. If path leads to a SQL DB and xl_sheet
#'   is specified but table remains \code{NULL} then this will specificy which
#'   table to pull from the SQL DB
#'
#' @param header Should the first row of the data be the column names. Defaults
#'   to TRUE. Only used for file types of csv, csv.gz, xls, xlsx
#'
#' @param nrows,allRows,specificRows Number of rows to return, or allRows.
#'   Default is to return all rows unless nrows is specified. If specificRows is
#'   specified, then it will pull specific rows.
#'
#' @param ids Alternatively, instead of submitting nrows, allRows, rows, could
#'   submit a column of ids of interest. There must be an "id" column in the
#'   data set to use this. Good if only interested in a few IDs or some subset
#'   of interest.
#'
#' @param sampsDF,columns Which columns from the data frame to retrieve. If
#'   sampsDF, then must be a data frame with at least a column called 'full_name'
#'   or it will look for the first column. Else, input which columns are
#'   requested using columns and leaving sampsDF NULL. columns is a Vector of
#'   specific columns to return. Will only return those columns that exist.
#'
#' @param return_id_col Defautls to TRUE. Should the ID column be returned
#'   assuming it exists. If so, it will be returns as the first column.
#'
#' @param returnColsNotAvailable Should any columns that are requested but not
#'   available in the data set be returned. If so, will return as the second
#'   element of a list with the name columns_not_available
#'
#' @param preserveSpecificRowOrder Should the row order if using specificRows be
#'   preserved. Can be a bit slower. Default is FALSE and will give them in
#'   numeric order of rows.
#'
#' @param type The type of file to be found at \code{path}. Not necessary but
#'   can be helpful if getting errors regarding the type of dataset.. Options
#'   are: "SQLite","csv","xls","xlsx",gz
#'
#' @return Returns the read in data. If \code{returnColsNotAvailable = TRUE}
#'   then it will will return a list, with the second element being a vector of
#'   the columns not available. Otherwise, it will return a data frame.
#'
#' @examples
#' \dontrun{
#' myData <- mm.fastread(path = "./my.csv")
#' myData2 <- mm.frastread(path = "my.csv.gz")
#' myData3 <- mm.fastread(path = "my.csv.gz", as.data.frame = TRUE)
#' myData3 <- mm.fastread(path = "my.csv.gz", as.data.table = TRUE)
#' myData4 <- mm.fastread(path = "./../../00 labAndSampKeys/SQLdatabases/virScanData.sqlite", table = "meta",nrows = 7, as.data.frame= TRUE)
#' }
#' 
#'
#' @inheritParams mmR::mm.fastread2
#'
#' @importFrom magrittr %>%
#' @export
vs.fastread <- function(path,
                        table = NULL,
                        xl_sheet = 1,

                        sampsDF = NULL,
                        ids = NULL,
                        return_id_col = TRUE,

                        header = TRUE,
                        nrows = NULL,
                        allRows = TRUE,
                        specificRows = NULL,
                        columns = NULL,
                        preserveSpecificRowOrder = FALSE,
                        returnColsNotAvailable = FALSE,
                        type = NULL,
                        search = FALSE,
                        includeSubDirectories = TRUE,
                        returnOnlyFirstInstance = TRUE,
                        keyColumn = "id",
                        ...){

  #if sampsDF is input instead of columns, get columns to grab from the sampsDF
  if(!is.null(sampsDF) & is.null(columns)) {
    if("full_name" %in% names(sampsDF)){
      columns <- sampsDF$full_name
    } else {
      columns <- sampsDF[,1]
    }
  }


  columns <- unique(columns)
  #---------------------------------------------------------------------------#
  #IF type is xls or xlsx
  #---------------------------------------------------------------------------#

  toReturn <- mmR::mm.fastread2(path = path,
                          table = table,
                          xl_sheet = xl_sheet,
                          header = header,
                          nrows = nrows,
                          allRows = allRows,
                          specificRows = specificRows,
                          columns = columns,
                          preserveSpecificRowOrder = preserveSpecificRowOrder,
                          returnColsNotAvailable = TRUE,
                          type = type,
                          ids = ids,
                          search = search,
                          includeSubDirectories = includeSubDirectories,
                          returnOnlyFirstInstance = returnOnlyFirstInstance,
                          keyColumn = keyColumn,
                          combineAll = TRUE)


    if(returnColsNotAvailable == TRUE){

        columns_not_available <- toReturn$columns_not_available
        if(keyColumn %in% columns_not_available){
          stop(paste0(keyColumn,"column not found in table. vs.fastread() requires 'id' or the specified keyColumn"))
        }
        toReturn <- toReturn$table_list

    } else if(returnColsNotAvailable == FALSE){

      allColNames <- vector()
      for(i in 1:length(toReturn)){
        allColNames <- unique(c(allColNames,names(toReturn[[i]])))
      }

      if(!keyColumn %in% allColNames){
        stop(paste0(keyColumn," column not found in 1 or more tables from which data was pulled. vs.fastread() requires an 'id' column or the specified keyColumn"))
      }
    }



  toReturnFinal <- toReturn[[1]]
  if(length(toReturn) > 1){

    idIndex <- which(colnames(toReturn[[1]]) == keyColumn)
    names(toReturn[[1]])[1] <- "id"
    if(!is.null(ids)){
      toReturn[[1]] <- toReturn[[1]][which(toReturn[[1]]$id %in% ids), ]
    }
    toReturnFinal <- toReturn[[1]] %>% dplyr::mutate(id = as.character(id))

    for(i in 2:length(toReturn)){

      idIndex <- which(colnames(toReturn[[i]]) == keyColumn)
      names(toReturn[[i]])[1] <- "id"
      if(!is.null(ids)){
        toReturn[[i]] <- toReturn[[i]][which(toReturn[[i]]$id %in% ids), ]
      }

      toReturnFinal <-
        toReturnFinal %>%
        full_join(toReturn[[i]] %>% dplyr::mutate(id = as.character(id)),
                  by = "id")
    }
  } else {
    if(!is.null(ids)){
      toReturnFinal <- toReturnFinal[which(toReturnFinal$id %in% ids), ]
    }
  }





  if(!return_id_col & ncol(toReturnFinal) > 1) {
    if(keyColumn %in% colnames(toReturnFinal)) {
      idIndex <- which(colnames(toReturnFinal) == keyColumn)
      toReturnFinal <- toReturnFinal[ ,-idIndex]
    }
  }

  if(returnColsNotAvailable == TRUE){

    return(list(table = toReturnFinal,
                columns_not_available = columns_not_available ))

  } else {

    return(toReturnFinal)

  }

}




