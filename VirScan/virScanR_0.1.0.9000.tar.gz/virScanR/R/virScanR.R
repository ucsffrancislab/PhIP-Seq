#' virScanR: A package for maintaining and analyzing virScan Data..
#'
#' The virScan package provides three categories of important functions:
#' data preparation, data processing and deep learning.
#'
#' @section virScanR functions:
#' The virScanR functions are intended to.
#'
#' @docType package
#' @name virScanR
NULL
