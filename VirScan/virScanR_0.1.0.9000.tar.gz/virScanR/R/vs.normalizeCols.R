#' Normalizes counts columns so that they are all roughly the same counts.
#'
#' @param data Data.table or data.frame that contains counts or some other data
#'   that requires normalization. Any columns to not evaluate can be input as a
#'   vector with \code{cols_to_not_evaluate} or if only wanting to normalize a
#'   subset of the columns can just input \code{cols_to_evaluate}. Either way,
#'   will return the full data but with just those columns specified (or not
#'   specified) normalized to the max column of the group.
#'
#' @param cols_to_evaluate,cols_to_not_evaluate Which colums to or to not
#'   evaluate.
#' @param normalize_to Should the data be normalized such that each column sums
#'   to the \code{"max","min"} or \code{"mean"} column or to a value such as
#'   100000. if an integer is provided, then all columns will be made to sum to
#'   that value, else will expect "max","min",or "mean". Defaults to "mean".
#'
#'
#' @param round,digits Should the resulting data be rounded (DEFAULT) and if so,
#'   what digits (DEFAULT = 0).
#'
#' @param quantiles,allCounts,countsPer The quantiles over which to normalize.
#'   This helps to remove outliers. Default is c(0.5,0.75)... ie the 3rd
#'   quantile. might want to change this. Should be a vector. If
#'   \code{allCounts} is set to TRUE, then will not use quantiles and will use
#'   the sum of the full column. \code{countsPer} If the columns should all end
#'   up a certain count number - i.e. if countsPer 100000 will mean that each
#'   count will be counts per countsPer.
#'
#'
#' @param normalizeTo Should data be normalized to the mean of all the columns,
#'   the min or the max. Must specify one of: \code{"mean"}, \code{"max"}
#'   (DEFAULT) or  \code{"min"}. Which portion of the columns is specified using
#'   the \code{quantiles} argument.
#'
#' @return Returns all of the data, in the same column order, but with some or
#'   all of the columns normalized so that they all have the same counts as the
#'   max counts column.
#' @export
vs.normalizeCols <- function(data,
                             cols_to_evaluate = NULL,
                             cols_to_not_evaluate = NULL,
                             round = TRUE,
                             digits = 0,
                             quantiles = c(0.5,0.75),
                             normalizeTo = "max",
                             allCounts = FALSE,
                             countsPer = NULL,
                             parallel = TRUE,
                             cores = NULL,
                             showProgress = TRUE,
                             ...){

  # data <- data.frame(id = as.character(c(1:1e4)),x = runif(n = 1e4,min =0,max = 1000), y = 1.3*runif(n = 1e4,min =0,max = 1000),z = 2*runif(n = 1e4,min =0,max = 1000))
  # # data <- data.table::copy(counts)[[1]]
  # cols_to_evaluate = NULL
  # cols_to_not_evaluate = "id"
  # round = TRUE
  # digits = 0
  # quantiles = c(0.5,0.75)
  # allCounts = FALSE
  # countsPer = 1e6

  whatClass <- class(data)[1]

  if(whatClass != "data.table"){
    data <- data.table::data.table(data)
  }


  originalColOrder <- names(data)
  noEvalVec <- vector()
  if(!is.null(cols_to_not_evaluate)){
    noEvalVec <- cols_to_not_evaluate[which(cols_to_not_evaluate %in% names(data))]
  }

  if(!is.null(cols_to_evaluate)){
    noEvalVec <- unique(c(noEvalVec,
                          originalColOrder[which(!originalColOrder %in% cols_to_evaluate)]))

  }

#data[,input := id]
  if(length(noEvalVec)>0){
    dataNoEval <- data.table::copy(data) %>% select(noEvalVec)
    dataEval <- originalColOrder[which(!originalColOrder %in% names(dataNoEval))]
    dataEval <- data.table::copy(data) %>% select(dataEval)
  } else {
    dataEval <- data.table::copy(data)[.dataEval]
  }



  #convert a column.....
    # for (k in cols) {set(dataEval2,
    #                     j = k,
    #                     value =
    #                       quantile(dataEval[[k]],
    #                                probs = c(quantiles[1],
    #                                          quantiles[2]),
    #                                na.rm = TRUE)
    #                     )}

  if(allCounts == TRUE){
    dataSum =
      data.table::copy(dataEval)[ ,
                                  lapply(.SD,
                                         sum,
                                         na.rm = TRUE)]
  } else {
    #summarize a column
    #Function to sum over quantiles
    sumQuantiles <- function(X, quantiles){

      quants <- quantile(X,probs = quantiles, na.rm = TRUE)
      sum(X[which(X >= quants[1] & X <= quants[2])])

      #X[which(X>=quants[1] & X<= quants[2])] <- 0
      #return(X)
    }

    if(parallel &
       (requireNamespace(package = "parallel")==TRUE)){
      if(is.null(cores)) cores = parallel::detectCores()
      dataSum =
        data.table::copy(dataEval)[ ,
                                    parallel::mclapply(.SD,
                                                       sumQuantiles,
                                                       quantiles = quantiles,
                                                       mc.cores = cores)]
    } else {
      dataSum =
        data.table::copy(dataEval)[ ,
                                    lapply(.SD,
                                           sumQuantiles,
                                           quantiles = quantiles)]
    }

  }

  print(paste0("summed columns after trimming to: ", paste(quantiles,collapse = ",")))

  if(normalizeTo=="mean"){
    normalizeToThis <- mean(t(dataSum)[,1], na.rm = TRUE)
  } else if(normalizeTo == "max"){
    normalizeToThis <- max(t(dataSum)[,1], na.rm = TRUE)
  } else if(normalizeTo == "min"){
    normalizeToThis <- min(t(dataSum)[,1], na.rm = TRUE)
  } else if(normalizeTo == "med"){
    normalizeToThis <- median(t(dataSum)[,1], na.rm = TRUE)
  } else {
    normalizeToThis <- median(t(dataSum)[,1], na.rm = TRUE)
  }

  dataNormalizer <- normalizeToThis/dataSum
  print("Finished Calculating Normalizers")

  InfToNA <- function(X){
    X[which(X == "inf")] <- NA
    return(X)
  }



  if(parallel &
     (requireNamespace(package = "parallel")==TRUE)){
    if(is.null(cores)) cores = parallel::detectCores()

    dataEval =
      data.table::copy(dataEval)[ ,
                parallel::mclapply(.SD,
                                   InfToNA,
                                   mc.cores = cores)]
  } else {
    #just a different way to do this without using lapply... keeping for reference
    #cols <- names(dataEval)
    #for (j in cols) data.table::set(dataEval, j = j, value = InfToNA(dataEval2[[j]]))
    dataEval
      dataEval[ , lapply(.SD, InfToNA)]
  }


  normalizerFxn <- function(X,normalizer,countsPer,round,digits){
    col <- colnames(normalizer)
    X <- X*normalizer

    if(!is.null(countsPer)){
      divide <- sum(X, na.rm = TRUE)
      if(!round){
        return(countsPer * X / divide)
      } else {
        return(round(countsPer * X / divide,digits = digits))
      }
    } else {
      if(!round){
        return(X)
      } else {
        return(round(X,digits = digits))
      }
    }
  }

  ######
  dataEvalKeep <- data.table::copy(dataEval)
  #dataEval2 <- data.table::copy(dataEval)
  #dataEval <- data.table::copy(dataEval2)
  ######


  cols <- names(dataEval)
  "Normalizing All Columns Specified"

  if(showProgress == TRUE & requireNamespace(package = "parallel") == TRUE){

    try(
      pb <- utils::txtProgressBar(0,length(cols),style=3))
      #progress::progress_bar$new(
      #  format = "Normalizing :what [:bar] :percent eta: :eta",
      #  clear = TRUE, total = length(cols), width = 60),silent = TRUE)
  }



  for (X in 1:length(cols)) {
    j = cols[X]

    data.table::set(dataEval,
                    j = j,
                    value = normalizerFxn(dataEval[[j]],
                                          dataNormalizer[,get(j)],
                                          countsPer = countsPer,
                                          round = round,
                                          digits = digits))

    #if(showProgress == TRUE){print(paste0("normalizing", j))}
    if(showProgress == TRUE & requireNamespace(package = "parallel") == TRUE){
      #try(pb$tick(tokens = list(what = j)),silent = TRUE)
      #Sys.sleep(.1 / 100)
      #setTxtProgressBar(pb, i)
      setTxtProgressBar(pb, X)
    }
  }



  if(length(names(dataEval)) < length(names(data))){
    toReturn <-
      data.table::data.table(
        data.frame(
          cbind(dataNoEval,dataEval)))
  } else {
    toReturn <- dataEval
  }

  toReturn <- toReturn %>% select(originalColOrder)

  if(whatClass %in% c("tbl_df","tbl","tibble","data_frame")){
    return(dplyr::tbl_df(toReturn))
  } else if(whatClass == "data.frame"){
    return(as.data.frame(toReturn))
  } else {
    return(toReturn)
  }

}






