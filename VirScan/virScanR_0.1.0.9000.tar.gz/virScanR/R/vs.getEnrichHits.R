#------------------------------------------------------------------------------#
# RETURNS enrichment hits from the two replicates
# SDs = 2 gives mean(enrichment) + SDs * sd(enrichment) for a given group
#------------------------------------------------------------------------------#
#' Essentially a shortcut to run vs.getEnrichHitsAll and vs.getHits
#' @param enrichments Data frame of fold-enrichments, with "id" and "input" as
#'   first two columns. Usually the output "enrichments" from
#'   \code{\link{vs.calc_enrichment.int}} or \code{\link{vs.calc_enrichment_chunks}}

#'
#' @inheritParams vs.calc_enrichment_chunks
#'
#' @param groupSize This must be the same group_size as was used to run
#'   \code{\link{vs.calc_enrichment_chunks}}.
#' @param staggerChunk This must be set to be the same as when
#'   \code{\link{vs.calc_enrichment_chunks}} was called
#'
#' @param SDs How many standard deviations from the mean to consider significant
#'
#' @param replicateNamesDF a data frame with columns rep1, rep2 with the each
#'   with the sample name and the replicate name. It's used to make sure that
#'   the columns being compared are in fact appropriate. This is most easily
#'   made with \code{\link{vs.gatherReplicateNames}}.
#'
#' @param alreadyBinomial Can pass in the enrichments themselves, or can pass in
#'   the binomial data and under enrichments and this function  will simply take
#'   it and run \code{\link{vs.getHits}} with alreadyBinomial == TRUE
#'
#' @return If alreadyBinomial == FALSE, will return a list of 3 elements, hits,
#'   enrichHitsBinom, and enrichHitsMetrics. If \code{alreadyBinomial} == TRUE,
#'   then this will just return the output of \code{vs.getHits}... which is just
#'   the binomial data - with the first two columns being "id", "input"
#'
#'
#' @importFrom magrittr %>%
#' @export
vs.getEnrichHits <- function(enrichments,
                             groupSize = 600,
                             staggerChunk = FALSE,
                             SDs = 2,
                             replicateNamesDF,
                             alreadyBinomial = FALSE,  #if already Binomial data
                             ...
){

  if(alreadyBinomial == FALSE){
    enrichHitsAll <- vs.getEnrichHitsAll(enrichments, #Defined Below
                                         groupSize=groupSize,
                                         SDs = SDs,
                                         staggerChunk = staggerChunk)
    enrichments = enrichHitsAll[["enrichHitsBinom"]]

  }

  #use vs.getHits but use enrichments instead of pVals and set already
  #Binomial to TRUE
  hitsToReturn <- vs.getHits(pVals = enrichments,
                             replicateNamesDF = replicateNamesDF,
                             alreadyBinomial = TRUE) %>%
    dplyr::tbl_df()


  if(alreadyBinomial == FALSE){
    return(list(hits = hitsToReturn,
                enrichHitsBinom = enrichHitsAll[["enrichHitsBinom"]],
                enrichMetrics = enrichHitsAll[["enrichMetrics"]]))
  } else {
    return(list(hits = hitsToReturn))
  }

}





#------------------------------------------------------------------------------#
# vs.getEnrichHits
# combines the above two functions and returns the hits matrix in the
# same order as the enrichment IDs... this will not try to assess
# whether both replicates were hits - but just gives binomial responses
# for each column
#------------------------------------------------------------------------------#
#' @importFrom magrittr %>%
#' @export
vs.getEnrichHitsAll <- function(enrichments,
                                groupSize = 600,
                                SDs = 2,
                                staggerChunk = FALSE){

  #a= Sys.time()
  hitsListComplete <-
    parallel::mclapply(X = 1:(length(names(enrichments))-2),
                       FUN = vs.internal.enrichHitsFxn, #defined below
                       enrichments = enrichments,
                       groupSize = groupSize,
                       SDs = SDs,
                       staggerChunk = staggerChunk,
                       mc.cores = parallel::detectCores()-1,
                       ...)
  #
  #b = Sys.time() - a
  hitsList <- enrichMetrics <- list()
  for(q in 1:length(hitsListComplete)){
    hitsList[[q]] <- NA
    enrichMetrics[[q]] <- NA
  }

  for(q in 1:length(hitsListComplete)){
    hitsList[[q]] <- hitsListComplete[[q]][[1]]
    enrichMetrics[[q]] <- hitsListComplete[[q]][[2]]
    hitsListComplete[[q]] = NA
  }



  if(length(hitsList)>1){
    for(p in 2:length(hitsList)){
      #only start at 2 to keep the id col from the first element
      hitsList[[p]] <- hitsList[[p]] %>% dplyr::select(-id)
    }
  }

  toReturn <- dplyr::bind_cols(hitsList)

  for(z in 2:ncol(toReturn)){
    naIndex_z <- which(is.na(toReturn[,z]))
    toReturn[naIndex_z,z] <- 0
  }

  return(list(enrichHitsBinom = toReturn,
              enrichMetrics = enrichMetrics))  #JUST MADE THIS LIST OF TWO
}






#------------------------------------------------------------------------------#
# vs.internal.enrichHitsFxn
# used above in the mclapply statement
#------------------------------------------------------------------------------#
#' Internal Function for parallelizing vs.getEnrichHits
#' @importFrom magrittr %>%
#'
vs.internal.enrichHitsFxn <- function(X,
                                      enrichments,
                                      groupSize = 600,
                                      SDs = 2,
                                      staggerChunk = FALSE, ...){

  #enrichments = data$enrichSplit[[1]][,c(1:4)]
  #pVals = data$pValsSplit[[1]][c(1:3)]
  #X=1
  #staggerChunk = FALSE
  col = names(enrichments)[-c(1:2)][X]
  temp <-
    vs.internal.getEnrichHits.setup1(col = col, #Defined Below
                                     enrichments = enrichments,
                                     groupSize = groupSize,
                                     staggerChunk = staggerChunk)
  hitOrNot_and_metrics <-
    enrichments %>%
    dplyr::select(id) %>%
    dplyr::left_join(
      data.table::rbindlist(

        lapply(X = temp$groups,
               FUN = vs.internal.getEnrichHits.setup2, #Defined Below
               SDs = SDs,
               temp2 = temp$temp)
        #mc.cores = detectCores()-1)
      ), by = "id")

  toReturn <-
    hitOrNot_and_metrics %>%
    dplyr::select(id, hit)

  names(toReturn) <- c("id",col)

  toReturnMetrics <- hitOrNot_and_metrics %>%
    dplyr::mutate(sigLimit = avgLnEnrich + SDs * sdLnEnrich) %>%
    dplyr::mutate(sample = col)

  return(list(toReturn = toReturn, toReturnMetrics = toReturnMetrics))
  #print(paste("done with: ", col))
}





#------------------------------------------------------------------------------#
# vs.internal.getEnrichHits.setup1
#------------------------------------------------------------------------------#
# Used above in vs.internal.enrichHitsFxn
# SET UP Fxn for vs.getEnrichHits
# This requires a column name that exists in both enrichments and pVals
# enrichments dataframe (i.e. data[["enrichments"]])
# pVals dataframe (i.e. data[["pVals"]])
# and a group size for the number of epitopes that are in each bin
#------------------------------------------------------------------------------#
#' @importFrom magrittr %>%
vs.internal.getEnrichHits.setup1 <- function(col,
                                             enrichments,
                                             groupSize = 600,
                                             staggerChunk = FALSE,
                                             ...){
  temp1 <-
    enrichments %>%
    dplyr::select(id, input, col) %>%
    dplyr::arrange(input) %>%
    dplyr::mutate(group =
                    sort(
                      rep(c(1:round(nrow(enrichments)/groupSize,digits = 0)),
                          length = nrow(enrichments))))


  if(staggerChunk == TRUE){
    temp3 <- temp1
    halfGroup = round(groupSize/2, digits = 0)
    temp3$group <-
      c(rep(0,halfGroup), temp1$group[1:(length(temp1$group)-halfGroup)])
    temp1 <- temp3
  }

  names(temp1 <- c("id","input","enrich","group"))

  temp2 <-
    temp1 %>%
    dplyr::filter(input>0,enrich>0) %>%
    dplyr::mutate(lnEnrich = log(enrich))


  return(list(temp = temp2,
              groups = unique(temp2$group)))#,
  #enrichments = enrichments))
}




#------------------------------------------------------------------------------#
# vs.internal.getEnrichHits.setup2
# used above in vs.internal.enrichHitsFxn
# Actually calculates the p-values.
# getEnrichHits - this is the function that looks at the enrichments
# bins them and gets potential hits based on mean + 3*sd of the ln(enrichment)
# in a given bin
#------------------------------------------------------------------------------#
#' Internal function to calculate the p-values
#'
#' @importFrom magrittr %>%
vs.internal.getEnrichHits.setup2 <- function(X, temp2,
                                             SDs = 2){

  temp <- temp2 %>% dplyr::filter(group == X)


  avgLnEnrich = mean(temp$lnEnrich, na.rm = TRUE)
  sdLnEnrich = stats::sd(temp$lnEnrich, na.rm = TRUE)

  CISD = avgLnEnrich + SDs * sdLnEnrich

  temp <-
    temp %>%
    dplyr::mutate(hit = ifelse(lnEnrich >= CISD,1,0)) %>%
    dplyr::mutate(avgLnEnrich = avgLnEnrich, sdLnEnrich = sdLnEnrich) %>%
    dplyr::mutate(prob = pnorm(lnEnrich,
                               mean = avgLnEnrich,
                               sd = sdLnEnrich,
                               lower.tail = FALSE))


  return(temp)
}
