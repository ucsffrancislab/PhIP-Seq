#------------------------------------------------------------------------------#
#Reverse hits to make non hits 1s.
#this is good, for example, when trying to get backgrounds and such
#------------------------------------------------------------------------------#
#' A simple function to reverse zeros and 1s
#'
#' This function will only change values that are zeros or ones. So if a column
#' is not comprized of zeros or ones it won't be changed (except any zeros and
#' ones that it does contain)
#'
#' @param hitsDF a data frame with at least some columns that are zero and ones
#'
#' @param nonSampleCols Columns that should not be converted such as ID columns.
#'
#'
#' @examples
#' #' #Note: only samp2 and 3 will be reversed here.
#' #Samp 1 is not reversed because it is specified under nonSampleCols
#' #Samp4 is not reversed because it is not a binomial column
#'
#' set.seed(1001)
#' myDat <-
#'   data.frame(id = c(1:20)) %>%
#'   mutate(input = id*4) %>%
#'   mutate(
#'   samp1 = round(runif(n = nrow(.),0,1),digits = 0),
#'   samp2 = round(runif(n = nrow(.),0,1),digits = 0),
#'   samp3 = round(runif(n = nrow(.),0,1),digits = 0),
#'   samp4 = runif(n = nrow(.),0,1))
#'
#'   vs.reverseHits(myDat, nonSampleCols = c("id","input","samp1"))
#' @export
vs.reverseHits <- function(hitsDF,
                           nonSampleCols = c("id","input")){


  addedID = FALSE
  if(length(which(names(hitsDF) %in% nonSampleCols))==0){
    hitsDF <- cbind("tempID" = rep(1,nrow(hitsDF)), hitsDF)
    nonSampleCols = "tempID"
    addedID = TRUE
  }


  allNames <- names(hitsDF)
  sampNames <- allNames[which(!names(hitsDF) %in% nonSampleCols)]
  changeFxn <- function(vec) {ifelse(vec ==1,0,ifelse(vec ==0,1,vec))}


  idCols <- data.frame(hitsDF[,nonSampleCols])
  names(idCols) <- nonSampleCols


  toReturn <-
    data.frame(
      cbind(
        idCols,
        apply(X = hitsDF[,sampNames],
              MARGIN = 2,
              FUN = changeFxn
              )
      )
    )[,allNames]

  if(addedID == TRUE){
    toReturn <- toReturn[,-1]
  }
  return(toReturn)
}


 # set.seed(1001)
 # myDat <-
 #   data.frame(id = c(1:20)) %>%
 #   mutate(input = id*4) %>%
 #   mutate(
 #   samp1 = round(runif(n = nrow(.),0,1),digits = 0),
 #   samp2 = round(runif(n = nrow(.),0,1),digits = 0),
 #   samp3 = round(runif(n = nrow(.),0,1),digits = 0),
 #   samp4 = runif(n = nrow(.),0,1))


 #vs.reverseHits(myDat, nonSampleCols = c("id","input","samp1"))


