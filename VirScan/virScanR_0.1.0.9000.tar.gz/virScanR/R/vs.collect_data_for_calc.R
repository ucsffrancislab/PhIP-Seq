#------------------------------------------------------------------------------#
# Set the parameters for sample collection
#------------------------------------------------------------------------------#
#' Set the parameters for sample collection
#'
#' This function creates a list to feed to
#' \code{\link{vs.collect_counts_for_calcs}}. It is designed to make it easy to
#' set parameters once and then quickly update the samples to collect or the
#' input library, etc while keeping other features the same.
#'
#' @param sampsDF The sample data frame with at least one column which contains
#'   the column names of the samples of interest in the database of interest.
#'   Ideally, sampsDF is produced by \code{\link{vs.makeSampsDF}} which uses
#'   \code{\link{vs.setParams_sampsDF}} to set its parameters. It should contain
#'   a column called "full_name" as the first column.
#' @param path,inputLibDB_path The path to the dataset for the samples of
#'   interest (path) or to the database containing the input/beads library
#'   (inputLibDB_path). If the latter is left NULL (DEFAULT) then \code{path}
#'   will be used for both. If this is a csv or csv.gz file, then this should be
#'   the full path to the file, including the 'file.csv' portion. If this is a
#'   SQL data base or XLSX or XLS data base then this should be the path to the
#'   database itself.
#' @param counts_table,inputLib_table Name of the specific table in the database
#'   where the samples of interest or the input samples are. If inputLib_table
#'   is left NULL, it will take on the value of counts_table.
#' @param ids Vector of ids to collect. For instance, if the database has mixed
#'   libraries or only one a certain set of ids to evaluate. The ids can easily
#'   be retrieved two ways: using \code{\link{vs.get_ids}} or using the
#'   arguments here:
#'   ids_DB_path,ids_DB_table,ids_DB_libColName,ids_DB_idColName. See vs.get_ids
#'   for details. Of note, both of these options require a specific database or
#'   data frame that contains the ids, with each library in its own column,  an
#'   'master \code{"id"} column' that may have ids from multiple libraries, and
#'   then each element of a given libraries column would be either 1, if that
#'   library has an id with that name, or 0/NA if not.
#' @inheritParams vs.get_ids
#' 
#' @param additional_samples Any sample names for additional samples
#'
#' @param inputLib_colName The name of the column that contains the
#'   input/beads/or otherwise reference column used for ranking and grouping the
#'   ids.
#' @param inputLib_idColName The name of the id column of the inputLib. Usually
#'   same as keyColumn (i.e. "id") but could be something else.
#' @param newInputLibDF Can upload a unique dataframe rather than going out and
#'   capturing previous ones. This must have at least two columns, and 'id'
#'   column and the column containing the counts.
#' @param includeInputCounts If FALSE (DEFAULT), will not look for or append a
#'   referent/input library. Therefore, these same parameters can be used, for
#'   example, to collect pValues or fold-enrichments later on without also
#'   capturing an input library or if using different samples, such as
#'   beads_only runs as the input counts. If TRUE, will collect the specified
#'   input column and place it as the second column, after the id column.
#' @param returnColsNotAvailable Should a vector of names of samples not
#'   available in the dataset be returned. If so, the returned object is a list
#'   and the second element is the vector of unavailable columns. Default is
#'   TRUE.
#' @param returnUpdatedSampsDF Should an updated "sampsDF data frame be returned
#'   based on the samples that are actually available? Default is TRUE.
#' @param keepInputLibNameIntact If FALSE, will make the input or referent name
#'   'input' else if TRUE will keep the name as it is.
#' @param convert_NAs_To What should NA's in the data be converted to? DEFAULT =
#'   0.
#' @param returnAs What type of data structure to return. Choose from:
#'   "data.table" (DEFAULT),"data.frame" or a tibble - any of:
#'   "tbl_df","data_frame","tibble","tbl".
#'
#' @inheritParams mmR::mm.fastread2
#'
#' @importFrom magrittr %>%
#' @export
vs.set_params_collect_data_for_calcs <- function(
  sampsDF=NULL,
  path=NULL,
  counts_table=NULL,

  inputLibDB_path=NULL,
  inputLib_table=NULL,
  inputLib_colName=NULL,
  inputLib_idColName = NULL,
  newInputLibDF=NULL,

  ids=NULL,
  ids_DB_path = NULL,
  ids_DB_table = NULL,
  ids_DB_libColName = NULL,
  ids_DB_idColName = NULL,
  
  additional_samples = NULL,
  nrows = NULL,
  returnColsNotAvailable = TRUE,
  keepInputLibNameIntact = FALSE,
  convert_NAs_To = 0,
  includeInputCounts = FALSE,
  returnUpdatedSampsDF = TRUE,
  returnAs = "data.table",
  search = FALSE,
  includeSubDirectories = TRUE,
  returnOnlyFirstInstance = TRUE,
  keyColumn = "id",
  col_type_n_guess = 1e4,
  skipExcel_zip = FALSE, 
  allow_gz_bz2_unzip = TRUE, 
  force_gz_bz2_unzip = FALSE, 
  directoryForTempDir = getwd(), 
  max_size_for_excel_zip = NULL,
  cores = parallel::detectCores()-1,
  ...
){
  return(
    list(
      sampsDF = sampsDF,
      path = path,
      counts_table = counts_table,
      ids = ids,
      
      newInputLibDF = newInputLibDF,
      
      inputLibDB_path = inputLibDB_path,
      inputLib_table = inputLib_table,
      inputLib_colName = inputLib_colName,
      inputLib_idColName = inputLib_idColName,
      
      ids_DB_path = ids_DB_path,
      ids_DB_table = ids_DB_table,
      ids_DB_libColName = ids_DB_libColName,
      ids_DB_idColName = ids_DB_idColName,
      
      additional_samples = additional_samples,
      nrows = nrows,

      returnColsNotAvailable = returnColsNotAvailable,
      keepInputLibNameIntact = keepInputLibNameIntact,
      convert_NAs_To = convert_NAs_To,
      includeInputCounts = includeInputCounts,
      returnUpdatedSampsDF = returnUpdatedSampsDF,
      returnAs = returnAs,
      search = search,
      includeSubDirectories = includeSubDirectories,
      returnOnlyFirstInstance = returnOnlyFirstInstance,
      keyColumn = keyColumn,
      col_type_n_guess = col_type_n_guess,
      skipExcel_zip = skipExcel_zip,
      allow_gz_bz2_unzip = allow_gz_bz2_unzip, 
      force_gz_bz2_unzip = force_gz_bz2_unzip, 
      directoryForTempDir = directoryForTempDir, 
      max_size_for_excel_zip = max_size_for_excel_zip,
      cores = cores
    )
  )
}


#------------------------------------------------------------------------------#
# Collect the data and append an input count or referent column
#------------------------------------------------------------------------------#
#' Retrieves desired data from the database.
#'
#' Takes a list of parameters, made using \code{\link{vs.set_params_collect_data_for_calcs}}. See that function for details. Can also input sampsDF and inputLib_colName directly here and it will override any that are in the supplied parameter list. Intended to make it easy to keep all the actual parameters the same, but just change the specific columns being collected. Of note, this function primarily relies on \code{\link{vs.pull}}. Will also udpate sampsDF and provide a new sampsDF data frame based on those samples that were available. THis can be used for downstream work.
#'
#' @param paramsList a list of parameters that determine the data to be collected. See \code{\link{vs.set_params_collect_data_for_calcs}} for details. Can also set sampsDF and inputLib_colName directly here without using the list function.
#'
#' @inheritParams vs.set_params_collect_data_for_calcs
#'
#' @return Returns either a data frame or a list with three elements. The data
#'   frame is returned if returnColsNotAvailable = FALSE, and consists of the
#'   samples requested. The returned DF will start with an 'id' column and, if
#'   \code{includeInputCountsor = TRUE} then the second column will be the input
#'   counts requested. If returnColsNotAvailable = TRUE, (DEFAULT) will return a
#'   list with three elements. The first will be as just described, the second
#'   element a vector of names of columns that were not available and the third
#'   element the sampsDF data.frame. If \code{returnUpdatedSampsDF = TRUE} then
#'   the sampsDF that is returned is updated to reflect only those samples that
#'   were found. Relies on an internal function
#'   \code{vs.removeColsNotInVirScanFromSampsDF} to update it.
#'
#'
#' @importFrom magrittr %>%

#' @export
vs.collect_data_for_calcs <- function(paramsList,
                                      sampsDF = NULL,
                                      inputLib_colName = NULL,
                                      inputLib_idColName = NULL,
                                      additional_samples = NULL,
                                      cores = NULL,
                                      ...){
#Declare all of the parameters up from

  if(is.null(sampsDF)){sampsDF = paramsList$sampsDF}
  if(is.null(inputLib_colName)){inputLib_colName = paramsList$inputLib_colName}
  if(is.null(inputLib_idColName)){inputLib_idColName = paramsList$inputLib_idColName}
  if(is.null(additional_samples)){additional_samples = paramsList$additional_samples}
  if(is.null(cores)) cores = paramsList$cores
  
  #path <- "./../00_labAndSampKeys/1_virScanData/counts/"
  path = paramsList$path
  counts_table = paramsList$counts_table
  ids = paramsList$ids

  keyColumn = paramsList$keyColumn
  
  #Get epitope IDs...
  #-----------------------------------------------------------------
  if(is.null(ids)){
    ids_DB_path = paramsList$ids_DB_path
    ids_DB_table = paramsList$ids_DB_table
    ids_DB_libColName = paramsList$ids_DB_libColName
    ids_DB_idColName = paramsList$ids_DB_idColName
    if(is.null(ids_DB_idColName)){
      ids_DB_idColName = keyColumn
    }
    
    if(!is.null(ids_DB_path)){
      try(
        ids <-
          vs.get_ids(ids_DB_path = ids_DB_path,
                     ids_DB_table = ids_DB_table,
                     ids_DB_idColName = ids_DB_idColName,
                     ids_DB_libColName = ids_DB_libColName,
                     returnAs = "vector")
      )
      
      if(class(.Last.value) == "try-error"){
        ids = NULL
      }
    }
  }
  
     
  #Set up to get input Library if requested
  #-----------------------------------------------------------------
  newInputLibDF = paramsList$newInputLibDF
  inputLibDB_path = paramsList$inputLib_path
  inputLib_table = paramsList$inputLib_table
  inputLib_idColName = paramsList$inputLib_idColName
  if(is.null(inputLib_idColName)){
    inputLib_idColName = keyColumn
  }
  
  nrows = paramsList$nrows
  returnColsNotAvailable = paramsList$returnColsNotAvailable
  keepInputLibNameIntact = paramsList$keepInputLibNameIntact
  convert_NAs_To = paramsList$convert_NAs_To
  includeInputCounts = paramsList$includeInputCounts
  returnUpdatedSampsDF = paramsList$returnUpdatedSampsDF
  returnAs = paramsList$returnAs
  search = paramsList$search
  includeSubDirectories = paramsList$includeSubDirectories
  returnOnlyFirstInstance = paramsList$returnOnlyFirstInstance
  col_type_n_guess = paramsList$col_type_n_guess
  skipExcel_zip = paramsList$skipExcel_zip
  allow_gz_bz2_unzip = paramsList$allow_gz_bz2_unzip 
  force_gz_bz2_unzip = paramsList$force_gz_bz2_unzip
  directoryForTempDir = paramsList$directoryForTempDir
  max_size_for_excel_zip = paramsList$max_size_for_excel_zip
    
  newInputDFNames = NULL
  inputPathSameAsCounts = FALSE
  inputTableSameAsCounts = FALSE
  collectInputWithSampleCounts = FALSE
  columns <- NULL
  if (!is.null(sampsDF)) {
    if("data.frame" %in% class(sampsDF)){
      data.table::setDF(sampsDF)
      if ("full_name" %in% names(sampsDF)) {
        columns <- c(sampsDF$full_name)
      }
      else {
        columns <- sampsDF[, 1]
      }  
    } else if(is.vector(sampsDF)){
      columns <- sampsDF
    }
  }
  
  columns <- c(columns,additional_samples)
  if(is.null(columns) | length(columns) == 0){
    stop("sampsDF or additional_samples must be provided")
  }
  
  if(is.null(keyColumn)){
    stop("keyColumn cannot be NULL. Default value is 'id' or specify a new keyColumn.")
  }
  
  if( includeInputCounts == TRUE ){
    inputLib = NULL
    #if an actual data frame is uploaded for the newInputLibDF
    if( !is.null(newInputLibDF) ) {
      
      if(!"data.frame" %in% class(newInputLibDF)){
        stop("If newInputLibDF is supplied, it must be a data.frame, data.table or tibble.")
      }
      data.table::setDF(newInputLibDF)
      newInputDFNames <- names(newInputLibDF)
      
      if(ncol(newInputLibDF)<2){
        stop("newInputLibDF requires a data frame with at least two columns. The first column should be the row id (i.e. column name matching inputLib_idColName) and second the input library (i.e. column name matching inputLib_colName).")
      }
      
      if((!(inputLib_idColName %in% newInputDFNames)) & ncol(newInputLibDF)>2){
        stop("inputLib_idColName (if specified or 'keyColumn' if 'inputLib_idColName' is not specified) is not found in the newInputLibDF data.frame and there are >2 columns. Must specify appropriate inputLib_idColName to be used in the supplied input library df or provide a two column data frame - the first column the row ids (corresponding to keyColumn) and second column the input library values or counts.")
      }
      
      
      if((!(inputLib_colName %in% newInputDFNames)) & ncol(newInputLibDF)>2){
        stop("'inputLib_colName' not found in the newInputLibDF data.frame and there are >2 columns.
             Must specify appropriate column name using 'inputLib_colName' to use for the input library or provide a two column data frame - the first column the row ids (corresponding to keyColumn) and second column the input library values or counts.")
      }
      
      if(ncol(newInputLibDF) == 2){
        
        if(is.null(inputLib_colName)){
          inputLib_colName <- newInputDFNames[2]
        } else if(!inputLib_colName %in% newInputDFNames){
          stop("inputLib_colName not found in the supplied newInputLibDF data frame")
        }
        
        if(is.null(inputLib_idColName)){
          inputLib_idColName <- newInputDFNames[1]
        } else if(!inputLib_idColName %in% newInputDFNames){
          stop("inputLib_idColName not found in the supplied newInputLibDF data frame")
        }
        
      }
      
      inputLib <- newInputLibDF[,c(inputLib_idColName,inputLib_colName)]
      
    } #end if(!is.null(newInputLibDF))...
      
    if( is.null(newInputLibDF) ) {#if newInputLibDF is null
      
      #Defaults to have the input library table in the same db as the data.
      #but if it's not null, it will look in inputLibDB_path for the input
      #library table
      if( is.null( inputLibDB_path  ) | inputLibDB_path == path ) {
        inputLibDB_path = path
        inputPathSameAsCounts = TRUE
      }
      
      if( is.null(inputLib_table) | inputLib_table == table) {
        inputLib_table = table
        inputTableSameAsCounts = TRUE
      }
      
      if( is.null(inputLib_idColName) | inputLib_idColName == keyColumn) {
        inputLib_idColName = keyColumn
        inputLib_idCol_SameAsCounts = TRUE
      }
      
      
      if(inputPathSameAsCounts == TRUE & 
         inputTableSameAsCounts == TRUE & 
         inputLib_idCol_SameAsCounts == TRUE){
        collectInputWithSampleCounts = TRUE
      }
    
      if(is.null(inputLib_colName)) {
        stop(paste0("inputLib_colName must be specified"))
      } 
      
      
      #Collect input library here.
      if(!collectInputWithSampleCounts){
        inputLib <- 
          mmR::mm.fastread2(path = inputLibDB_path,
                            table = inputLib_table,
                            columns = inputLib_colName,
                            header = TRUE,
                            nrows = nrows,
                            allRows = TRUE,
                            returnColsNotAvailable = TRUE,
                            returnAs = "data.frame",
                            search = TRUE,
                            includeSubDirectories = includeSubDirectories,
                            returnOnlyFirstInstance = TRUE,
                            combineAll = TRUE,
                            keyColumn = inputLib_idColName,
                            col_type_n_guess = col_type_n_guess,
                            returnDataWithNoKeyCol = FALSE,
                            returnColNamesWithNoKeyCol = FALSE,
                            allow_gz_bz2_unzip = allow_gz_bz2_unzip,
                            force_gz_bz2_unzip = force_gz_bz2_unzip,
                            directoryForTempDir = directoryForTempDir,
                            max_size_for_excel_zip = max_size_for_excel_zip,
                            cores = cores)
        
        
        #Check to see if inputLib was found appropriately
        if(!("data.frame" %in% class(inputLib[[1]])) | nrow(inputLib[[1]]==0)){
          stop(sprintf("Unable to find 'inputLib_colName': %s",inputLib_colName))
        }
        
        if(ncol(inputLib[[1]]) == 1){
          stop(
            sprintf(
              "inputLib_idColName (%s) - or 'keyColumn' if not directory specified - not found",
              inputLib_colName))
        } 
        inputLib <- inputLib[[1]]
      }
    }
      
    #check if keepInputLibNameIntact...
    if(!is.null(inputLib)){
      if(keepInputLibNameIntact == FALSE){
        names(inputLib) <- c(keyColumn,"input")
        inputLib_colName <- "input"
      } else {
        names(inputLib)[1] <- keyColumn
      }
    }
          
    #set ids to match those in the input library.
    if(!is.null(inputLib)){
      if(is.null(ids)){
        ids <- inputLib[,keyColumn]  
      } else {
        ids <- ids[which(ids %in% inputLib[,keyColumn])]
      }
    }
    
    if(collectInputWithSampleCounts == TRUE){
      columns <- unique(c(inputLib_colName, columns))
    }
  } #end "includeInputCounts == TRUE" portion
    
  if(keyColumn %in% columns){
    columns <- columns[-which(columns == keyColumn)]
  }
  #path <- "./../00_labAndSampKeys/1_virScanData/counts/"
  counts <- 
    mmR::mm.fastread2(
      path = path,
      table = counts_table,
      columns = columns,
      header = TRUE,
      allRows = TRUE,
      nrows = nrows,
      returnAs = "data.table",
      col_type_n_guess = col_type_n_guess,
      search = TRUE,
      includeSubDirectories = includeSubDirectories,
      returnOnlyFirstInstance = returnOnlyFirstInstance,
      combineAll = TRUE,
      returnDataWithNoKeyCol = FALSE,
      returnColNamesWithNoKeyCol = TRUE,
      keyColumn = keyColumn,
      returnColsNotAvailable = TRUE,
      skipExcel_zip = skipExcel_zip,
      allow_gz_bz2_unzip = allow_gz_bz2_unzip,
      force_gz_bz2_unzip = force_gz_bz2_unzip,
      directoryForTempDir = directoryForTempDir,
      max_size_for_excel_zip = max_size_for_excel_zip,
      cores = cores)

      
#Need to add this in here.
#convert_NAs_To = convert_NAs_To

  if(nrow(counts[[1]])==0){
    message("No Counts Collected")
  }
  
  if(!is.null(ids)){
    counts[[1]] <- counts[[1]][get(keyColumn) %in% ids, ]
  }
  #filter by 'reference'... probably don't need.  unless huge data.
  # if(!is.null(ids)){
  #   keep.idxs <- which(counts[[1]][,get(keyColumn)] %in% ids)
  #   cols <- names(counts[[1]])
  #   cols1 <- cols[1] 
  #   DT.subset = data.table::data.table(data.frame(x = counts[[1]][[cols1]][keep.idxs]))
  #   names(DT.subset) <- keyColumn
  #   counts[[1]][, (cols1) := NULL]
  #   cols <- data.table::copy(names(counts[[1]]))
  #   for (col in cols){ 
  #     print(col)
  #     DT.subset[, (col) := counts[[1]][[col]][keep.idxs]]
  #     counts[[1]][, (col) := NULL] #delete
  #   }
  #   counts[[1]] <- DT.subset
  #   rm(DT.subset)
  # }
  
  countsNotAvailable = counts$columns_not_available
  counts = counts[[1]]

  sampsDF_original <- sampsDF$full_name
  if(returnUpdatedSampsDF){
    sampsDF <-
      vs.removeColsNotInVirScanFromSampsDF.int(sampsDF, names(counts))
  }


    print("obtained counts")
    if(length(countsNotAvailable)>0){
      print(paste0("WARNING: Count data not available for:"))
      print(countsNotAvailable)
    }
    print(
      paste0(
        100 * (1-length(countsNotAvailable) / length(sampsDF_original)),
        " % of counts samples available"))

    if(includeInputCounts == TRUE){
      
      if(!is.null(inputLib)){
        data.table::setDT(inputLib)  

        inputLib[,(keyColumn) := as.character(inputLib[[keyColumn]])]
        counts[,(keyColumn) := as.character(counts[[keyColumn]])]
        counts <- counts[inputLib,on = (keyColumn)]
      }
    }
    
    if(!is.null(convert_NAs_To)){
      convertCells <- function(X,convertTo){
        X[which(is.na(X))] <- convertTo
        return(X)
      }
      counts <- counts[, lapply(.SD, convertCells,
                                convertTo = convert_NAs_To)] #, .SDcols = (names)]
    }
        
    
    
    if(returnAs == "data.frame"){
      counts <- data.table::setDF(counts)
    } else if(returnAs == "data.table"){
      counts <- data.table::setDT(counts)
    } else if(returnAs %in% c("tbl_df","tibble","tbl","data_frame")){
      counts <- dplyr::as_tibble(counts)
    } else {
      counts <- data.table::setDT(counts)
    }


    if(returnColsNotAvailable){
      return(
        list(counts = counts,
             countsNotAvailable = countsNotAvailable,
             sampsDF = sampsDF))
    } else {
      return(
        list(counts = counts, 
             sampsDF = sampsDF))
    }
}
