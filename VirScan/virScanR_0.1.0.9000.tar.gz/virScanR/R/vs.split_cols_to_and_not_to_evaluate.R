#' Function to split colums to and to not evaluate and return as a list of 1 or 3 items.
#'
#' @param data Data to split
#' @param cols_to_not_evaluate Which columns to not evaluate. NULL is Default.
#' @param cols_to_evaluate Which columns to evaluate. NULL is default. If this
#'   is not NULL, any columns not listed will be automatically added to
#'   'cols_to_not_evaluate' and treated as such.
#' @param returnNotEvaluated Should those columns that fall under the return Not
#'   Evaluated category be returned as list element 2. Default is FALSE. If this
#'   is set to TRUE, then there will also be a third list element with the
#'   original column orders - for convenience later on.
#' @importFrom magrittr %>%
#' @export
vs.split_cols_to_and_not_to_evaluate <-
  function(data,
           cols_to_not_evaluate = NULL,
           cols_to_evaluate = NULL,
           returnNotEvaluated = FALSE,
           ...){

    whatClassAll <- class(data)
    whatClass <- whatClassAll[1]

    if(!whatClass %in% c("data.frame","tbl_df","tbl")){
      data <- dplyr::tbl_df(data)
    }

    #SEPARATE OUT DATA TO EVALUATE AND DATA TO NOT EVALUATE
    ##--------------------------------------------------------------------------
    originalColOrder <- names(data)

    noEvalVec <- vector()
    if(!is.null(cols_to_not_evaluate)){
      if(is.numeric(cols_to_not_evaluate)){
        cols_to_not_evaluate <- originalColOrder[cols_to_not_evaluate]
      }
      noEvalVec <- cols_to_not_evaluate
    }

    if(!is.null(cols_to_evaluate)){
      if(is.numeric(cols_to_evaluate)){
        cols_to_evaluate <- originalColOrder[cols_to_evaluate]
      }

      noEvalVec <- unique(c(noEvalVec,
                            originalColOrder[which(!originalColOrder %in% cols_to_evaluate)]))

    }

    dataNoEval <- NULL
    dataEval <- NULL
    if(length(noEvalVec)>0){
      dataNoEval <- data %>% dplyr::select(noEvalVec)
      dataEval <- originalColOrder[which(!originalColOrder %in% names(dataNoEval))]
      dataEval <- data %>% dplyr::select(dataEval)
    } else {
      dataEval <- data
    }


    if(whatClass == "data.table"){
      data.table::setDT(dataEval)
      data.table::setDT(dataNoEval)
    } else if(whatClass == "data.frame"){
      data.table::setDF(dataEval)
      data.table::setDF(dataNoEval)
    }

    data.table::setattr(dataEval, "class", whatClassAll)
    data.table::setattr(dataNoEval, "class", whatClassAll)

    if(returnNotEvaluated == TRUE){
      return(
        list(
          dataEval = dataEval,
          dataNoEval = dataNoEval,
          originalColOrder = originalColOrder
        )
      )
    } else {
      return(list(dataEval = dataEval))
    }
}
