#' Function to read in the sample meta data and organize to find sample names,
#' individuals, etc
#'
#' @param path,samplePath,individualPath,virScanPath,inputLibKeyPath \code{path}
#'   is the path to a database containing the sample meta data, individual meta
#'   data virScan meta data and/or input library keys. Alternatively, each of
#'   the paths can be input separately, if for example a csv is used to hold
#'   each or combining databases, etc. To do this, use the respective
#'   \code{samplePath,individualPath,virScanPath, or inputlibKeyPath}.
#'
#' @param table_name_samp,table_name_ind,table_name_vs,table_name_libKey If
#'   using the a database with multiple tables, the respective name, for example
#'   the worksheet names of an xlsx workbook or the table name in a SQL table.
#'
#' @param remove_duplicates Should duplicate rows in any of the data sets be
#'   removed (DEFAULT TRUE)
#' @param return_duplicates Should any duplicate rows in any of the data sets be
#'   returned as list elements (DEFAULT TRUE).
#'
#'
vs.gatherSampleMetaData <-
  function(path = NULL,

           table_name_samp = "enterSampleData",
           table_name_ind = "enterIndividualData",
           table_name_vs = "enterVirScanData",
           table_name_libKey = "inputLibKeys",

           samplePath = NULL,
           individualPath = NULL,
           virScanPath = NULL,
           inputLibKeyPath = NULL,

           remove_duplicates = TRUE,
           return_duplicates = TRUE,
           ...
           ){








    #tables <- mmR::mm.listTables(path)
    if(is.null(samplePath)){
      samplePath = path
    }

    if(is.null(individualPath)){
      individualPath = path
    }

    if(is.null(virScanPath)){
      virScanPath = path
    }

    if(is.null(inputLibKeyPath)){
      inputLibKeyPath = path
    }


    samp1 <- mmR::mm.fastread(samplePath, table_name_samp)
    ind1 <- mmR::mm.fastread(individualPath, table_name_ind)
    vs1 <- mmR::mm.fastread(virScanPath, table_name_vs)
    libKey <- try(mmR::mm.fastread(inputLibKeyPath, table_name_libKey),silent = TRUE)
    if(class(.Last.value)[1] =="try-error"){
      libKey = NULL
      print("no Input library key file found")
    }
    #-----------------------------------------------------------------------------
    #IndividualsKey
    #-----------------------------------------------------------------------------
    ind <- ind1
    #unique_individual_long
    #-----------------------------------------------------------------------------
    ind <- ind %>%
      dplyr::mutate(unique_individual_long = paste(pi, study_name,individual, sep = "."))
    ind_duplicated <- ind[duplicated(ind$unique_individual_long),]

    if (remove_duplicates == TRUE) {
      ind <- ind[!duplicated(ind$unique_individual_long),]
    }


    #unique_individual_id
    #-----------------------------------------------------------------------------
    ind$unique_individual_id <- c(1:nrow(ind))



    #-----------------------------------------------------------------------------
    #SamplesKey
    #-----------------------------------------------------------------------------
    samp <- samp1
    #unique_sample_long
    #-----------------------------------------------------------------------------
    samp <- samp %>%
      dplyr::mutate(unique_sample_long = paste(pi,study_name,tube_id,sep = "."))
    samp_duplicated <- samp[duplicated(samp$unique_sample_long),]

    if(remove_duplicates == TRUE){
      samp <- samp[!duplicated(samp$unique_sample_long),]
    }

    #unique_sample_id
    #-----------------------------------------------------------------------------
    samp$unique_sample_id <- c(1:nrow(samp))

    #unique_individual_id
    #-----------------------------------------------------------------------------
    samp <- samp %>%
      dplyr::mutate(unique_individual_long = paste(pi,study_name,individual,sep = "."))

    samp <-
      samp %>%
      dplyr::left_join(ind %>% 
                         dplyr::select(unique_individual_long,unique_individual_id),
                by = "unique_individual_long")


    #-----------------------------------------------------------------------------
    #virScanKey
    #-----------------------------------------------------------------------------
    vs <- vs1

    #Get unique_sample_long, unique_sample_id, unique_individual_id, and individual
    #by merging with the samp data frame.
    #and make the full_name column
    #-----------------------------------------------------------------------------
    vs2 <-
      vs %>%
      dplyr::mutate(unique_sample_long = paste(pi,study_name,tube_id,sep = ".")) %>%
      dplyr::left_join(
        samp %>% dplyr::select(unique_sample_long,unique_sample_id,
                        unique_individual_id,individual),
        by = "unique_sample_long") %>%
      dplyr::mutate(unique_sample_long = NULL) %>%
      dplyr::mutate(full_name = ifelse(!is.na(custom_full_name),
                                custom_full_name,
                                paste0(plate_name,".",row,column)))



    #Check for duplicates. return the data frame, dups, if return_duplicates = TRUE
    #-----------------------------------------------------------------------------
    duplicated <-
      vs2 %>%
      dplyr::group_by(full_name) %>%
      dplyr::mutate(count =1, cumCount = cumsum(count), count = sum(count))

    duplicatedIndex <- which(duplicated$count>1)

    dups <- vs2[duplicatedIndex,]

    if(remove_duplicates == TRUE){
      if(nrow(dups)>0){
        if(length(which(!is.na(dups$pi)))>0){
          print("WARNING: duplicate virScan entries detected. Removing now, Set 'return_duplicates' = TRUE to see them.")
        }
        vs2 <- vs2[-duplicatedIndex,]
      }
    }



    vs3 <-
      vs2 %>%
      dplyr::mutate(beads_only =
               ifelse(is.na(beads_only),0,
                      ifelse(beads_only ==1,1,0)),
             empty_sample =
               ifelse(is.na(empty_sample),0,
                      ifelse(empty_sample ==1,1,0)),
             library_sample =
               ifelse(is.na(library_sample),0,
                      ifelse(library_sample ==1,1,0))) %>%

      dplyr::mutate(unique_sample_id =
               ifelse(beads_only ==1,"beads",unique_sample_id),
             unique_individual_id =
               ifelse(beads_only ==1,"beads",unique_individual_id)) %>%
      dplyr::mutate(unique_sample_id =
               ifelse(library_sample ==1,"library",unique_sample_id),
             unique_individual_id =
               ifelse(library_sample ==1,"library",unique_individual_id)) %>%
      dplyr::mutate(unique_replicate_id = paste(unique_sample_id,
                                         input_id,
                                         dilution_other_change,
                                         protocol,sep = ".")) %>%
      dplyr::group_by(unique_replicate_id) %>%
      dplyr::mutate(replicate = 1) %>%
      dplyr::mutate(total_replicate = sum(replicate)) %>%
      dplyr::mutate(replicate = cumsum(replicate)) %>%
      dplyr::mutate(oddRep = replicate %% 2) %>%
      dplyr::mutate(tech_replicate_replicate_num =
               ifelse(oddRep == 1 & total_replicate > replicate,
                      replicate + 1,
                      replicate - 1)) %>%
      dplyr::mutate(oddRep = NULL) %>%
      dplyr::ungroup() %>%
      dplyr::mutate(replicate_unique_id = paste0(unique_replicate_id,"_Rep",replicate),
             replicate_to_look_for = paste0(unique_replicate_id,"_Rep",tech_replicate_replicate_num))


    techRepToMerge <-
      vs3 %>%
      dplyr::select(replicate_unique_id,
             replicate_full_name = full_name) %>%
      dplyr::group_by(replicate_full_name) %>%
      dplyr::mutate(count = 1, count = cumsum(count)) %>%
      dplyr::filter(count ==1) %>%
      dplyr::select(-count) %>%
      dplyr::ungroup()





    vs4<-
      vs3 %>%
      dplyr::left_join(techRepToMerge,
                by = c("replicate_to_look_for" = "replicate_unique_id")) %>%
      dplyr::mutate(replicate_full_name =
               ifelse(
                 !is.na(custom_replicate_full_name),
                 custom_replicate_full_name,
                 ifelse(
                   !is.na(custom_replicate_plate_name) &
                     !is.na(custom_replicate_row) &
                     !is.na(custom_replicate_column),
                   paste0(custom_replicate_plate_name,".",
                         custom_replicate_row,
                         custom_replicate_column),
                   replicate_full_name))) %>%
      unique()


    vs5 <-
      vs4 %>%
      dplyr::left_join(
        libKey %>%
          dplyr::select(input_id,
                 input_name,
                 amp_or_combined_date,
                 input_full_description = full_description),
        by = "input_id") %>%
      unique()



    vs6 <-
      vs5 %>%
      dplyr::mutate(unique_methods_long_id = paste(input_id,protocol,sep = "."))

    unique_methdods_id_df <-
      vs6 %>%
      dplyr::select(unique_methods_long_id) %>%
      unique() %>%
      dplyr::mutate(unique_methods_id = 1,
             unique_methods_id = paste0("X",cumsum(unique_methods_id)))

    vs7 <-
      vs6 %>%
      dplyr::left_join(unique_methdods_id_df, by = "unique_methods_long_id")

    vs8 <-
      vs7 %>%
      dplyr::mutate(fully_comparable_long_id =
               paste(unique_methods_long_id,
                     dilution_other_change,
                     sep = "."))

    fully_comparable_id =
      vs8 %>%
      dplyr::select(fully_comparable_long_id) %>%
      unique() %>%
      dplyr::mutate(fully_comparable_id = 1,
             fully_comparable_id = paste0("X",cumsum(fully_comparable_id)))

    vs9 <-
      vs8 %>%
      dplyr::left_join(fully_comparable_id, by = "fully_comparable_long_id") %>%
      dplyr::mutate(unique_virScan_id = c(1:nrow(vs8)))

    if(return_duplicates == FALSE){
      samp_duplicated = NULL
      ind_duplicated = NULL
      dups = NULL
    }

    return(
      list(
        sampData=samp,
        indData = ind,
        vsData = vs9,
        libKey = libKey,
        samp_dups = samp_duplicated,
        ind_dups = ind_duplicated,
        vs_dups = dups
        )
      )

  }




