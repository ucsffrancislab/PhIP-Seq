#------------------------------------------------------------------------------#
#Remove failed Runs from the rep12 dtaframe
#------------------------------------------------------------------------------#
#' Internal functino to remove any runs that failed from the replicateNames data
#' frame that is used in vs.collect_calc_CSData
#' @importFrom magrittr %>%
vs.rmFailuresFromReplicateNamesDF <- function(replicateNamesDF, failedDF){
  return(replicateNamesDF %>%
           dplyr::filter(!identifier %in% failedDF$identifier))
}
