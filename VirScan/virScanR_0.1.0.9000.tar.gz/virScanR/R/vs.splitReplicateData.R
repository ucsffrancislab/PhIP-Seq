#------------------------------------------------------------------------------#
#vs.splitReplicateData #function to return a list, and each element is a replicate
#------------------------------------------------------------------------------#
#' Function to split replicate data into a list with two data frames, each identical dimenstions and column orders, differing by the technical replicates, as input with replicateNamesDF.
#'
#' @param counts,pVals,table The data to split into two data frames. Counts
#'   defaults to ID as column 1 and Input library counts as column 2. pVals
#'   defaults to only having an ID column up front as the first column, and then
#'   the samples. table does not default and expects nonSampleColsNames to be
#'   filled out, or left NULL if no ID or nonSample names.
#'
#' @param replicateNamesDF a dataframe with rep1 and rep2, where rep1 is the
#'   column name of the first replicate and rep2 is the column name of the
#'   second replicate. Best to make this with
#'   \code{\link{vs.gatherReplicateNames}}, because it makes sure that it only
#'   keeps each pairing once, rather than having both A-B and B-A it only keeps
#'   a row for A-B and removes B-A, so not to duplicate columns
#'
#' @param idColNum,inputLibColNum Which number in the respective data is the
#'   "ID" column or input library Column. Defaults to 1 and 2 if data shows up
#'   under counts =..., defautls to just 1 (and no input Lib) if data is input
#'   under pVals.
#'
#' @param nonSampleColNames If data is input as table =... then this is to
#'   identify the names of the columns that are not samples to be split up (i.e.
#'   ID column, input library column, ets...)
#'
#'
#' @importFrom magrittr %>%
#' @export
vs.splitReplicateData <- function(counts = NULL,
                                  pVals = NULL,
                                  table = NULL,
                                  replicateNamesDF,
                                  idColNum = 1,
                                  inputLibColNum  =2,
                                  nonSampleColsNames = NULL){

  replicateNamesDF$rep1 <- as.character(replicateNamesDF$rep1)
  replicateNamesDF$rep2 <- as.character(replicateNamesDF$rep2)


  if(!is.null(counts)){
    data = counts
    init = c(idColNum,inputLibColNum)
  } else if(!is.null(pVals)){
    data = pVals
    init = idColNum
  } else if(!is.null(table)){
    data = table
    init = nonSampleColsNames
  }


  namesForRep1 <- data.frame(rep1 = names(data), rep1_ok = 1)
  namesForRep2 <- data.frame(rep2 = names(data), rep2_ok = 1)


  checkForBothReps <-
    replicateNamesDF %>%
    dplyr::left_join(namesForRep1, by = "rep1") %>%
    dplyr::left_join(namesForRep2,by = "rep2") %>%
    dplyr::mutate(bothReps = rep1_ok + rep2_ok)

  noReplicate <- which(checkForBothReps$bothReps != 2)


  if(length(noReplicate) != 0){
    stop(sprintf("STOP!: missing replicates for: %s",
                        replicateNamesDF$identifier[noReplicate]))
  }

  replicateNamesDF <- replicateNamesDF[which(!is.na(checkForBothReps$bothReps)),]
  


  if(!is.null(init)){
    if(length(init)>0){
      rep1 <-cbind(data.frame(data[,init]), data.frame(data[ ,replicateNamesDF$rep1])) %>% data.frame()
      rep2 <-cbind(data.frame(data[,init]), data.frame(data[ ,replicateNamesDF$rep2])) %>% data.frame()
    }

  } else {
    rep1 <- data[,replicateNamesDF$rep1] %>% data.frame()
    rep2 <- data[,replicateNamesDF$rep2] %>% data.frame()
  }

  if(!is.null(counts)){
    names(rep1)[c(1:length(init))] = c("id","input")
    names(rep2)[c(1:length(init))] = c("id","input")
  } else if(!is.null(pVals)){
    names(rep1)[c(1:length(init))] = "id"
    names(rep2)[c(1:length(init))] = "id"
  } else if(!is.null(table)) {

    if(!is.null(init)){
      if(length(init) > 0){
        names(rep1)[c(1:length(init))] = nonSampleColsNames
        names(rep2)[c(1:length(init))] = nonSampleColsNames
      }
    }

  }


    toReturn <- list(rep1, rep2)

    return(toReturn)

}
