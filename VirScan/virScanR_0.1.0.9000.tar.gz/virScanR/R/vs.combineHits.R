#' A function to combine two groups of 0/1 'hits' get a conservative or liberal
#' readout of the combined data.
#'
#' Allows, for example, to take two statistical runs on the same sample and only
#' mark those as hits that were found to be significant in both runs. Or, more
#' liberally to take any that were significant in one or the other and call it a
#' hit.
#'
#' This function is similar to \code{vs.getHits} except it compares two
#' statistically different samples, rather than two technical replicates that
#' were actually run separately. The major difference is that this function
#' expects as a Default for the samples in the two data sets to have the exact
#' same names or, alternatively, the exact same order and dimensions. It can
#' technically work in lieu of vs.getHits for data with different names but
#' known to have correct column orders for pairing doubles to choose hits.
#'
#' This is particularly useful, for example, when ensuring, in VirScan, that two
#' statistical runs on staggered chunks have the same hits, and removing (or
#' keeping) those which are discrepent.
#'
#' @param dat1,dat2 Data frames containing the values to to combine
#'
#' @param nonSampleCols1,nonSampleCols2 STRING or VECTOR: Columns that should
#'   not be evaluated. Note, that after combining, if nonSampleCols1 and 2 are
#'   different, preference will be given to keep the structure of the original
#'   hits1 data, and therefore nonSampleCols2 will be dropped in the combined
#'   data. If these are exactly the same, then only have to fill out
#'   nonSampleCols1
#'
#' @param arrangeByName LOGICAL: If the data sets are not in exactly the same
#'   arrangement but comparable samples share the exact same name, then, if set
#'   to TRUE, this will compare zeros and 1's in samples that share the same
#'   name. DEFAULT is TRUE.
#'
#' @param arrangeByColOrder LOGICAL: If the names in the two data sets are
#'   different (ie technical replicates with differing NGS sample names) but the
#'   orders of the columns in the two data sets are known to match up with each
#'   other, then change this to TRUE and it will prioritize column order over
#'   column name when comparing the two runs.
#'
#' @param colNamesToReturn Optional vector of names for the columns that are
#'   returned. This is particularly useful if feeding it data sets each of which
#'   only contain a single vector from a data frame. For example, if using
#'   myDF[,x] in R, where x is a single integer, myDF[,x] is interpreted as an
#'   unnamed vector. Therefore, it can be useful to supply, for example,
#'   \code{colNamesToReturn = names(myDF)[x]} so it will spit out an appropriate
#'   column name rather than an unnamed column.  Will ONLY be run if a single
#'   column is chosen or if arrangeByColOrder is set to TRUE.
#'
#' @param combineConservatively LOGICAL: If one sample is zero and the other is
#'   one, should it call it zero (\code{combineConservatively = TRUE}) or call
#'   it significant/one (\code{combineConservatively = FALSE}).  Essentially, if
#'   binomial and combining a zero and a one, then if TRUE, will make it zero,
#'   if FALSE will make it one. Therefore, assumes 1 is the significant value.  Defaults to TRUE.
#'
#' @param isIntegerData = LOGICAL Is the data integer data. If so, will round up
#'   conservatively if \code{combineConservatively} is set to FALSE.
#'
#' @param calcFun What function to use to combine them. Must be one of: \code{"binomial","mean","average","sum","diff","mult","prod","divide"}.
#' Binomial is the one discussed above. But the others are other reasonable ways to combine the matrices.
#'
#' @param convert_NAs_to,convert_nulls_to Converts any NAs or NULL's,
#'   respectively, to this value before combining. Also see convert_vals,convert_vals_to.
#'
#' @param convert_vals,convert_vals_to Converts the \code{convert_vals} to
#'   \code{convert_vals_to}. \code{convert_vals} Takes a Number, string or vector
#'   of values to convert. \code{convert_vals_to} takes a single value.
#'
#' @return Returns a data frame object with zeros and ones for what is
#'   considered a hit based on the supplied inputs.
#'
#' @examples
#' set.seed(1001)
#' myDat1 <-
#' data.frame(id = c(1:20)) %>%
#' mutate(input = id*4) %>%
#' mutate(
#' samp1 = runif(n = nrow(.),0,1),
#' samp2 = runif(n = nrow(.),0,1),
#' samp3 = runif(n = nrow(.),0,1),
#' samp4 = runif(n = nrow(.),0,1))
#'
#' myDat2 <-
#' data.frame(id = c(1:20)) %>%
#' mutate(input = id*4) %>%
#' mutate(
#' samp1.1 = runif(n = nrow(.),0,1),
#' samp2.1 = runif(n = nrow(.),0,1),
#' samp3.1 = runif(n = nrow(.),0,1),
#' samp4.1 = runif(n = nrow(.),0,1))
#'
#' hits1 = vs.makeBinomP(pVals = myDat1,
#'            pThresh = .1,
#'            greaterThan=TRUE,
#'            nonSampleCols = c("id","input"))
#'
#' hits2 = vs.makeBinomP(pVals = myDat2,
#'            pThresh = .1,
#'            greaterThan=TRUE,
#'            nonSampleCols = c("id","input"))
#'
#'#DIFFERENT SAMPLE NAMES, SAME ORDER OF COLS
#' vs.combineHits(hits1 = hits1,
#'                hits2 = hits2,
#'                arrangeByColOrder = TRUE)
#'
#' #Change order of columns of myDat2 but havesame sample names in data
#'
#' myDat3 <-
#' data.frame(id = c(1:20)) %>%
#' mutate(input = id*4) %>%
#' mutate(
#' samp1 = runif(n = nrow(.),0,1),
#' samp4 = runif(n = nrow(.),0,1),
#' samp2 = runif(n = nrow(.),0,1),
#' samp3 = runif(n = nrow(.),0,1))
#'
#' hits3 = vs.makeBinomP(pVals = myDat3,
#'            pThresh = .1,
#'            greaterThan=TRUE,
#'            nonSampleCols = c("id","input"))
#'
#' vs.combineHits(hits1 = hits1,
#'                hits2 = hits3,
#'                arrangeByName = TRUE)
#'
#' @export
vs.combineData <- function(dat1,
                           dat2,
                           nonSampleCols1 = c("id","input"),
                           nonSampleCols2 = NULL,
                           arrangeByName = TRUE,
                           arrangeByColOrder = FALSE,
                           colNamesToReturn = NULL,
                           combineConservatively = TRUE,
                           isIntegerData = TRUE,
                           calcFun = "binomial",#c("binomial","mean","average","sum","diff","mult","prod","divide"),
                           convert_NAs_to = NULL,
                           convert_nulls_to = NULL,
                           convert_vals = NULL,
                           convert_vals_to = NULL
                           ) {

  #make sure it's a DF. this is particularly needed if a vector is supplied.
  dat1 <- data.frame(dat1)
  dat2 <- data.frame(dat2)

  if(nrow(dat1) != nrow(dat2)){
    stop("Differing number of rows in supplied data.")
  }

  if(is.null(nonSampleCols2)) { nonSampleCols2 = nonSampleCols1 }

  if(!is.null(convert_NAs_to)){
    dat1 <- mmR::mm.convertCells(data = dat1,
                                 nonSampleCols = nonSampleCols1,
                                 originalVal = NA,
                                 newVal = convert_NAs_to)

    dat2 <- mmR::mm.convertCells(data = dat2,
                                 nonSampleCols = nonSampleCols2,
                                 originalVal = NA,
                                 newVal = convert_NAs_to)
  }


  if(!is.null(convert_nulls_to)){
    dat1 <- mmR::mm.convertCells(data = dat1,
                                 nonSampleCols = nonSampleCols1,
                                 originalVal = NULL,
                                 newVal = convert_NAs_to)

    dat2 <- mmR::mm.convertCells(data = dat2,
                                 nonSampleCols = nonSampleCols2,
                                 originalVal = NULL,
                                 newVal = convert_NAs_to)
  }


  if(!is.null(convert_vals)){
    dat1 <- mmR::mm.convertCells(data = dat1,
                                 nonSampleCols = nonSampleCols1,
                                 originalVal = convert_vals,
                                 newVal = convert_vals_to)

    dat2 <- mmR::mm.convertCells(data = dat2,
                                 nonSampleCols = nonSampleCols2,
                                 originalVal = convert_vals,
                                 newVal = convert_vals_to)
  }






  allNames1 <- names(dat1)
  allNames2 <- names(dat2)

  sampleNames1 <- allNames1[which(!(allNames1) %in% nonSampleCols1)]
  sampleNames2 <- allNames2[which(!(allNames2) %in% nonSampleCols2)]

  nonSampleNames1 <- allNames1[which((allNames1) %in% nonSampleCols1)]
  nonSampleNames2 <- allNames2[which((allNames2) %in% nonSampleCols2)]

  # check to see if here is some column that matches the the nonSampleCols
  # This is needed to not throw an error if trying to negatively select 0 columns
  # If there isn't, then add a temporary one as the first column.
  addedID1 = FALSE
  if(length(nonSampleNames1)==0){
    dat1 <- data.frame(cbind("tempID" = rep(1,nrow(dat1)), dat1))
    nonSampleCols1 = "tempID"
    addedID1 = TRUE
  }


  addedID2 = FALSE
  if(length(nonSampleNames2)==0){
    dat2 <- data.frame(cbind("tempID" = rep(1,nrow(dat2)), dat2))
    nonSampleCols2 = "tempID"
    addedID2 = TRUE
  }

  nonSampleColIndex1 <- which(names(dat1) %in% nonSampleCols1)
  nonSampleColIndex2 <- which(names(dat2) %in% nonSampleCols2)

  nSamples1 <- ncol(data.frame(dat1[,-nonSampleColIndex1]))
  nSamples2 <- ncol(data.frame(dat1[,-nonSampleColIndex1]))

  if(nSamples1 != nSamples2){
    stop("Different number of sample columns. Did you specify the nonSampleCol1 and 2 correctly?")
  }

  #keep for later to append back
  nonSampleData1ToKeep <- data.frame(dat1[,nonSampleColIndex1])
  names(nonSampleData1ToKeep) <- names(dat1)[nonSampleColIndex1]




  if(arrangeByName == TRUE & arrangeByColOrder == FALSE){

    if(nSamples2 == 1){
      sampleNames1.1 = sampleNames2
    } else {
      sampleNames1.1 = sampleNames1
    }

    namesToUseOnceCombined <- colnames(dat1)[colnames(dat1) %in% sampleNames1]
    dat1 <- dat1[,sampleNames1]
    dat2 <- dat2[,sampleNames1.1]


  } else {

    namesToUseOnceCombined <- names(dat1)[-nonSampleColIndex1]
    dat1 <- dat1[,-nonSampleColIndex1]
    dat2 <- dat2[,-nonSampleColIndex2]

  }





  if(calcFun %in% c("binomial", "mean","average")){
    datCombined <- data.frame((dat1 + dat2) / 2)
  }

  if(calcFun == "sum"){
    datCombined <- data.frame((dat1 + dat2))
  }

  if(calcFun == "diff"){
    datCombined <- data.frame((dat1 - dat2))
  }

  if(calcFun == "mult" | calcFun == "prod"){
    datCombined <- data.frame((dat1 * dat2))
  }

  if(calcFun == "divide"){
    datCombined <- data.frame((dat1 / dat2))
  }



  names(datCombined) <- namesToUseOnceCombined





  if(combineConservatively == TRUE){ #rounds 0.5 down to 0
    myFun <- function(vec){as.integer(round(vec,digits=0))}
  } else {
    myFun <- function(vec){as.integer(ceiling(vec))}
  }


  #Run this only if integer data. otherwise, this can be used for averaging the
  #data across the data sets.
  if(isIntegerData == TRUE | calcFun == "binomial"){
    datCombined <- apply(X = datCombined,
                                MARGIN = 2,
                                FUN = myFun) %>% tbl_df()
  }

  if(addedID1 == FALSE){
    toReturn <-
      data.frame(
        cbind(nonSampleData1ToKeep,
              datCombined)
        )

  } else {
    toReturn <- datCombined
  }

  if(!is.null(colNamesToReturn)){
    if(length(colNamesToReturn) == ncol(toReturn)){
      if(arrangeByColOrder == TRUE | length(sampleNames1) ==1){
        names(toReturn) <- colNamesToReturn
      }
    }
  }

  return(toReturn)

}



#' Effectively the same as vs.combineData but defaults assuming binomial hit data of zeros and ones.
#'
#' @inheritParams vs.combineData
#'
#' @export
vs.combineHits <- function(hits1,
                           hits2,
                           nonSampleCols1 = c("id","input"),
                           nonSampleCols2 = NULL,
                           arrangeByName = TRUE,
                           arrangeByColOrder = FALSE,
                           colNamesToReturn = NULL,
                           combineConservatively = TRUE,
                           convert_NAs_to = NULL,
                           convert_nulls_to = NULL,
                           convert_vals = NULL,
                           convert_vals_to = NULL,
                           ...){
  return(
    vs.combineData(dat1 = hits1,
                   dat2 = hits2,
                   nonSampleCols1 = nonSampleCols1,
                   nonSampleCols2 = nonSampleCols2,
                   arrangeByName = arrangeByName,
                   arrangeByColOrder = arrangeByColOrder,
                   colNamesToReturn = colNamesToReturn,
                   combineConservatively = combineConservatively,
                   isIntegerData = TRUE,
                   calcFun = "binomial",
                   convert_NAs_to = convert_NAs_to,
                   convert_nulls_to = convert_nulls_to,
                   convert_vals = convert_vals,
                   convert_vals_to = convert_vals_to))
}








#
#
#
# library(dplyr)
#  set.seed(1001)
#  myDat1 <-
#  data.frame(id = c(1:20)) %>%
#  mutate(input = id*4) %>%
#  mutate(
#  samp1 = runif(n = nrow(.),0,1),
#  samp2 = runif(n = nrow(.),0,1),
#  samp3 = runif(n = nrow(.),0,1),
#  samp4 = runif(n = nrow(.),0,1))
#
#  myDat2 <-
#  data.frame(id = c(1:20)) %>%
#  mutate(input = id*4) %>%
#  mutate(
#  samp1.1 = runif(n = nrow(.),0,1),
#  samp2.1 = runif(n = nrow(.),0,1),
#  samp3.1 = runif(n = nrow(.),0,1),
#  samp4.1 = runif(n = nrow(.),0,1))
#
#  hits1 = vs.makeBinomP(pVals = myDat1,
#             pThresh = .1,
#             greaterThan=TRUE,
#             nonSampleCols = c("id","input"))
#
#  hits2 = vs.makeBinomP(pVals = myDat2,
#             pThresh = .1,
#             greaterThan=TRUE,
#             nonSampleCols = c("id","input"))
#
# #DIFFERENT SAMPLE NAMES, SAME ORDER OF COLS
#  vs.combineData(dat1 = hits1,
#                 dat2 = hits2,
#                 nonSampleCols1 = c("id","input"),
#                 arrangeByName = FALSE,
#                 combineConservatively = TRUE,
#                 isIntegerData = TRUE,
#                 calcFun = "diff")
#
#  #Change order of columns of myDat2 but havesame sample names in data
#
#  myDat3 <-
#  data.frame(id = c(1:20)) %>%
#  mutate(input = id*4) %>%
#  mutate(
#  samp1 = runif(n = nrow(.),0,1),
#  samp4 = runif(n = nrow(.),0,1),
#  samp2 = runif(n = nrow(.),0,1),
#  samp3 = runif(n = nrow(.),0,1))
#
#  hits3 = vs.makeBinomP(pVals = myDat3,
#             pThresh = .1,
#             greaterThan=TRUE,
#             nonSampleCols = c("id","input"))
#
#  vs.combineHits(hits1 = hits1,
#                 hits2 = hits3,
#                 arrangeByName = TRUE)
