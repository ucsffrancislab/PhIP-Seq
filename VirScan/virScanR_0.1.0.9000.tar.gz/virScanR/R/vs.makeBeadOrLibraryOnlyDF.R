#-------------------------------------------------------------------------------
#vs.makeBeadOrLibraryOnlyDF
#-------------------------------------------------------------------------------
#' @importFrom magrittr %>%
#' @export
vs.makeBeadOrLibraryOnlyDF <- function(paramsList,
                                       libraryOnly = FALSE,
                                       beadsOnly = TRUE){

  path = paramsList$path
  inputLibrary = paramsList$inputLibrary
  libraryAmpDate = paramsList$libraryAmpDate
  protocol = paramsList$protocol
  pi = paramsList$pi
  studyName = paramsList$studyName
  plates = paramsList$plates
  labLead = paramsList$labLead



  if(libraryOnly == TRUE | beadsOnly == FALSE){
    virScanInfo <- vs.getKeysList(path = path)$virScanKey %>%
      dplyr::filter(librarySample == 1)
  } else {
    virScanInfo <- vs.getKeysList(path = path)$virScanKey %>%
      dplyr::filter(beadsOnly == 1)
  }


  sampInfo <- vs.getKeysList(path = path)$samplesKey %>%
    dplyr::mutate(unique_sample_id = as.character(unique_sample_id))

  #Get all samples that used all same protocol and supplies

  if(!is.null(inputLibrary)){
    virScanInfo <- virScanInfo %>% dplyr::filter(inputLib %in% inputLibrary)
  }

  if(!is.null(libraryAmpDate)){
    virScanInfo <- virScanInfo %>% dplyr::filter(libAmpDate %in% libraryAmpDate)
  }

  if(!is.null(protocol)){
    virScanInfo <- virScanInfo %>% dplyr::filter(protocol %in% protocol)
  }

  if(!is.null(plates)){
    virScanInfo <- virScanInfo %>% dplyr::filter(plateName %in% plates)
  }

  if(!is.null(labLead)){
    virScanInfo <- virScanInfo %>% dplyr::filter(labLead %in% labLead)
  }

  virScanInfo <-
    virScanInfo %>%
    dplyr::left_join(sampInfo %>%
                       dplyr::select(unique_sample_id, timePoint),
                     by = "unique_sample_id") %>%
    unique()


  allNames <- names(virScanInfo)
  namesFirst <-
    c("PI",
      "studyName",
      "individual",
      "dilution_other_change",
      "fullName",
      "replicate_fullname",
      "inputLib",
      "protocol",
      "libAmpDate",
      "plateName")

  keepNamesFirst <- namesFirst[which(namesFirst %in% allNames)]
  allNames2 <- allNames[-which(allNames %in% keepNamesFirst)]
  namesOrdered <- c(keepNamesFirst, allNames2)

  if(returnAllCols == TRUE){

    return(virScanInfo %>% dplyr::select(namesOrdered))

  } else {

    return(virScanInfo %>% select(fullName, replicate_fullname))
  }

}
