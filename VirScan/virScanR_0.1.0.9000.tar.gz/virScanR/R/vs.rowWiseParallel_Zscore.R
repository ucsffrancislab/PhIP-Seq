
#' Function to calculate rowWise Z scores
#'
#' @param data Data across which to calculate Z scores
#' @param baseCols columns NAMES to use to create the mean and stDev. These
#'   would be, for example, the beads only runs if calculating Z scores from
#'   some control beads. Or alternatively some control condition. If not
#'   specified and meanVec and sdVec are not specified, then all columns will be
#'   used to construct the Null distribution and all columns will be judged
#'   based on the distribution of all of the columns.
#' @param meanVec,sdVec Instead of supplying baseCols, can supply two vectors,
#'   one a vector of means and the other a vector of standard deviations. the
#'   Length of both of these vectors should equal the number of rows of data.
#' @param cores The number of cores to use. Requires parallel package (DEFAULT
#'   is parallel::detectCores()). To run without parallel processing, set cores
#'   to 1 and it will use base R.
#' @param removeOutliersFromBase Should outliers be removed from the base cols
#'   before calculating meand and sd for Z score calculations
#' @param na.rm If using baseCols to calculate the mean and standard deviations
#'   for the Z score calculations, should NA's be removed from these two
#'   calculations. Useful, for example, when outliers are removed and converted
#'   to NA, for example with \code{\link{vs.outliers_to_XX_rowWise}}
#' @param return Returns a data frame, the same size as data, but converted to Z
#'   scores.
#' @inheritParams vs.rowFXN_NoOutlier
#'
#' @export
vs.rowWiseParallel_Zscore <- function(data,
                                      baseCols = NULL,
                                      meanVec = NULL,
                                      sdVec = NULL,
                                      cores = parallel::detectCores(),
                                      removeOutliersFromBase = FALSE,
                                      outlierLimit = 1.5,
                                      na.rm = TRUE){

  if(!is.null(meanVec) & !is.null(sdVec) & is.null(baseCols)){
    if(length(meanVec) != length(sdVec)){
      stop("meanVec and sdVec must be the same lengths")
    } else if(length(meanVec) != nrow(data)){
      stop("meanVec and sdVec must have lengths equal to the rows in data")
    }
  } else if(!is.null(baseCols)){
    inIndex <- which(baseCols %in% names(data))
    if(length(inIndex) < length(baseCols) &
       length(inIndex) > 0){
      warning("Warning: Not all baseCols were found in the data. Using those that were found.")
      baseCols <- baseCols[inIndex]
    } else if(length(inIndex) == 0){
      stop("No baseCols found as columns in the data.")
    }
  } else if(is.null(baseCols) & is.null(meanVec) & is.null(sdVec)){
    baseCols <- names(data)
    warning("Using all columns to calculate base distribution.")
  }

  whatClassAll <- class(data)
  whatClass <- whatClassAll[1]

  if(whatClass != "data.table"){
    data <- data.table::setDT(data)
  }


  if(removeOutliersFromBase == TRUE){
    noOutlierRemoval = FALSE
  } else {
    noOutlierRemoval = TRUE
  }
  if(!is.null(baseCols)){
    meanVec <- vs.rowFXN_NoOutlier(data = data,
                                   rowFun = mean,name = "mean",
                                   cores = cores,
                                   returnAsVector = TRUE,
                                   cols_to_evaluate = baseCols,
                                   outlierLimit = outlierLimit)



    sdVec <- vs.rowFXN_NoOutlier(data = data,
                                 rowFun = sd,
                                 name = "sd",
                                 cores = cores,
                                 returnAsVector = TRUE,
                                 cols_to_evaluate = baseCols,
                                 outlierLimit = outlierLimit)
  }

  if(cores>1 &
     (requireNamespace(package = "parallel")==FALSE)){
    Zscores <- data.table::copy(data)[ ,
                                       parallel::mclapply(.SD,
                                                          FUN = function(X,meanVec,sdVec){
                                                            (X-meanVec)/sdVec
                                                          },
                                                          meanVec = meanVec,
                                                          sdVec = sdVec,
                                                          mc.cores = cores)
                                       ]

  } else {
    Zscores <- data.table::copy(data)[ ,
                                       lapply(.SD,
                                              FUN = function(X,meanVec,sdVec){
                                                (X-meanVec)/sdVec
                                              },
                                              meanVec = meanVec,
                                              sdVec = sdVec
                                       )]
  }




  if(whatClass != "data.table"){
    data.table::setDF(Zscores)
  }
  data.table::setattr(Zscores, "class", whatClassAll)
  return(Zscores)
}
