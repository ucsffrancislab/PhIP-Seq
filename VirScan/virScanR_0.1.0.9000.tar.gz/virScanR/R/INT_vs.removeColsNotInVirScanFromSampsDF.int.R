#INTERNAL FUNCTION ONLY.
#' @importFrom magrittr %>%
vs.removeColsNotInVirScanFromSampsDF.int <- function(sampsDF,
                                                     colNames) {
  colsNotAvailable <-
    sampsDF$full_name[which(!sampsDF$full_name %in% colNames)]

  return(sampsDF %>% dplyr::filter(!full_name %in% colsNotAvailable))

}
