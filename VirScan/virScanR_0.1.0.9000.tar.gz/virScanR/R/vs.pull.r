#------------------------------------------------------------------------------#
# sql.pullVS
#------------------------------------------------------------------------------#
#' The Major data pull function for VirScan data
#'
#' #Gathers requested virScan data and spits out the data aligned to the input
#' libary of interest - ensures data is in the correct row order per the input
#' libary of interest - the user can also supply here  a new input libary that
#' is not yet in the SQL data base....
#'
#' @family database connections
#'
#' @param sampsDF A data frame with at least one column called \code{fullName}
#'   which has the names of the table columns desired. Can be used instead of
#'   columns. Columns however will overwrite sampsDF if they are both declared
#'
#' @param table String: the name of the table inside the DB to get.
#'
#' @param columns Which columns to collect. Requires columns names, i.e. from
#'   \code{sql.listTableCols()} or supplying \code{sampsDF}. If none are listed,
#'   it will default to pulling all of the columns. \code{columns} overwrides
#'   \code{sampsDF}
#'
#' @param includeInputCounts TRUE/FALSE. Should the input Counts be sought out
#'   and returned as the second column (after \code{id} and before the requested
#'   sample data). If so, then \code{inputLib_table, inputLib_colName} and -
#'   optionally - \code{inputLibDB_path} should be filled in, or a custom or new
#'   input library should be input as the input to \code{newInputLibDF}.
#'   DEFAULTS TO FALSE.
#'
#' @param nrows,rows,ids,allRows How many or which rows or \code{ids} to pull.
#'   Defaults to the first 5. Can give a vector of specific epitope IDs using
#'   \code{ids = c(1,2,3....115000...)} to grab specific ids if desired. Of
#'   course, the table requires an \code{id} column and will throw an error if
#'   not. Can alternatively set nrows to any number to get the equivalent of
#'   \code{head(data, nrows)}.Or, can set \code{rows}. If using \code{rows}, you
#'   can include specific rows to grab. But this can be slow. It requires that
#'   an "id" variable be included and throws an error if it is not there. This
#'   is because the only way to get specific rows declared solely by row number
#'   is to collect the full dataframe first and then grab the rows as per usual
#'   for a data.frame() object. However, if there is an "id" column, it will
#'   first collect the "id" column and then figure out which \code{ids}
#'   correspond to the desired \code{rows} requested and will then filter for
#'   those before \code{collect()}-ing the data. Therefore, it requires
#'   \code{id} column and if it's not there, then it is best to set rows to NULL
#'   and explicitly select the rows from the output data.frame() afterwards.
#'   Finally, if \code{allRows} is set to \code{TRUE} it will collect all of the
#'   rows.
#'
#' @param inputLibDB_path,inputLib_table,inputLib_colName,inputLibDB_path,newInputLibDF
#'   If \code{includeInputCounts = TRUE} then at least the \code{inputLib_table}
#'   and \code{inputLib_colName} must be filled in, or a custom or new input
#'   library should be input as the input to \code{newInputLibDF}. If
#'   inputLibDB_path is NULL, it will default to \code{path}.
#'   \code{inputLib_table} and \code{inputLib_colName} are strings that should
#'   be the names of the SQL table of the input libraries and the column name of
#'   the specific input counts desired. If \code{newInputLibDF} is not NULL
#'   (Default) then it should be a \code{data.frame} with two columns:
#'   \code{c("id","myInputLibrary")}. It will prioritize \code{newInputLibDF} if
#'   not NULL, over searching for \code{inputLib_table} etc. Therfore,
#'   \code{newInputLibDF} is useful if you have a curated subset of virScan
#'   epitopes with input Library counts or something that you'd like to pull.
#'   Finally, if \code{inputLibDB_path} is not \code{NULL} (the default) then it
#'   will look in the new path for a new SQL database to find the
#'   \code{inputLib_table & inputLib_colName}.  Of NOTE: for any of these
#'   options, \code{includeInputCounts} must be TRUE and the data that will be
#'   output will be only data with epitope IDs that match the input Counts that
#'   are found or provided.
#'
#' @param returnColsNotAvailable Should a vector of columns requested but not
#'   available in the database be returned? If this is set to true, then the
#'   output is a list and this vector is the second element of the list.
#'
#' @param keepInputLibNameIntact Should the input library that is retrieved keep
#'   the name of the library used or be changed to \code{"input"}. Default has
#'   it change to "input" so it can be used easily in other functinos that only
#'   recognize the second column as "input" for downstream calculations.
#'   Therefore, it's up to the user to know what the input library requested
#'   was.
#'
#' @param convert_NAs_To Should the \code{NAs} in the SQL data that is pulled
#'   out, if any, be converted to something. The Default is \code{NULL}. However
#'   if this is set to anything else, the NA's will be converted to this value.
#'   ie (0,1,"hello"...)
#'
#' @param type,typeInputDB The type of the data bases.
#'
#' @importFrom magrittr %>%
#' @inheritParams mmR::mm.fastread2
#'
#' @return Returns a list with either one or two elements. If
#'   \code{returnColsNotAvailable = TRUE} then it will return a list with two
#'   elements and the second element will be any column names or sample names
#'   that were not available in the requested table. If
#'   \code{returnColsNotAvailable = FALSE} however, it will return just a single
#'   element list with the requested data as the single element. The returned
#'   data will alwasy have \code{id} as the first column and, if
#'   \code{includeInputCounts = TRUE} then it will have the input counts as the
#'   second column and defaults to \code{keepInputLibNameIntact = FALSE} which
#'   makes the name of the second column simply \code{input} rather than the
#'   name of the actual input library requested. The following column are all
#'   the requested data.
#'
#'
#'
#' @seealso sql.listTables, sql.listTableCols
#'
#' @examples
#' \dontrun{
#'
#' myPath <- "./path/to/db.sqlite"
#'
#'
#' inputLibraries <- sql.getTableCols(myPath, "inputLibs")
#' inputColName <- inputLibraries[8]
#' InputLib <-
#'   sql.pull(path = myPath,
#'   getInputLibOnly = TRUE,
#'   inputLib_table = "inputLibs",
#'   inputLib_colName = inputColName)
#' }
#'
#' @export
vs.pull <- function(path,
                     table,

                     #which samples
                     sampsDF = NULL,
                     columns = NULL,

                     #which rows or epitope IDs
                     nrows = NULL,
                     rows = NULL,
                     ids = NULL,
                     allRows = FALSE,

                     #should input Counts be returned?
                     includeInputCounts = FALSE, #TRUE
                     inputLibDB_path = NULL, #Need not be entered
                     inputLib_table = NULL, #"inputLibs"
                     inputLib_colName = NULL, #"inputCombined"
                     #or
                     newInputLibDF = NULL,

                     returnColsNotAvailable = FALSE, #TRUE
                     keepInputLibNameIntact = FALSE,
                     convert_NAs_To = NULL,
                     typeInputDB = NULL,
                     type = NULL,
                    search = FALSE,
                    includeSubDirectories = TRUE,
                    returnOnlyFirstInstance = TRUE,
                    keyColumn = "id",
                    ...){



  newInputDFNames = NULL
  inputPathSameAsCounts = FALSE
  inputTableSameAsCounts = FALSE
  collectInputWithSampleCounts = FALSE
  #Get the input library - necessary to align the counts
  if( includeInputCounts == TRUE ){

    if( !is.null(newInputLibDF) ) {

      newInputDFNames <- names(newInputLibDF)

      if(newInputDFNames[1] != keyColumn){
        stop(paste0("newInputLibDF must have '",keyColumn,"' as the first column"))
      }

      if((!(inputLib_colName %in% newInputDFNames)) & ncol(newInputLibDF)>2){
        stop("inputLib_colName not found in the newInputLibDF data.frame and there are >2 columns.
             Must specify appropriate column name to use for the input library")
      }

      data.table::setDF(newInputLibDF)
      inputLib = newInputLibDF[ , c(keyColumn,inputLib_colName)]

      if(keepInputLibNameIntact == FALSE){
        names(inputLib) <- c(keyColumn,"input")
      }

    }


    if( is.null(newInputLibDF) ) {#if newInputLibDF is null

      #Defaults to have the input library table in the same db as the data.
      #but if it's not null, it will look in inputLibDB_path for the input
      #library table
      if( is.null( inputLibDB_path  ) ) {
        inputLibDB_path = path
        inputPathSameAsCounts = TRUE
      }

      if( is.null(inputLib_table)) {
        inputLib_table = table
        inputTableSameAsCounts = TRUE
      }

      if(is.null(inputLib_colName)) {
        newInputDFNames <- mm.listTableCols(path = inputLibDB_path,
                                            table = inputLib_table)
        
        if(newInputDFNames[1] != keyColumn){
          stop(paste0("The input library must have ",keyColum," as the first column"))
        }

        if(length(newInputDFNames)>2){
          stop("input library has >2 columns and inputLib_colName is not defined. Please provide a column name to use for the input library.")
        }

        inputLib_colName <- newInputDFNames[2]
      } else {

        newInputDFNames <- mm.listTableCols(path = inputLibDB_path,
                                            table = inputLib_table)

        if(!(inputLib_colName %in% newInputDFNames)){
          stop("inputLib_colName not found")
        }
      }


      if(inputPathSameAsCounts == TRUE & inputTableSameAsCounts == TRUE){
        collectInputWithSampleCounts = TRUE
      } else {

        inputLib <- vs.fastread(path = inputLibDB_path,
                                table = inputLib_table,
                                sampsDF = NULL,
                                columns = unique(c(keyColumn,inputLib_colName)),
                                header = TRUE,
                                nrows = nrows,
                                allRows = allRows,
                                rows = rows,
                                ids = ids,
                                return_id_col = TRUE,
                                returnColsNotAvailable = TRUE,
                                search = FALSE,
                                includeSubDirectories = TRUE,
                                returnOnlyFirstInstance = TRUE,
                                keyColumn = keyColumn)


        #write.csv(inputLib[[1]], inputLibDB_path = "~/Desktop/test.csv")


        if(length(inputLib$columns_not_available) > 0 ){

          stop("REQUESTED INPUT LIBRARY NOT AVAILABLE")

        } else {
          inputLib <- inputLib$table
        }

        if(keepInputLibNameIntact == FALSE){
          names(inputLib) <- c("id","input")
        } else {
          names(inputLib)[1] <- "id"
        }
      } #end reading in inputLib with vs.fastread

    } #end new inputLibrary counts



    #Change ids here so that the samples that are pulled
    #only include ids that were pulled with the input library
    #(if the inputLibrary was asked to be included.)
    if(collectInputWithSampleCounts == FALSE){
      ids <- inputLib$id
    }


    if(collectInputWithSampleCounts == TRUE){
      if (!is.null(sampsDF) & is.null(columns)) {
        if ("full_name" %in% names(sampsDF)) {
          columns <- sampsDF$full_name
        }
        else {
          columns <- sampsDF[, 1]
        }
      }
      columns <- unique(c(inputLib_colName, columns))
    }
  } #end "includeInputCounts == TRUE" portion


  if(includeInputCounts == FALSE){

      if (!is.null(sampsDF) & is.null(columns)) {
        if ("full_name" %in% names(sampsDF)) {
          columns <- sampsDF$full_name
        } else {
          columns <- sampsDF[, 1]
        }
      }
      columns <- unique(columns)
  } #End IncludeInputCounts ==FALSE




  df <- vs.fastread(path = path,
                      table = table,
                      sampsDF = NULL,
                      header = TRUE,
                      columns = columns,
                      nrows = nrows, #NULL
                      rows = rows, #NULL
                      allRows = FALSE,
                      ids = ids,
                      return_id_col = TRUE,
                      returnColsNotAvailable = TRUE,
                      type = type,
                      search = search,
                      includeSubDirectories = includeSubDirectories,
                      returnOnlyFirstInstance = returnOnlyFirstInstance,
                      keyColumn = keyColumn)


  if(includeInputCounts == TRUE){
    if(collectInputWithSampleCounts == TRUE){
      if(keepInputLibNameIntact == FALSE){
        names(df$table) <- c("id","input",names(df$table)[-c(1:2)])
      }
    }
  }
  names(df$table)[1] <- "id"

  columns_not_available <- df$columns_not_available
  df <- df$table



  if(includeInputCounts == TRUE){
    if(collectInputWithSampleCounts == FALSE){
      df <-
        inputLib %>% dplyr::mutate(id = as.character(id)) %>%
        dplyr::left_join(df %>% dplyr::mutate(id = as.character(id)),
                         by = "id")
    }
  }

  names(df)[1] <- keyColumn


  #Remove NAs and convert to Zeros for pvals or counts
  if(!is.null(convert_NAs_To)){
    for(i in 2:ncol(df)){
      naIndex <- which(is.na(df[,i]))
      df[naIndex,i] = as.integer(convert_NAs_To)
    }
  }

  if(returnColsNotAvailable == TRUE){
    return(list(table = df,
                columns_not_available = columns_not_available))
  } else {
    return(list(table = df))
  }
}





#Defaults
# path
# table
#
# #which samples
# sampsDF = NULL
# columns = NULL
#
# #which rows or epitope IDs
# nrows = NULL
# rows = NULL
# ids = NULL
# allRows = FALSE
#
# #should input Counts be returned?
# includeInputCounts = FALSE #TRUE
# inputLibDB_path = NULL #Need not be entered
# inputLib_table = NULL #"inputLibs"
# inputLib_colName = NULL #"inputCombined"
# #or
# newInputLibDF = NULL
#
# returnColsNotAvailable = FALSE #TRUE
# keepInputLibNameIntact = FALSE
# convert_NAs_To = NULL
# typeInputDB = NULL
# type = NULL
#
