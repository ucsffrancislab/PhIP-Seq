#------------------------------------------------------------------------------#
# Function to calculate enrichments
#------------------------------------------------------------------------------#
#' Function to set the parameters for vs.calculate_enrichments.
#'
#' The data frame must be set up with colums names: ("id","input","sample1
#' counts, sample2 counts, etc...)
#'
#' @inheritParams vs.calc_enrichment.int
#' @inheritParams vs.calc_enrichment_chunks
#' @param groupTogetherIfGreaterThanGroupSize If there are greater than
#'   \code{groupSize} ids with a specific input count, should these be grouped
#'   together, rather than grouping together an arbitrary set of samples of
#'   \code{groupSize}. For example, if groupSize is set to 300 and there are 600
#'   ids with an input count of 1, then should all of these combine to make a
#'   single group, or should the 600 ids contribute arbitrarily to two different
#'   groups. If so, then all of the ids for which there are n > groupSize will
#'   make their own groups, and those ids left over will each make up groups of
#'   approximately ~groupSize numbers of ids.
#' @importFrom magrittr %>%
#' @export
vs.set_params_calculate_enrichments <-
   function(counts = NULL,
            groupSize = 300,
            groupTogetherIfGreaterThanGroupSize = TRUE,
            calculateEnrichmentByChunks = TRUE,
            idCol = "id",
            inputCol = "input",
            staggerChunk = FALSE,

            propExtremesToRemove = .1,
            convertZeroInput_To = NULL,
            convertZeroCounts_To = NULL){

     return(
       list(
         counts = counts,
         groupSize = groupSize,
         groupTogetherIfGreaterThanGroupSize = groupTogetherIfGreaterThanGroupSize,
         calculateEnrichmentByChunks = calculateEnrichmentByChunks,
         idCol = idCol,
         inputCol = inputCol,
         staggerChunk = staggerChunk,
         propExtremesToRemove = propExtremesToRemove,
         convertZeroInput_To = convertZeroInput_To,
         convertZeroCounts_To = convertZeroCounts_To
       ))

   }


#------------------------------------------------------------------------------#
# Function to calculate enrichments
#------------------------------------------------------------------------------#
#' Function to take a data frame and calculate enrichments from it.
#'
#' The data frame must be set up with colums names: ("id","input","sample1
#' counts, sample2 counts, etc...)
#'
#'
#' @importFrom magrittr %>%
#' @export
vs.calculate_enrichments <- function(paramsList,
                                     counts=NULL,
                                     inputCol = NULL,
                                     ...){

  #counts = paramsList$counts
  #inputCol = paramsList$inputCol
  if(is.null(counts)){counts = paramsList$counts}
  if(is.null(inputCol)){inputCol = paramsList$inputCol}

  counts <- data.frame(counts)

  groupSize = paramsList$groupSize

  groupTogetherIfGreaterThanGroupSize =
    paramsList$groupTogetherIfGreaterThanGroupSize

  calculateEnrichmentByChunks = paramsList$calculateEnrichmentByChunks
  idCol = paramsList$idCol
  inputCol = paramsList$inputCol
  staggerChunk = paramsList$staggerChunk
  propExtremesToRemove = paramsList$propExtremesToRemove
  convertZeroInput_To = paramsList$convertZeroInput_To
  convertZeroCounts_To = paramsList$convertZeroCounts_To


  if(calculateEnrichmentByChunks == FALSE){
    groupSize = nrow(counts)
    staggerChunk = FALSE
    print("Calculating enrichments without grouping by input")
  } else {
    print(paste("Calculating Enrichments by Chunks of ",groupSize))
  }

  #Creating grouping of the IDs...
  #can also do this directly inside vs.calc_enrichment_chunks

  groupedIDs <- vs.makeGroups(dataToGroup = counts,
                              groupSize = groupSize,
                              idCol = idCol,
                              groupingCol = inputCol,
                              staggerChunk = staggerChunk,
                              groupTogetherIfGreaterThanGroupSize =
                                groupTogetherIfGreaterThanGroupSize,
                              returnData = FALSE,
                              returnAs = "tibble")



  #countData = counts
  #groupingCol = inputCol
  enrichments <-
    vs.calc_enrichment_chunks3(
      countData = counts,
      groupedIDs = groupedIDs,
      groupSize = NULL,
      idCol = idCol,
      groupingCol = inputCol,
      groupTogetherIfGreaterThanGroupSize = groupTogetherIfGreaterThanGroupSize,
      propExtremesToRemove = propExtremesToRemove,
      convertZeroInput_To = convertZeroInput_To,
      convertZeroCounts_To = convertZeroCounts_To,
      staggerChunk = staggerChunk)




  return(enrichments)

}


