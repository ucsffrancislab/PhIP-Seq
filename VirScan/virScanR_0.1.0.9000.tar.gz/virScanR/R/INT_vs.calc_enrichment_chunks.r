#------------------------------------------------------------------------------#
#vs.calc_enrichment_chunks
#------------------------------------------------------------------------------#
#' Calculates enrichments based on chunks
#'
#' The chunks are based on the input counts, split over a certain number of
#' grouped IDs. The algorithm orders IDs by input library counts and then splits
#' it into chunks of \code{groupSie} length and calculates fold-enrichment
#' within that group.  See \code{\link{vs.calc_enrichment.int}} for more information
#' on how the enrichments are being calculated
#'
#' @inheritParams vs.calc_enrichment.int
#'
#' @param groupSize How many ID's should be grouped together to make up a chunk
#'   (Should be sufficient to create a null distribution).  If want the same
#'   result as vs.calc_enrichment.int, set groupSize to the number of distinct IDs
#'   (i.e. number of rows of the countData).  This will be input into the
#'   \code{\link{vs.makeGroups}} function. Alternatively can forego groupSize and
#'   provide the output if already created under groupedIDs.
#'
#' @param groupedIDs If already created groupedID dataframe using
#'   \code{\link{vs.makeGroups}}, can just provide the output object
#'   directly here and it will override the groupSize parameter.
#'   #'
#' @param staggerChunk Should the chunks be staggered. This will help to reduce
#'   bias that might occur within a given chunk. For example, if the input
#'   counts in a given chunk range from 10 to 50, and the fold enrichment is
#'   based on the counts / mean_chunk_counts, then those with an input of 50
#'   might be biased upwards towards a higher fold_enrichment compared to the
#'   mean of the group, and those with input counts of only 10 (bottom of the
#'   group), might be biased downards, towards a lower fold-enrichment.
#'   Staggering will help reduce this bias by creating two sets of groupedIDs,
#'   overlapping 50%.  So, if a chunk goes from 10:50 it's "parallel" chunk
#'   might go from 30:70 and therefore those IDs that were in the upper half of
#'   the first run would find themselves in the lower half of the parallel run.
#'   If this is used, two sets of all of the data will be output, and it is up
#'   to the user to decide how to deal with discrepencies - though some
#'   functions have been developed to help, like \code{\link{vs.combineData}} or
#'   \code{\link{vs.combineHits}}
#'
#' @return Returns nearly the identical as \code{\link{vs.calc_enrichment.int}} (so
#'   read that for more information, as it is the engine underlying this
#'   function) except that the "normalizers" element of the list is itself a
#'   list, containing... and this also returns the \code{groupedIDs} dataframe
#'   that was used to group and calculate the chunks. This is useful to be
#'   passed on directly to \code{\link{vs.getEnrichHits}} and
#'   \code{\link{vs.getEnrichHitsAll}} for example.
#'
#' @importFrom magrittr %>%
#' @export
vs.calc_enrichment_chunks <- function(countData,
                                      groupSize = 200,
                                      groupTogetherIfGreaterThanGroupSize = FALSE,
                                      groupedIDs = NULL,
                                      idCol = "id",
                                      groupingCol = "input",
                                      propExtremesToRemove = 0.05,
                                      staggerChunk = FALSE,
                                      convertZeroInput_To = NULL,
                                      convertZeroCounts_To = NULL,
                                      ...){


  idColIndex <- which(names(countData) == idCol)
  groupingColIndex <- which(names(countData) == groupingCol)[1]
  names(countData)[idColIndex] <- "id"
  names(countData)[groupingColIndex] <- "input"

  originalOrder <- tbl_df(countData %>% select(id))


  if(is.null(groupedIDs)){
    groupedIDs <-
      vs.makeGroups(dataToGroup = countData,
                        groupSize = groupSize,
                        groupTogetherIfGreaterThanGroupSize =
                          groupTogetherIfGreaterThanGroupSize,
                        idCol = "id",
                        groupingCol = "input",
                        staggerChunk = staggerChunk,
                    returnData = FALSE,
                    returnAs = "tibble")
  }

  #X = 15
  tempChunkList <-
    parallel::mclapply(X = sort(unique(groupedIDs$group)),
                       FUN = vs.enrichOnGroupsFxn.int, #defined below
                       groupedIDs = groupedIDs,
                       countData = countData,
                       propExtremesToRemove = propExtremesToRemove,
                       convertZeroInput_To = convertZeroInput_To,
                       convertZeroCounts_To = convertZeroCounts_To,
                       mc.cores = parallel::detectCores()-1)



  normalizerList <- list()
  enrichList     <- list()
  lnEnrichList   <- list()
  probEnrichList <- list()
  j = 1
  for(j in 1:length(tempChunkList)){
    normalizerList[[j]] <- tempChunkList[[j]]$normalizers %>% dplyr::mutate(group = j)
    enrichList[[j]] <- tempChunkList[[j]]$enriched
    lnEnrichList[[j]] <- tempChunkList[[j]]$lnEnriched
    probEnrichList[[j]] <- tempChunkList[[j]]$probEnriched
  }


  enriched <-
    originalOrder %>%
    left_join(data.table::rbindlist(enrichList), by = "id") %>%
    dplyr::tbl_df()

  lnEnriched <-
    originalOrder %>%
    left_join(data.table::rbindlist(lnEnrichList), by = "id") %>%
    dplyr::tbl_df()


  probEnriched <-
    originalOrder %>%
    left_join(data.table::rbindlist(probEnrichList), by = "id") %>%
    dplyr::tbl_df()


  normalizers <-
    data.table::rbindlist(normalizerList) %>%
    dplyr::tbl_df()

  #the normalizer to multiply the input counts by to get them on the same scale
  #as the counts. One for each group produced by vs.makeGroups()

  normalizer <-
    normalizers %>%
    select(full_name, group, normalizer) %>%
    tidyr::spread(full_name,normalizer)

  #the average of the natural log of the fold enrichments for each group
  avgLnFoldEnrich <-
    normalizers %>%
    select(full_name, group, avgLnFoldEnrich) %>%
    tidyr::spread(full_name,avgLnFoldEnrich)

  #the SD of the natural log of the fold enrichments for each group
  sdLnFoldEnrich <-
    normalizers %>%
    select(full_name, group, sdLnFoldEnrich) %>%
    tidyr::spread(full_name,sdLnFoldEnrich)


  idColIndexEnriched <- which(names(enriched) == "id")
  idColIndexLnEnriched <- which(names(lnEnriched) == "id")
  idColIndexProbEnriched <- which(names(probEnriched) == "id")

  names(enriched)[idColIndexEnriched] <- idCol
  names(lnEnriched)[idColIndexLnEnriched] <- idCol
  names(probEnriched)[idColIndexProbEnriched] <- idCol


  groupingColIndexEnriched <- which(names(enriched) == "input")
  groupingColIndexLnEnriched <- which(names(lnEnriched) == "input")
  groupingColIndexProbEnriched <- which(names(probEnriched) == "input")

  names(enriched)[groupingColIndexEnriched] <- groupingCol
  names(lnEnriched)[groupingColIndexLnEnriched] <- groupingCol
  names(probEnriched)[groupingColIndexProbEnriched] <- groupingCol


  return(list(enriched = enriched,
              lnEnriched = lnEnriched,
              probEnriched = probEnriched,
              normalizers = list(normalizers = normalizer,
                                 avgLnFoldEnrich = avgLnFoldEnrich,
                                 sdLnFoldEnrich = sdLnFoldEnrich),
              groupedIDs = groupedIDs))
}





#INTERNAL
#' @importFrom magrittr %>%
vs.enrichOnGroupsFxn.int <- function(X,
                                     groupedIDs,
                                     countData,
                                     propExtremesToRemove,
                                     convertZeroInput_To = NULL,
                                     convertZeroCounts_To = NULL){

  #X=0
  IDsToGet <- groupedIDs[which(groupedIDs$group == X), ]
  countChunk <- countData[which(countData$id %in% IDsToGet$id), ]

  return(
    vs.calc_enrichment.int(countData = countChunk,
                       inputCounts = NULL, #captures all inputs for the chunk
                       propExtremesToRemove = propExtremesToRemove,
                       convertZeroInput_To = convertZeroInput_To,
                       convertZeroCounts_To = convertZeroCounts_To,
                       cores = 1)
  )
}
