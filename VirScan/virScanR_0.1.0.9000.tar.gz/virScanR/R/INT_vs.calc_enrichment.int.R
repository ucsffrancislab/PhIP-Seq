#------------------------------------------------------------------------------#
#Calculates enrichment from counts data where first column is id,
#second column is input counts
#and rest of the columns are sample counts

#additionally requires 'inputCounts' - a vector of input Counts to normalize
#against...

#gives back a list
# [[1]] : enrichments
# [[2]] : normalizers used to get the enrichments
#------------------------------------------------------------------------------#
#countData <- data[["countsSplit"]][[1]]
#countData <- data[["counts"]]
#inputCounts <- c(100:120)

#' Calculate enrichments from count data.
#'
#' Assumes that the majority of count data is part of the NULL distribution, and
#' calculates everything as a fold-enrichment away from the mean of the NULL
#' distribution. So, will calculate the mean of all of the counts (might remove
#' extremes if propExtremesToRemove is set to something >0) and then calculate
#' each samples counts as a fold enrichment away from the mean of all of the
#' counts. If a specific input range (\code{inputCounts}) is not specified
#' directly here, and the input counts have a wide range, then should be called
#' with \code{\link{vs.calc_enrichment_chunks}} instead. A specific input Count
#' range (for which ID's are potentially comparable) can be inserted directly.
#' Essentially you want to compare like to like. So it wouldn't make sense to
#' calculate the fold-enrichment for each ID compared to the mean of the entire
#' distribution of input counts... all The high input library counts would
#' probably have samples that are significant for those IDs, and all of the low
#' ones would not.
#'
#' Also, Calculates p_Values (output as probEnriched) as
#' pnorm(log_fold_enrichment, mean = mean_log_fold_enrichment of all the values
#' assesssed, sd = sd_log_fold_enrichment).  Might update this to check the
#' distribution and compare off of a zero-inflated negative binomial or gamma
#' etc. This is done in the function called \code{normalizedEnrichment_tempFXN},
#' which is an internal function only.
#'
#' @param countData The data frame of NGS count data to calculate
#'   fold-enrichment. Requires that the count data have at least an "id" and
#'   "input" column and then at least one sample
#'
#' @param inputCounts The input counts to limit the assessment to. For example,
#'   if only want to get fold-enrichment of those IDs with an input count of
#'   c(44:46). Default is NULL and looks at all levels of input count
#'   simultaneously
#'
#' @param propExtremesToRemove What proportion of extreme values to remove when
#'   estimating the null distribution? This helps in case there is a large
#'   outlier. Generally OK to remove 0.05 or 5% on either end to make sure
#'   you're getting rid of outliers (i.e. potential 'hits') when getting the
#'   background or NULL distribution
#'
#' @param convertZeroInput_To,convertZeroCounts_To How to deal with zeros in the
#'   input library counts or the output. Can, for example, change any input
#'   counts that are 0 to 0.1 to allow at least some fold-enrichment to be
#'   calculated off of the, if there are any sample runs with counts for those
#'   same IDs. Similar idea for convertZeroCounts_To... although probably best
#'   to leave at zero for that one.
#'
#' @param cores How many cores to use when processing in paralle. If no parallel
#'   processing desired - set to one.
#'
#'
#' @return Returns a list of length 4, each with a dataframe containing the (1)
#'   \code{enriched}: the fold-enrichments, (2) \code{lnEnriched}: the ln of the
#'   fold enrichments - this is what was used to calculate p-values, and (3)
#'   \code{probEnriched}: the p-values associated with the enrichments; (4)
#'   \code{normalizers}: normalizing values  used to calculate the
#'   fold_enrichments (not particularly useful to the user). The first column of
#'   elements \code{enriched,lnEnriched,probEnriched} is the ID, the second
#'   column is the input library value for that ID, and the rest of the columns
#'   are the respective values for each sample (one sample per column.)
#'
#'
#' @importFrom magrittr %>%
vs.calc_enrichment.int <- function(countData,
                               inputCounts= NULL,
                               propExtremesToRemove = 0.05,
                               convertZeroInput_To = NULL,
                               convertZeroCounts_To = NULL,
                               cores = (parallel::detectCores()-1),
                               ...){

  if(!is.null(inputCounts)){
    temp1 <- countData %>% dplyr::filter(input %in% inputCounts)
  } else {
    temp1 <- countData
  }



  colnames1 <- names(temp1)
  nrows <- nrow(temp1)

  nrowsRemove <- round(nrows * propExtremesToRemove, digits = 0)

  rowsTrimmed <- c(nrowsRemove:(nrows-nrowsRemove))

  id_input_DF <- temp1 %>% dplyr::select(id,input) %>% dplyr::arrange(id)



  #X=3
  if(cores == 1) {
    enrichedTempList <-
        lapply(X=(3:length(colnames1)),
               FUN = normalizedEnrichment_tempFXN, #Defined below
               temp1 = temp1,
               colnames1 = colnames1,
               rowsTrimmed = rowsTrimmed,
               convertZeroInput_To = convertZeroInput_To,
               convertZeroCounts_To = convertZeroCounts_To)

  } else {
    enrichedTemp <-
        parallel::mclapply(X=(3:length(colnames1)),
                           FUN = normalizedEnrichment_tempFXN, #FXN at bottom of this script
                           temp1 = temp1,
                           colnames1 = colnames1,
                           rowsTrimmed = rowsTrimmed,
                           convertZeroInput_To = convertZeroInput_To,
                           convertZeroCounts_To = convertZeroCounts_To,
                           mc.cores = cores)
  }

  enrichedTemp <- lnEnrichedTemp <- probEnrichedTemp <-
    data.frame(
      matrix(ncol = (length(colnames1)-2),
             nrow = nrow(enrichedTempList[[1]][["summary_and_fold_enrich"]])))

  #-3 above to remove the portions of summary_and_fold_enrich that are not fold_enrichments

  #don't have the top three rows on the log enriched temp and prob DF
  lnEnrichedTemp <- probEnrichedTemp <- lnEnrichedTemp[-c(1:3),]



  for(X in 1:ncol(enrichedTemp)){
    enrichedTemp[,X] <- enrichedTempList[[X]]$summary_and_fold_enrich

    lnEnrichedTemp[,X] <- enrichedTempList[[X]]$log_FE_Prob$ln_fold_enrich
    probEnrichedTemp[,X] <- enrichedTempList[[X]]$log_FE_Prob$prob
  }


  names(enrichedTemp) = colnames1[-c(1:2)]
  names(lnEnrichedTemp) = colnames1[-c(1:2)]
  names(probEnrichedTemp) = colnames1[-c(1:2)]

  #First row is normalizer
  normalizers1 <-
    data.frame(t(enrichedTemp[1,])) %>%
    dplyr::mutate(rows = rownames(.)) %>%
    dplyr::mutate(inputRangeMin = min(inputCounts, na.rm = TRUE),
                  inputRangeMax = max(inputCounts,na.rm = TRUE))
  names(normalizers1) <- c("normalizer","full_name", "inputRangeMin", "inputRangeMax")

  #second row is average log fold enrichment
  avgLogFoldEnrich <-
    data.frame(t(enrichedTemp[2,])) %>%
    dplyr::mutate(rows = rownames(.))
  names(avgLogFoldEnrich) <- c("avgLnFoldEnrich","full_name")

  #thrid row is standard deviation of the log fold enrichment
  sdLogFoldEnrich <-
    data.frame(t(enrichedTemp[3,])) %>%
    dplyr::mutate(rows = rownames(.))
  names(sdLogFoldEnrich) <- c("sdLnFoldEnrich","full_name")

  normalizers <-
    normalizers1 %>%
    left_join(avgLogFoldEnrich, by = "full_name") %>%
    left_join(sdLogFoldEnrich, by = "full_name")

  enriched <- dplyr::bind_cols(id_input_DF, enrichedTemp[-c(1:3),])

  lnEnriched <- dplyr::bind_cols(id_input_DF, lnEnrichedTemp)
  probEnriched <- dplyr::bind_cols(id_input_DF, probEnrichedTemp)

  return(list(enriched = enriched,
              lnEnriched = lnEnriched,
              probEnriched = probEnriched,
              normalizers = normalizers
              ))
}



#FUNCTION TO CALCULATE FOLD ENRICHMENTS IN THE GROUP AND GET
#LOG FOLD ENRICHMENTS, MEAN LOG FOLD ENRICHMENT, SD LOG FOLD ENRICHMENT
#AND P VALUE or 'PROB' for the FOLD ENRICHMENT
normalizedEnrichment_tempFXN <- function(X,
                                         temp1,
                                         colnames1,
                                         rowsTrimmed,
                                         convertZeroInput_To = NULL,
                                         convertZeroCounts_To = NULL){
  #X=3
  samp1 <-
    temp1 %>%
    dplyr::select(id,input,counts = colnames1[X]) %>%
    dplyr::arrange(counts)

  if(!is.null(convertZeroInput_To)){
    samp1$input[which(samp1$input==0)] <- convertZeroInput_To
  }

  if(!is.null(convertZeroCounts_To)){
    samp1$counts[which(samp1$counts==0)] <- convertZeroCounts_To
  }

  sumCounts1 <-
    apply(samp1[rowsTrimmed,-1],2,sum,na.rm = TRUE)

  #Don't bother trimming if it's going to make it zero.
  if(sumCounts1["counts"]==0 | sumCounts1["input"]==0){
    sumCounts1 <-
      apply(samp1[ ,-1],2,sum,na.rm = TRUE)
  }

  normalizer1 = sumCounts1["counts"]  / sumCounts1["input"]

  #CALCULATE ENRICHMENTS HERE
  samp2 <-
    samp1 %>%
    dplyr::mutate(inputNormalized = input *  normalizer1) %>%
    dplyr::mutate(fold_enrich = counts / inputNormalized) %>%
    dplyr::arrange(id) %>%
    dplyr::select(id, fold_enrich)


  #now get log - but need to do it without throwing errors
  #so make an index of those that would throw an error
  index_is.na = which(is.na(samp2$fold_enrich))
  index_0 = which(samp2$fold_enrich==0)
  index_inf = which(samp2$fold_enrich == "Inf")

  noLogTransform <- c(index_is.na, index_0, index_inf)


  if(length(noLogTransform)==0){
    #if none would throw errors...

    #1) Calculate log fold enrichment
    ln_fold_enrich <- log(samp2$fold_enrich)

    #2) Calculate average and SD of log fold enrichment
    Avg_SD_lnFoldEnrich <-
      data.frame(avgLnEnrich = mean(ln_fold_enrich),
                 sdLnEnrich = stats::sd(ln_fold_enrich))

  } else {
    #if there are zeros in the fold_enrichment

    #1) calculate log fold enrichment of those without errors when log() transform
    ln_fold_enrich <- samp2$fold_enrich
    ln_fold_enrich[-noLogTransform] <- log(samp2$fold_enrich[-noLogTransform])

    #2) Calculate avg and SD of those that would not throw errors
    Avg_SD_lnFoldEnrich <-
      data.frame(avgLnEnrich = mean(ln_fold_enrich[-noLogTransform]),
                 sdLnEnrich = stats::sd(ln_fold_enrich[-noLogTransform]))

    #3) convert those with zero fold_enrichments into four x SD lower than mean
    ln_fold_enrich[noLogTransform] =
      Avg_SD_lnFoldEnrich$avgLnEnrich - 4 * Avg_SD_lnFoldEnrich$sdLnEnrich

  }

  # Make a log_fold_enrichment column in the samp2 to return
  samp2$ln_fold_enrich = ln_fold_enrich

  #check normality
  #plot(density(samp2$ln_fold_enrich))
  #theoretical <-
    #rnorm(n = 10000,
    #   mean = Avg_SD_lnFoldEnrich$avgLnEnrich,
    #    sd = Avg_SD_lnFoldEnrich$sdLnEnrich)
  #lines(density(theoretical))


  #CALCULATE P-VALUE
  # calculate the p-value for that enrichment relative to the
  # maen/SD of the group
  samp2$prob = pnorm(q = samp2$ln_fold_enrich,
                     mean = Avg_SD_lnFoldEnrich$avgLnEnrich,
                     sd = Avg_SD_lnFoldEnrich$sdLnEnrich, lower.tail = FALSE)


  #FIRST THREE ROWs ARE NORMLIZER, Avg Log Enrich, StDev Log Enrich!!!
  summary_and_fold_enrich <- data.frame(
                tempName = c(normalizer1[1],
                Avg_SD_lnFoldEnrich$avgLnEnrich,
                Avg_SD_lnFoldEnrich$sdLnEnrich,
                samp2$fold_enrich))

  names(summary_and_fold_enrich) <- colnames1[X]

  return(list(summary_and_fold_enrich =
                summary_and_fold_enrich,
              log_FE_Prob =
                samp2[,c("ln_fold_enrich",
                         "prob")]))

  #head(summary_and_fold_enrich)
  #head(samp2[,c("ln_fold_enrich",
   #             "prob")])

}
