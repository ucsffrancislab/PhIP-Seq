#------------------------------------------------------------------------------#
#Function to set non hits to Zero
#requires output of vs.splitReplicate
#------------------------------------------------------------------------------#
#' Function to convert the NGS counts, enrichments etc which are not considered
#' significant hits to zero. Or reverse this too.
#'
#' @param countsReplicateSplit A List of length 2 with two data frames, one for
#'   each replicate. Can be made with \code{\link{vs.splitReplicateData}}. The
#'   first and second columns of each DF should be the "id" and "input library
#'   counts" If this is not the case, then enter the correct column numbers
#'   under \code{idColNum and inputLibColNum} or set to 0 or NULL.
#'
#' @param hitsDF A single Data frame of zeros and ones representing hits or not
#'   for each ID. The columns should be in the SAME ORDER as the columns of
#'   \code{countsReplicateSplit}. NOTE: unlike the counts data, the HITS DF
#'   should NOT have an input Library as the second column. If it does, add the
#'   name of the column to hits_nonSampleCols.
#'
#' @param reverse Should the zeros be converted to 1, and vice versa in the
#'   hitsDF. This is useful if trying instead to convert hits to zero, for
#'   example to get background counts for a sample.
#'
#' @param idColNum,inputLibColNum The column number in the counts data frames of
#'   the "ID" column and the Input library column. If the input Library column
#'   is missing, set to zero or NULL. DEFAULT is 1 and 2, respectively.
#'
#' @param hits_nonSampleColNames the names of any non-sample columns (i.e.
#'   c("id","input")). Default is "id"
#'
#' @importFrom magrittr %>%
#'
#'
#' @export
vs.setNonHitCountsToZero <- function(countsReplicateSplit,
                                     hitsDF,
                                     reverse = FALSE, #sets hit counts to zero instead (good for background counts)
                                     idColNum = 1,
                                     inputLibColNum  = 2,
                                     hits_nonSampleColNames = c("id")){

  hits_nonSampleCols <- unique(c("id",hits_nonSampleColNames))

  counts1 <- countsReplicateSplit[[1]]
  counts2 <- countsReplicateSplit[[2]]
  idAndinputLib = counts1[,c(idColNum,inputLibColNum)]

  if(reverse == TRUE){
    hitsDF <- vs.reverseHits(hitsDF, nonSampleCols = hits_nonSampleColNames)
  }

  hitsDF <- hitsDF[,-which(names(hitsDF) %in% nonSampleColNames)]

  namesMatch = identical(names(hitsDF,names(counts1[,-c(idColNum,inputLibColNum)])))

  return(
    list(rep1 =
           cbind(idAndinputLib,
                 (hitsDF %>% dplyr::select(-id)) * counts1[,-c(idColNum,inputLibColNum)]),
         rep2 =
           cbind(idAndinputLib,
                 (hitsDF %>% dplyr::select(-id)) * counts2[,-c(idColNum,inputLibColNum)]))
  )
}


