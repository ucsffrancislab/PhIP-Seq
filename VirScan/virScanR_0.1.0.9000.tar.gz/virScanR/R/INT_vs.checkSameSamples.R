#------------------------------------------------------------------------------#
#Are columns the identical between the two dataframes
#------------------------------------------------------------------------------#
#' Checks that two data frames are identical in rows and columns
#'
#' Requires both to have an "id" column.
#'
#' @param pVals,counts The two data.frames to compare. Could be anything - they
#'   just both need to have an "id" columns

vs.checkSameSamples <- function(pVals,
                                counts){
  pNames <- names(pVals)
  cNames <- names(counts)



  return(data.frame(
    sameColumns = identical(pNames,cNames),
    sameRows = identical(as.double(pVals$id), as.double(counts$id))))
}
