#------------------------------------------------------------------------------#
#getFailedRuns
#------------------------------------------------------------------------------#
#' @importFrom magrittr %>%
#' @export
vs.getFailedRunNames <- function(counts,
                                 minCountsForFailure = 2e5,
                                 replicateNamesDF = NULL,
                                 ...){

  sampCountsSum <- apply(counts,2,sum,na.rm = TRUE)
  failed <-
    names(sampCountsSum)[which(sampCountsSum < minCountsForFailure)]

  failedDF <-
    data.frame(full_name = failed, counts = sampCountsSum[failed])

  if(!is.null(replicateNamesDF)){
    failedRuns <-
      replicateNamesDF %>%
      dplyr::mutate(failed = ifelse(rep1 %in% failed | rep2 %in% failed, 1,0)) %>%
      dplyr::filter(failed == 1) %>%
      dplyr::select(-failed) %>%
      tidyr::gather(key = failed,
                    value = full_name,
                    -identifier)

    failedRuns <-
      failedRuns %>%
      dplyr::mutate(counts = sampCountsSum[failedRuns$full_name]) %>%
      dplyr::arrange(identifier) %>%
      dplyr::mutate(repFailed = ifelse(counts<minCountsForFailure,1,0)) %>%
      dplyr::filter(!is.na(repFailed))

    return(failedRuns)
  } else {
    return(failedDF)
  }
}
