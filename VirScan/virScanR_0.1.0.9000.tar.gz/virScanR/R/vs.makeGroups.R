#------------------------------------------------------------------------------#
#vs.makeGroups
#------------------------------------------------------------------------------#
#' Groups data on a single column allowing the size of the groups to be set, or
#' whether to group all with a particular
#'
#' @param dataToGroup The data frame (or if a list, the data in the first
#'   element of a list) to create groups by.
#'
#' @param idCol The \code{id} (or equivalent) column that declares what the row
#'   means. Note, this is not the column to use for grouping. For that, set
#'   \code{groupingCol}.
#'
#' @param groupingCol The column name that should be used for grouping. For
#'   example, this might be \code{"input"} (DEFAULT) or \code{"myLib_counts"},
#'   etc... Must be input as a string.
#'
#' @param returnData Should all of the data be returned (DEFAULT is TRUE), or
#'   (FALSE) just the \code{idCol} and the \code{"group"} column.
#'
#' @param returnAs Should it be returned as "data.table","data.frame",or one of
#'   "tibble","tbl_df","tbl","data_frame".
#'
#' @param returnAsList Should the returned values be split into lists, based on
#'   their group (TRUE),, or kept as a single data frame (FALSE - DEFAULT).
#'
#' @param groupSize How many ID's should be grouped together to make up a chunk
#'   (Should be sufficient to create a null distribution).  If want the same
#'   result as vs.calc_enrichment.int, set groupSize to the number of distinct
#'   IDs (i.e. number of rows of the countData).  This will be input into the
#'   \code{\link{vs.makeGroups}} function. Alternatively can forego groupSize
#'   and provide the output if already created under groupedIDs.
#'
#' @param staggerChunk Should the chunks be staggered. This will help to reduce
#'   bias that might occur within a given chunk. For example, if the input
#'   counts in a given chunk range from 10 to 50, and the fold enrichment is
#'   based on the counts / mean_chunk_counts, then those with an input of 50
#'   might be biased upwards towards a higher fold_enrichment compared to the
#'   mean of the group, and those with input counts of only 10 (bottom of the
#'   group), might be biased downards, towards a lower fold-enrichment.
#'   Staggering will help reduce this bias by creating two sets of groupedIDs,
#'   overlapping 50%.  So, if a chunk goes from 10:50 it's "parallel" chunk
#'   might go from 30:70 and therefore those IDs that were in the upper half of
#'   the first run would find themselves in the lower half of the parallel run.
#'   If this is used, two sets of all of the data will be output, and it is up
#'   to the user to decide how to deal with discrepencies - though some
#'   functions have been developed to help, like \code{\link{vs.combineData}} or
#'   \code{\link{vs.combineHits}}
#'
#' @param splitHighVarMeanGrps Should groups with a very high variance to mean
#'   ratio be split to make groups with lower variance (usually only fring
#'   groups at upper end would require this. Default is TRUE)
#'
#' @param groupTogetherIfGreaterThanGroupSize If there are greater than
#'   \code{groupSize} ids with a specific input count, should these be grouped
#'   together, rather than grouping together an arbitrary set of samples of
#'   \code{groupSize}. For example, if groupSize is set to 300 and there are 600
#'   ids with an input count of 1, then should all of these combine to make a
#'   single group, or should the 600 ids contribute arbitrarily to two different
#'   groups. If so, then all of the ids for which there are n > groupSize will
#'   make their own groups, and those ids left over will each make up groups of
#'   approximately ~groupSize numbers of ids.
#' @export
vs.makeGroups <- function(dataToGroup,
                          groupSize = 200,
                          groupTogetherIfGreaterThanGroupSize = TRUE,
                          idCol = "id",
                          groupingCol = "input",
                          staggerChunk = FALSE,
                          splitHighVarMeanGrps = TRUE,
                          returnData = TRUE,
                          returnAs = "data.table",
                          returnAsList = FALSE){


  if(staggerChunk == TRUE & groupTogetherIfGreaterThanGroupSize == TRUE){
    stop("Cannot Stagger Chunk and set groupTogetherIfGreaterThanGroupSize to TRUE. Set the latter to FALSE or do not Stagger")
  }


  if("list" %in% class(dataToGroup)){
    dataToGroup = data.table::copy(data.table::setDF(dataToGroup[[1]]))
  } else {
    dataToGroup = data.table::copy(data.table::setDF(dataToGroup))
  }

  idIndex <- which(names(dataToGroup) == idCol)
  groupIndex <- which(names(dataToGroup) == groupingCol)

  groupedIDs1 <- dataToGroup[,c(idIndex,groupIndex)]
  names(groupedIDs1) <- c("id","input")


  if(groupTogetherIfGreaterThanGroupSize){

    inputGroups <-
      groupedIDs1 %>%
      dplyr::group_by(input) %>%
      dplyr::mutate(count = 1, count = sum(count)) %>%
      dplyr::select(input,count) %>%
      unique() %>%
      dplyr::arrange(input) %>%
      dplyr::ungroup()

    #----------------------------------------------------------------------
    inputGroups2 <-
      inputGroups %>%
      dplyr::mutate(group1 = 1) %>%
      dplyr::mutate(group1 = cumsum(group1)) %>%
      dplyr::mutate(groupLead = lead(group1)) %>%
      dplyr::mutate(gtGrpSz = ifelse(count >= groupSize,1,0)) %>%
      data.frame() %>%
      dplyr::mutate(
        lead1 = lead(gtGrpSz)) %>%
      dplyr::mutate(
        group2 = ifelse(gtGrpSz==1,group1,
                        ifelse(count > groupSize *.70,group1,
                               ifelse(lead1 ==1,groupLead,NA)))) %>%
      dplyr::mutate(notGrouped = ifelse(is.na(group2),1,0)) %>%
      dplyr::mutate(notGroupedCum = cumsum(notGrouped))
    #----------------------------------------------------------------------

    inputGroups_gt_grpSz <-
      inputGroups2 %>%
      dplyr::filter(notGroupedCum ==0) %>%
      dplyr::select(input, count, group2) %>%
      left_join(groupedIDs1, by = "input") %>%
      select(id,input,group = group2)


    groupedIDs_lt_grpSz1 <-
      groupedIDs1 %>%
      dplyr::filter(!input %in% inputGroups_gt_grpSz$input) %>%
      dplyr::arrange(input)


    groupedIDs_lt_grpSz <-
      groupedIDs_lt_grpSz1 %>%
      #dplyr::select(id = idCol, input = groupingCol) %>%
      dplyr::arrange(input) %>%
      dplyr::mutate(group =
                      sort(
                        rep(c(1:round(nrow(groupedIDs_lt_grpSz1)/groupSize,digits = 0)),
                            length = nrow(groupedIDs_lt_grpSz1))))


    if(length(inputGroups_gt_grpSz$group)>0){
      groupedIDs_lt_grpSz$group = groupedIDs_lt_grpSz$group + max(inputGroups_gt_grpSz$group)
    }



    groupedIDs <-
      dplyr::bind_rows(
        inputGroups_gt_grpSz,
        groupedIDs_lt_grpSz)



  } else {
    groupedIDs <-
      groupedIDs1 %>%
      #dplyr::select(id = idCol, input = groupingCol) %>%
      dplyr::arrange(input) %>%
      dplyr::mutate(group =
                      sort(
                        rep(c(1:round(nrow(groupedIDs1)/groupSize,digits = 0)),
                            length = nrow(groupedIDs1))))
  }

  #if any groups have very high variance in input counts, split in two
  #------------------------------------------------------------------------
  splitHighVarMean <- function(groupedIDs,groupSize,nSplitGroupSize,sdMeanLim){
    temp <-
      groupedIDs %>%
      dplyr::group_by(group) %>%
      dplyr::mutate(count = 1, count = sum(count)) %>%
      dplyr::summarize(min = min(input),
                       max = max(input),
                       mean = mean(input),
                       sd = sd(input),
                       var = var(input)) %>%
      dplyr::mutate(limDiff = max-min) %>%
      dplyr::mutate(sdMean = sd/mean,
                    varMean = var/mean) %>%
      dplyr::filter(sdMean > sdMeanLim,
                    limDiff > 3)


    groupedIDsToSplit <-
      groupedIDs %>%
      dplyr::filter(group %in% temp$group)

    if(nrow(groupedIDsToSplit)>0){
      groupedIDsLast <-
        groupedIDsToSplit %>%
        dplyr::arrange(input) %>%
        dplyr::mutate(group =
                        sort(
                          rep(c(1:round(nrow(groupedIDsToSplit)/round(groupSize/nSplitGroupSize,digits=0),digits = 0)),
                              length = nrow(groupedIDsToSplit)))) %>%
        dplyr::mutate(group = group + min(groupedIDsToSplit$group)-1)

      groupedIDs2 <-
        groupedIDs %>%
        dplyr::filter(!id %in% groupedIDsLast$id) %>%
        dplyr::bind_rows(groupedIDsLast)

      return(groupedIDs2)
    } else {
      return(groupedIDs)
    }


  }
  #------------------------------------------------------------------------

  if(staggerChunk == FALSE & splitHighVarMeanGrps == TRUE){
    groupedIDs <- splitHighVarMean(groupedIDs,groupSize,nSplitGroupSize = 2, sdMeanLim = .08)
    groupedIDs <- splitHighVarMean(groupedIDs,groupSize,nSplitGroupSize = 4, sdMeanLim = .08)
    groupedIDs <- splitHighVarMean(groupedIDs,groupSize,nSplitGroupSize = 8, sdMeanLim = .08)
  }

  groupedIDs <- groupedIDs %>% select(id,group)


  integerGroups <-
    data.frame(group = sort(unique(groupedIDs$group))) %>%
    mutate(group1 = 1, group1 = cumsum(group1 ))

  groupedIDs <-
    groupedIDs %>%
    left_join(integerGroups, by = "group") %>%
    select(-group)
  names(groupedIDs) <- c(idCol,"group")


  if(staggerChunk == TRUE & groupTogetherIfGreaterThanGroupSize == FALSE){
    groupedIDs2 <- groupedIDs
    halfGroup = round(groupSize/2, digits = 0)
    groupedIDs2$group <-
      c(rep(0,halfGroup), groupedIDs$group[1:(length(groupedIDs$group)-halfGroup)])
    groupedIDs <- groupedIDs2
  }

  if(returnData == TRUE){
    #join
    groupedIDs <- data.table::setDT(groupedIDs)[dataToGroup,on = idCol]
  }
  if(returnAs == "data.frame"){
    groupedIDs <- data.table::setDF(groupedIDs)
  }
  if(returnAs %in% c("tibble","tbl_df","tbl","data_frame")) {
    groupedIDs <- dplyr::as_tibble(groupedIDs)
  }
  if(returnAsList == TRUE){
    groupedIDs <-
      mmR::mm.split_to_list(data.table::setDF(groupedIDs), by = "group")
  }
  return(groupedIDs )
}
