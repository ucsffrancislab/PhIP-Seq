#' Function to find combined input library runs that have desired individual input libraries
#' 
#' Function to find combined input library runs that have desired individual input libraries
#' 
#' @param input_ids the input ids that are of interest and to search for among the combined input libraries.
#' @param keys the keys list from vs.getKeysList()
#' 
#' @export 
vs.find_inputs_among_combined_inputs <- function(input_ids,keys){
  
  sampDF_input_id <- unique(input_ids)
  
  input_ids_for_beads <-
    c(sampDF_input_id,
      c(keys$combined_input_libsKey %>%
          filter(component_input_id == sampDF_input_id))$input_id)
  
  input_ids_for_beads1 <-
    (keys$combined_input_libsKey %>%
      filter(input_id == sampDF_input_id))$component_input_id
  
  input_ids_for_beads <-
    c(unique(c(input_ids_for_beads,
             input_ids_for_beads[which(!input_ids_for_beads %in% keys$combined_input_libsKey$input_id)])),
      input_ids_for_beads1)
  
  return(input_ids_for_beads)
}
