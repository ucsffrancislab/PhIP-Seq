#------------------------------------------------------------------------------#
#------------------------------------------------------------------------------#
#' Simple function to view key info of project details listed in the "virScanKey" file of sample meta data.
#'
#' To work, virScanKey must contain the following columns: PI, studyName,
#' libAmpDate, protocol, projectName, labLead
#'
#' @param path,keys,virScanKey Either the path to the SampleMetaData containing
#'   a worksheet called 'virScanKey' or a list of keys created using
#'   vs.getKeysList(), with one list element called virScanKey, or can give
#'   virScanKey directly. Only one should be declared.
#'
#' @param extraCols additional columns that you'd like to be included in the
#'   details
#'
#'
#' @importFrom magrittr %>%
#'
#' @export
vs.viewProjectDetails <- function(path = NULL,
                                  keys = NULL,
                                  virScanKey = NULL,
                                  extraCols = NULL,
                                  allCols = FALSE,
                                  ...){
  if(!is.null(path)){
    virScanKey = vs.getKeysList(path)$virScanKey
  }

  if(!is.null(keys)){
    virScanKey = keys$virScanKey
  }


  if(allCols == TRUE){
    extraCols = c(extraCols,"plate_name",
                  "input_name","amp_or_combined_date",
                  "dilution_other_change","protocol","assay_date")
  }

  if(!is.null(extraCols)){
    extraCols <- unique(extraCols[which(extraCols %in% colnames(virScanKey))])
  }



  if(!is.null(extraCols)){
    return(
      virScanKey %>%
        dplyr::select(pi,
                      study_name,
                      project_name,
                      project_name2,
                      unique_methods_long_id,
                      input_full_description,
                      input_id,
                      lab_lead,protocol,extraCols) %>%
        dplyr::group_by_("pi",
                        "study_name",
                        "project_name",
                        "project_name2",
                        "unique_methods_long_id",
                        "input_full_description",
                        "input_id",
                        "lab_lead","protocol",extraCols) %>%
        dplyr::mutate(count = 1) %>%
        dplyr::mutate(count = sum(count)) %>%
        unique() %>%
        #dplyr::ungroup() %>%
        #dplyr::group_by_(extraCols) %>%
        #dplyr::mutate(count = sum(count)) %>%

        dplyr::arrange(pi) %>%
        data.frame())
  } else {
  return(
    virScanKey %>%
      dplyr::select(pi,
                    study_name,
                    project_name,
                    project_name2,
                    unique_methods_long_id,
                    input_full_description,
                    input_id,
                    lab_lead,protocol) %>%
      dplyr::group_by(pi,
                      study_name,
                      project_name,
                      project_name2,
                      unique_methods_long_id,
                      input_full_description,
                      input_id,
                      lab_lead,protocol) %>%
      dplyr::mutate(count = 1) %>%
      dplyr::mutate(count = sum(count)) %>%
      unique() %>%
      dplyr::arrange(pi) %>%
      data.frame())
  }
}
