#------------------------------------------------------------------------------#
#makeRep12DF
#makes a dataframe with both replicates NGS column names next to the sampleID
#------------------------------------------------------------------------------#

#' Convenience function to pull the replicates from a sampsDF data frame.
#'
#'
#' Essentially uses the full_name and replicate_full_name columns of the virScan
#' sample metadata. However, it can also utilize a custom sampleIdentifier and,
#' if different a sampleIdentifier2, in conjunction with a column that states
#' what replicate number the sample is (usually 1 or 2, but if a sample is run
#' multiple times, could be greater... like beads Only often are).
#'
#' In general, best to not bother with sampleIdentifier and just pass it data
#' sets that have a full_name and replicate_full_name columns.
#'
#' The output is used in multiple functions.
#'
#' @param sampsDF The data frame containing the samples. Ideally should have at
#'   least two columns, one called \code{full_name} and one called
#'   \code{replicate_full_name}.
#'
#' @param useReplicateFullName Default is TRUE. Does sampsDF contain a column
#'   called \code{replicate_full_name} which contains the virScan 'full_name' for
#'   the replicates of those listed in sampsDF as \code{full_name}
#'
#' @param sampleIdentifier,sampleIdentifier2 If not using useReplicateFullName,
#'   then provide some other sample identifiers for the initial, and, if
#'   different, the replicates to match on. Such as "unique_sample_id". This
#'   also requires that there be a column for each sample called "replicate"
#'   that says if the particular virScan sample that was run was replicate 1,2,3
#'   etc....
#'
#' @return Returns a data frame with rep1 and rep2 columns, as well as a sample
#'   identifier column if that was used... saying what the identifying features
#'   were that were used to pair replicates.
#'
#' @importFrom magrittr %>%
#' @export
vs.gatherReplicateNames <- function(sampsDF = NULL,
                                    useReplicateFullName = TRUE,
                                    sampleIdentifier = "unique_sample_id",
                                    sampleIdentifier2 = NULL,
                                    ...){

  #sampsDF <- samps #Samples taken from the sample Key
  #sampleIdentifier = "labSampleName" #unique Lab identifier for the sample
  #sampleIdentifier2 = "plateName" #if same unique identifier, can add something else to help....
  #or make a completely new column that is unique, etc....

  testWhich <- names(sampsDF)
  if("full_name" %in% testWhich & "replicate_full_name" %in% testWhich){
  } else if("rep1" %in% testWhich & "rep2" %in% testWhich){
    colnames(sampsDF)[which(colnames(sampsDF)=="rep1")] <- "full_name"
    colnames(sampsDF)[which(colnames(sampsDF)=="rep2")] <- "replicate_full_name"
  }

  sampsDF$full_name <- as.character(sampsDF$full_name)
  sampsDF$replicate_full_name <- as.character(sampsDF$replicate_full_name)


    if(useReplicateFullName == TRUE){
      toReturn <-
        sampsDF %>%
        #dplyr::filter(Replicate ==1) %>%
        dplyr::select(rep1 = full_name,
                      rep2 = replicate_full_name) %>%
        dplyr::mutate(identifier = NA,
                      sampleIdentifier = NA)
    } else {

      if(!is.null(sampleIdentifier2)){
        identifier <-
          (sampsDF %>%
             dplyr::select(identifier1 = sampleIdentifier,
                           identifier2 = sampleIdentifier2) %>%
             dplyr::mutate(newIdentifier =
                             paste0(identifier1, "_", identifier2)))$newIdentifier
      } else {
        identifier <-
          (sampsDF %>%
             dplyr::select(newIdentifier = sampleIdentifier))$newIdentifier
      }


      sampsDF <- cbind(sampsDF, identifier = identifier) %>% data.frame()


      toReturn <- sampsDF %>%
        dplyr::filter(Replicate ==1) %>%
        dplyr::select(identifier, rep1 = full_name) %>%
        dplyr::left_join(sampsDF %>%
                           dplyr::filter(Replicate ==2) %>%
                           dplyr::select(identifier, rep2 = full_name),
                         by = "identifier") %>%
        dplyr::mutate(sampleIdentifier = sampleIdentifier)




      if(!is.null(sampleIdentifier2)){
        toReturn <-
          toReturn %>%
          dplyr::mutate(sampleIdentifier2 = sampleIdentifier2)
      }
    }

    #Remove duplicate pairs
    #Collapse so no two rows are just the reverse repeat of each other
    toReturn <-
      toReturn %>%
      dplyr::mutate(toCheck = paste(rep1,rep2)) %>%
      dplyr::mutate(toKeep = 1)


    for(i in 2:nrow(toReturn)){
      toCheck1 <- paste(toReturn[i,"rep2"],toReturn[i,"rep1"])
      toReturn$toKeep[i] = ifelse(toCheck1 %in% toReturn$toCheck[1:i-1], 0, 1)
    }

    toReturn <-
      toReturn %>%
      dplyr::filter(toKeep ==1) %>%
      dplyr::select(-toCheck, -toKeep) %>%
      dplyr::mutate(rep1 = as.character(rep1),
             rep2 = as.character(rep2))






  countRep12Fxn <- function(toReturn){
    return(
      toReturn %>%
     dplyr::group_by(rep1) %>%
     dplyr::mutate(ones = 1) %>%
     dplyr::mutate(rep1_count = cumsum(ones)) %>%
     dplyr::ungroup() %>%
     dplyr::group_by(rep2) %>%
       dplyr::mutate(rep2_count = cumsum(ones)) %>%
       dplyr::select(-ones) %>%
     dplyr::ungroup() %>%
       dplyr::arrange()
      )
  }

  toReturn2 <- countRep12Fxn(toReturn)
  indexToSwitch <- which(toReturn2$rep1_count >1)
  if(length(indexToSwitch) > 0){
    rep1Temp <- toReturn2$rep1
    rep2Temp <- toReturn2$rep2
    rep1Temp[indexToSwitch] <- toReturn2$rep2[indexToSwitch]
    rep2Temp[indexToSwitch] <- toReturn2$rep1[indexToSwitch]

    toReturn2$rep1 <- rep1Temp
    toReturn2$rep2 <- rep2Temp

  }
  toReturn3 <- countRep12Fxn(toReturn2)

  #Check to make sure that if there are duplicates (i.e. )

  return(toReturn3)
}


