#' Function to calculate rowWise Fxns. like rowSums and rowMeans, but also very
#' flexible and fast.
#'
#' This function works similar to 'apply' except it runs in parallel i.e. rows
#' are split across n \code{cores} . It can take any standard R function that
#' accepts a vector and returns a single variable, and it can add the results as
#' an extra column to the supplied data, or can return just a vector.
#' Additionally, it can take custom functions that accept a vector and can also
#' accept extra parameters, that must be passed to the extra function with a
#' list object called \extraParams(). See example for more details, but
#' essentially, to make a function that sums up a row and multiplies it by a
#' value, you could do:  it just be something like: \code{myFUN = function(X,
#' extraParams) {sum(X) * extraParams$e1)}} and then to use it you would do
#' \code{myExtras = list(e1 = 2); vs.rowFXN(data, FUN = myFUN, extraParams =
#' myExtras)}. Finally, it can also return results with greater than one value
#' per row, but the returnAsVector must be true, and the rows will be returns as
#' a vector of lists, one list for each row.
#'
#' @param data Data to calculate row summaries on.
#' @param rowFun a function that takes as input a vector and outputs a single
#'   value. (like mean, sd, var, etc)
#' @param name A name to give to the column that is added, (if returnAsVector is
#'   set to FALSE).
#' @param overwrite_name If the name already exists in the evauated columns,
#'   should it be overwritten. If FALSE (DEFAULT), and the name already exists,
#'   then the name will be changed to \code{myColName.XX}.
#' @param cores The number of cores to use. If not wanting to run in parallel,
#'   set to 1 and it will use apply. Default is parallel::detectCores()
#' @param na.rm Should NA's be removed from the specified functions when they
#'   run. Default is TRUE.
#' @param extraParams a list with extra parameters passed through it. See
#'   description of this function for details
#' @param returnAsVector Should the rowWise summaries be returned as a vector,
#'   or appended as a column to the data set. Default is TRUE to match
#' @param cols_to_evaluate,cols_to_not_evaluate Columns that should (\code{cols_to_evalute}) or should
#'   not (\code{cols_to_not_evaluatebe}) be evaluated. If a column is in both \code{cols_to_evaluate} and
#'   \code{cols_to_not_evaluate}, then it will not be evaluated. Can be column names or
#'   integer places for the columns.
#' @param returnNotEvaluated If returnAsVector is FALSE, Should the columns returned
#'   also include the columns that were not evaluated, or just the columsn that
#'   were evaluated to get the rowMeans or rowSums? Default is TRUE, if returnAsVector is FALSE.
#' @param makeShallowCopy Default is TRUE Should a shallow copy of the data be made. This shouldn't matter too much since the function ideally cleans up the data before returning it, but for safekeeping, this chould be set to TRUE.
#' @param returnName DEFAULT IS FALSE. If TRUE, the returned object will be a list, with the first element the data and summary column and the second element the name that is attributed to that column - in case overwrite_name is set to FALSE, it might be useful to know what the name of the column ended up being (i.e. myCol vs. myCol.1, vs myCol.2, etc...). For example this is useful when this function is passed inside another function.

#' @return Returns either a vector of row Summaries (if returnAsVector = TRUE),
#'   or the data set plus the rowWise summaries column added on. IF returnName is set to TRUE, then the returned object is a list with the first element named 'data' and is the data with the summary column and the second element is the name that is added.
#' @export
#' @examples
#' \dontrun{
#' 
#'
#' dt <- data.table::data.table(x = 1:10,y=1:10,z = 1:10)
#'
#' ## Any function that takes a vector and outputs a single value can be used.
#' vs.rowFXN(data = dt, FUN = sum, na.rm = TRUE, returnAsVector = FALSE)
#'
#' ##or can create custom row wise functions.
#' ##make a custom function that takes a vector X and can also accept extra
#' ##parameters provided they are passed to it through a list object called \code{extraParams}.
#'
#' sumMultiplier <- function(X,extraParams){
#' multiplier = extraParams$multiplier
#' return(sum(X, na.rm = TRUE) * multiplier
#' }
#'
#' extraParams <- list(multiplier = 2)
#' vs.rowFXN(data = dt, FUN = sumFun, na.rm = TRUE, extraParams = extraParams,returnAsVector = FALSE)
#'
#' Can also output lists too! But the caveat is you have to set returnAsVector to FALSE
#'
#' newFunListReturn <- function(X,na.rm = na.rm,extraParams){
#'     multiplier = extraParams$multiplier
#'     return(list(sum1 = sum(X)/10,
#'             sum2 = sum(X,na.rm = na.rm) * multiplier))
#' }
#'
#' extraParams <- list(multiplier = 2)
#' vs.rowFXN(data = dt, FUN = sumFun, na.rm = TRUE, extraParams = extraParams,returnAsVector = TRUE, cores = 8)
#' }

vs.rowFXN <- function(data,
                      rowFun = NULL,
                      name = "rowSummary",
                      overwrite_name = FALSE,
                      cores = parallel::detectCores(),
                      na.rm = TRUE,
                      extraParams = NULL,
                      returnAsVector = TRUE,
                      cols_to_not_evaluate = NULL,
                      cols_to_evaluate = NULL,
                      returnNotEvaluated = TRUE,
                      makeShallowCopy = TRUE,
                      returnName = FALSE,
                      ...){



  whatClassAll <- class(data)
  whatClass <- whatClassAll[1]

  if(whatClass != "data.table"){
    data = data.table::setDT(data)
  }

  if(makeShallowCopy) data <- data.table::copy(data)

  #Since using the number of cores to define the number of groups...
  # don't want to define more groups than are needed.
  if(cores>1 & nrow(data)<cores) {cores = nrow(data)}

  originalColOrder <- data.table::copy(names(data))

  #check to see if the desired name is already in the dataset.
  #if so, update the supplied name by .1 until an unused name is found.
  if(overwrite_name != TRUE & returnAsVector != TRUE){
    baseName = name
    tick = 0
    while(name %in% originalColOrder){
      tick = tick+1
      name = paste0(baseName,".",tick)
    }
    if(name != baseName){
      warning(sprintf("Designated column name %s already used. Summary name set to %s",baseName,name))
    }
  }



  noEvalVec <- vector()
  if(!is.null(cols_to_not_evaluate)){
    if(is.numeric(cols_to_not_evaluate)){
      cols_to_not_evaluate <- originalColOrder[cols_to_not_evaluate]
    }
    noEvalVec <- cols_to_not_evaluate
  }


  if(!is.null(cols_to_evaluate)){
    if(is.numeric(cols_to_evaluate)){
      cols_to_evaluate <- originalColOrder[cols_to_evaluate]
    }
    noEvalVec <- unique(c(noEvalVec,
                          originalColOrder[which(!originalColOrder %in% cols_to_evaluate)]))
  }

  if(length(noEvalVec)>0){
    colEval <- originalColOrder[which(!originalColOrder %in% noEvalVec)]
  } else {
    colEval <- originalColOrder
  }

  if(length(colEval)==0){
    stop("No columns to evaluate. This could be due to the combination of cols_to_evaluate and cols_to_not_evaluate leading to 0 columns being evaluated.")
  }


  #Set function for inside mclapply or apply
  argNames <- names(as.list(args(rowFun)))
  if("na.rm" %in% argNames){
    if("..." %in% argNames | "extraParams" %in% argNames){
      myFun <- function(x,na.rm = na.rm,extraParams = extraParams,...){
        return(rowFun(x,na.rm = na.rm, extraParams = extraParams))
      }
    } else {
      myFun <- function(x,na.rm = na.rm,extraParams = extraParams,...){
        return(rowFun(x,na.rm = na.rm))
      }
    }
  } else if("..." %in% argNames | "extraParams" %in% argNames){
    myFun <- function(x,na.rm = na.rm,extraParams = extraParams,...){
      return(rowFun(x,extraParams = extraParams))
    }
  } else {
    myFun <- function(x,na.rm = na.rm,extraParams = extraParams,...){
      return(rowFun(x))
    }
  }


  if(cores>1 &
     (requireNamespace(package = "parallel")==TRUE)){

    #NOTE:
    #NEED TO CONSIDER IF THE DT already has index and group as columns.

    data[ ,
          index_Rand_1938dcjweksxi2 := c(1:nrow(data))
          ][ ,
             group_Rand_ksdickmweox838r := rep(c(1:cores),
                          length = nrow(data))
             ]

    toReturn <-
      data.table::setorder(
        data.table::rbindlist(
          parallel::mclapply(
            X =
              mmR::mm.split_to_list(data, by = "group_Rand_ksdickmweox838r"),
            FUN = function(X) {
              return(
                X[,
                  c(name) := apply(.SD,
                                   MARGIN =1,
                                   FUN = myFun,
                                   na.rm = na.rm,
                                   extraParams = extraParams),
                  .SDcols = colEval ]
                )
              },
            mc.cores = cores
            )
          ),index_Rand_1938dcjweksxi2)[,
                                       c("index_Rand_1938dcjweksxi2",
                                         "group_Rand_ksdickmweox838r") := NULL]

    data[,
           c("index_Rand_1938dcjweksxi2",
             "group_Rand_ksdickmweox838r") := NULL]

    if(returnAsVector == TRUE){
      toReturn <- toReturn[,get(name)]
    } else {}

  } else { #if cores == 1
    toReturn <-
      data[,c(name) := apply(.SD,
                             1,
                             FUN = myFun,
                             na.rm = na.rm,
                             extraParams = extraParams),
           .SDcols = colEval]

    if(returnNotEvaluated == FALSE){
      toRemove <- names(toReturn)[!names(toReturn) %in% c(colEval,name)]
      toReturn[,c(toRemove) := NULL]
    }


    if(returnAsVector == TRUE){
      toReturn <- toReturn[,get(name)]
    } else {}

  }



  if(returnAsVector == TRUE){
    return(toReturn)
  } else {
    if(whatClass == "data.table"){
      if(returnName == TRUE){
        return(list(data = toReturn, name = name))
      } else {
        return(toReturn)
      }
    } else {
      data.table::setDF(toReturn)
      data.table::setattr(toReturn, "class", whatClassAll)
      if(returnName == TRUE){
        return(list(data = toReturn, name = name))
      } else {
        return(toReturn)
      }
    }
  }
}








