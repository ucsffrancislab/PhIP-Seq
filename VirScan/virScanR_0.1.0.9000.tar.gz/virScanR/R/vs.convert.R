#' Parameter Entry for vs.convert().
#'
#' Parameter Entry for vs.convert(). \code{vs.convert} is a function to Convert
#' a data.table or data.frame or a list of data.tables/frames based on a new
#' statistic in a colum-wise fashion. That is, distributions are assumed to be
#' comprised within columns, not rows, and each column is a distinct sample. If
#' a list is provided (or created by setting \code{makeGroups} to TRUE *OR* by
#' using \code{split_to_list_by = "myCol_with_Group_Identifiers"}) then all of
#' the distributions be relative to just the values within that group/list
#' element.  It is usually a good idea to input a data frame and if it needs to
#' be evaluated in chunks, then set \code{makeGroups = TRUE} and fill in
#' \code{makeGroupSize, idCol,makeGroup_by_col, staggerChunk,
#' groupTogetherIfGreaterThanGroupSize}. If this has already been done, and you
#' are, for instance chaining two rounds together, then you can use
#' \code{split_to_list_by = "group"} where the column "group" was produced in
#' the first call to \code{vs.makeGroups} when \code{makeGroups} was set to
#' \code{TRUE}.
#'
#' @param stat The statistic to calculate or transformation to perform to each
#'   column. Transformations and statistics available include:
#'   \code{"log_transform","log1p_transform","sqrt_transform","exp_transform",
#'   "ihs_transform","Z_score","Z_score_rowWise","fold_enrich",
#'   "NLP_norm","NLP_pois","NLP_nBinom","NLP_zinBinom" or "nlp_to_p_transform"}
#'   or \code{"custom"}.
#'
#'   For statistics or transforms that rely on a summary statistic (such as
#'   \code{"fold_enrich"}, which relies on the mean, the data can be trimmed to
#'   remove outliers first - see \code{propExtremesToRemove} or
#'   \code{numExtremesToRemove} and \code{removeTail} for information.#'
#'   \code{"log_transform", "log1p_transform", "ihs_transform","sqrt_transform"}
#'   will calculate the respective transformations.
#'
#'   If performing \code{"Z_score_rowWise} or a \code{"log_transform"} or
#'   \code{ihs_transform}, see \code{extraParam, extraParam2} arguments as these
#'   require the use of \code{extraParams}. \code{"Z_score_rowWise} requires
#'   extraParam and extraParam2 to be set - and these should be extraParam =
#'   vectorOfMeans of the beads_only samples (each entry the mean of the beads
#'   only for that peptide) and extraParam2 should be extraParam2 =
#'   vectorOf_std.devs. These two can be retrieved easily using
#'   \code{\link{vs.rowFXN}} or \code{\link{vs.rowFXN_NoOutlier}}.
#'   \code{ihs_transform} performs the inverse hyperbolic sine transformation -
#'   which tends to be a bit better than a log-transform when many zeros exist -
#'   as it can deal with zeros well. It requires a theta parameter which is
#'   similar to the base in a log transformation - it shouldn't change the
#'   distributional shape, but will effect the values themselves. Pass theta in
#'   as a single entry to \code{extraParam}. \code{log_transform} has (1) an
#'   option to either set zeros to a specific number (after the log_transform)
#'   (set this with \code{extraParam}, or use a mean - standard deviation
#'   approach to set zeros to a value that is some multiple \code{extraParam2}
#'   of the standard deviation below the mean.
#'
#'   The NLP_norm, NLP_pois and NLP_nBinom and NLP_zinBinom calculate the
#'   negative log P-value from the respective distributions, that is: normal,
#'   poisson, negative binomial or zero inflated negative binomial. Careful with
#'   zinbin - it is finicky and often fails to converge. Negative binomial is
#'   usually sufficient. The \code{"Z_score"} option calculates the Z score
#'   (i.e. \code{(data - mean)/sd)}.
#'
#'   \code{"custom"} requires that a custom_colFun be input into
#'   \code{custom_colFun}. See \code{custom_colFun} parameter details for
#'   information.
#'
#' @param idCol A column that can be considered unique to each row - required to
#'   provide the output back in the same order that it comes in.
#'
#' @param makeGroups Should the \code{vs.makeGroups} function be called on the
#'   data to create the groups and then push to the rest of the function as a
#'   list object to be evaluated on a per group basis. NOTE: IF a list is
#'   provided as the data, then neither \code{makeGroups} nor
#'   \code{eval_by_group_col} will be honored. The input list will supercede any
#'   other attempts at grouping. If the groups have already been created, either
#'   through an outside call to \code{vs.makeGroups} and the data is already in
#'   a list per those groups - then nothing else needs to be included. If the
#'   group column already exists but the data is not in a list yet, then set
#'   eval_by_group_col to the grouping column name - often just "group" if
#'   created through a previous call to this function with makeGroups = TRUE or
#'   an outside call to vs.makeGroups().
#'
#' @param eval_by_group_col Use when a grouping column is already created
#'   appropraitely (i.e. "group" column produced from
#'   \code{\link{vs.makeGroups())}}. This exists to be able to chain
#'   transfomrations together. If the first transformation createes the
#'   appropriate groups, then only need to use \code{split_to_list_by =
#'   "group"}, for example to create the appropriate list for evaluatin gthe
#'   data. NOTE: IF a list is provided as the data, then neither
#'   \code{makeGroups} nor \code{eval_by_group_col} will be honored. The input
#'   list will supercede any other attempts at grouping.
#'
#' @param cols_to_evaluate,cols_to_not_evaluate,cols_to_remove Vectors of
#'   columns to evaluate, columns to not evaluate and columns to remove. All
#'   columns that are passed in the data argument except those in
#'   \code{cols_to_remove} will be returned. If \code{cols_to_evaluate} is not
#'   null, only those columns will be evaluated. If \code{cols_to_not_evaluate},
#'   is not NULL, then any columns listed here will not be evaluated, but will
#'   be returned. This will supersede cols_to_evaluate. If
#'   \code{cols_to_evaluate} is left NULL, then it will evaluate all columns
#'   except for those included in \code{cols_to_not_evaluate and
#'   cols_to_remove}.
#'
#' @param propExtremesToRemove,numExtremesToRemove,removeTail The proportion or
#'   number of elements at the tail extremes to remove. It will order lower to
#'   upper and then remove the fraction or absolute number of rows, either from
#'   the lower end (\code{removeTail = "lower"}), the upper end
#'   (\code{removeTail = "upper"}) or from both ends (\code{removeTail =
#'   "both"}).
#'
#' @param extraParam,extraParam2 Random parameters for various
#'   functions (currently only "log_transform" and "ihs_transform") as follows:
#'
#'   \code{log_transform}: When Transforming to log transformation (i.e. using
#'   \code{stat = "log_transform"}), the zeros are set to some specific value
#'   after the log_transfomration, by setting \code{extraParam} to the desired
#'   value. Alternatively, keep \code{extraParam = NULL} and set
#'   \code{extraParam2} which will set zeros to a specified number of standard
#'   deviations below the mean of the potentially trimmed data.Trimming via
#'   \code{propExtremesToRemove} is performed first, then zeros are held out,
#'   log of remaining values are taken, mean and standard deviation are
#'   calculated, and finally the zeros will be set to \code{mean(log(values)) -
#'   extraParam2 * sd(log(values))}. In this case, extraParam2 sets is the
#'   number of sd's below the mean to change zero's to. if extraParam is set to
#'   NULL or NA, then initial values of zero (before log transform) will be
#'   returned as NA.
#'
#'   If using \code{stat = "ihs_transform"}, the inverse hyperbolic sine
#'   transformation uses theta which is somewhat arbitrary. It is like a base in
#'   a log distribtion. It is set to 2 by default but to change it set
#'   \code{extraParam} when stat is set to "ihs_transfrom".
#'
#' @param custom_colFun,custom_fun_paramsList User can input a custom function
#'   to apply over a column. This function must take X to identify the column
#'   (i.e. in lapply(X = 1:ncol, FUN = custom_colFun,data = data,...)) and the
#'   second argument must be data, which takes in the data - ONLY THE COLUMNS TO
#'   EVALUTE - the other columns will be stored and dealt with outside of the
#'   function. The function can also take as an argument \code{paramsList} which
#'   can be a list of parameters inserted here using \code{custom_fun_paramsList
#'   = list(param1 = ...,param2 =...)}. This will be appended to paramsList,
#'   before element \code{paramsList[["rowsTrimmed"]]}.
#'
#' @param coresAcrossGroups,coresAcrossCols The number of course to use across
#'   the groups, where each group is an element of the data that is provided, or
#'   coresAcrossCols dicates \code{cores} in \code{\link{vs.convert_one_DT}} -
#'   that is the number of cores that should be used to process the statistics
#'   across the columns. Early testing suggests that increases coresAcrossGroups
#'   up to detectCores is perhaps better. If set to 1, will use lapply, if set
#'   to >1 will use parallel::mclapply().
#'
#' @param returnAs type of data frame to return the final data. Choose one of
#'   \code{"data.table" (DEFAULT), "data.frame"} or for the tibble format any
#'   of: \code{"tibble","tbl_df","tbl","data_frame"}
#'
#' @return Returns a list of parameters which can be added as the sole argument
#'   (except for the data itself) to \code{\link{vs.convert}}.
#'
#' @inheritParams vs.makeGroups
#' 
# Import package operators
#' @importFrom magrittr "%>%" "%<>%"
#' @importFrom data.table ":=" "%like%" "%between%"
#' 
# Make sure data.table knows we know we're using it
.datatable.aware = TRUE
#' 
#' @export
#' @examples 
#' \dontrun{
#' customFun_rowWise_Z <- function(X,
#'                                 data,
#'                                 paramsList,...){
#'   
#'   #pass 'beads_meanRows and beads_sdRows into function using
#'   #custom_fun_paramsList = list(beads_meanRows = ..., beads_sdRows = ...)
#'   #and paramsList will take the names.
#'   
#'   colName <- names(data)[X]
#'   temp <- data.table::copy(data[,.(data[[colName]])]) #isolate column
#'   temp[,V1 := (V1 - paramsList$beads_meanRows)/paramsList$beads_sdRows]
#'   names(temp) <- c(colName) #rename column
#'   return(list(temp = temp,params = "rowWise"))
#'  }
#' }
#' 
vs.set_params_convert <- function(stat = c("log_transform","log1p_transform","Z_score","Z_score_rowWise", "log_transform","fold_enrich","NLP_norm","NLP_pois","NLP_nBinom","NLP_zinBinom"),
                       makeGroups = TRUE,
                       makeGroupSize = 300,
                       idCol = "id",
                       makeGroup_by_col = "input",
                       staggerChunk = FALSE,
                       groupTogetherIfGreaterThanGroupSize = TRUE,
                       splitHighVarMeanGrps = TRUE,

                       eval_by_group_col = "group",

                       cols_to_evaluate = NULL,
                       cols_to_not_evaluate =   c("id","group","input"),
                       cols_to_remove = NULL,



                       propExtremesToRemove = .1,
                       numExtremesToRemove = NULL,
                       removeTail = "both",

                       extraParam = NULL,
                       extraParam2 = NULL,

                       custom_colFun = NULL,
                       custom_fun_paramsList = NULL,
                       coresAcrossGroups = parallel::detectCores(),
                       coresAcrossCols = 1,
                       returnAs = "data.table",
                       returnParams = FALSE,
                       progressBar = TRUE,
                       ...){
  return(
    list(
         stat = stat,

         makeGroups = makeGroups,
         makeGroupSize = makeGroupSize,
         idCol = idCol,
         makeGroup_by_col = makeGroup_by_col,
         staggerChunk = staggerChunk,
         groupTogetherIfGreaterThanGroupSize = groupTogetherIfGreaterThanGroupSize,
         splitHighVarMeanGrps = splitHighVarMeanGrps,
         eval_by_group_col = eval_by_group_col,

         cols_to_evaluate = cols_to_evaluate,
         cols_to_not_evaluate =   cols_to_not_evaluate,
         cols_to_remove = cols_to_remove,
         propExtremesToRemove = propExtremesToRemove,
         numExtremesToRemove = numExtremesToRemove,
         removeTail = removeTail,
         extraParam = extraParam,
         extraParam2 = extraParam2,
         custom_colFun = custom_colFun,
         custom_fun_paramsList = custom_fun_paramsList,
         coresAcrossGroups = coresAcrossGroups,
         coresAcrossCols = coresAcrossCols,
         returnAs = returnAs,
         returnParams = returnParams,
         progressBar = progressBar)

    )

}


#Function to easily update a previously created paramsList
#-------------------------------------------------------------------------------
#' Function to update parameters set using vs.set_params_convert
#' @inheritParams vs.set_params_convert
#' @export
vs.update_params_convert <- function(paramsList,
                                     stat = NULL,
                                     idCol = NULL,

                                     makeGroups = NULL,
                                     makeGroupSize = NULL,
                                     makeGroup_by_col = NULL,
                                     staggerChunk = NULL,
                                     splitHighVarMeanGrps = NULL,
                                     groupTogetherIfGreaterThanGroupSize = NULL,

                                     eval_by_group_col = NULL,

                                     cols_to_evaluate = NULL,
                                     cols_to_not_evaluate = NULL,
                                     cols_to_remove = NULL,
                                     propExtremesToRemove = NULL,
                                     numExtremesToRemove = NULL,
                                     removeTail = NULL,
                                     extraParam = NULL,
                                     extraParam2 = NULL,
                                     custom_colFun = NULL,
                                     custom_fun_paramsList = NULL,
                                     coresAcrossGroups = NULL,
                                     coresAcrossCols = NULL,
                                     returnAs = NULL,
                                     returnParams = NULL,
                                     progressBar = NULL,
                                     ...){

  if(!is.null(stat)){paramsList$stat = stat}

  if(!is.null(makeGroups)){paramsList$makeGroups = makeGroups}
  if(!is.null(makeGroupSize)){paramsList$makeGroupSize = makeGroupSize}
  if(!is.null(idCol)){paramsList$idCol = idCol}
  if(!is.null(makeGroup_by_col)){paramsList$makeGroup_by_col = makeGroup_by_col}
  if(!is.null(staggerChunk)){paramsList$staggerChunk = staggerChunk}
  if(!is.null(groupTogetherIfGreaterThanGroupSize)){
    paramsList$groupTogetherIfGreaterThanGroupSize =
      groupTogetherIfGreaterThanGroupSize}

  if(!is.null(splitHighVarMeanGrps)){
    paramsList$splitHighVarMeanGrps = splitHighVarMeanGrps
  }

  if(!is.null(eval_by_group_col)){
    paramsList$eval_by_group_col = eval_by_group_col}

  if(!is.null(cols_to_evaluate)){paramsList$cols_to_evaluate = cols_to_evaluate}
  if(!is.null(cols_to_not_evaluate)){
    paramsList$cols_to_not_evaluate = cols_to_not_evaluate}
  if(!is.null(cols_to_remove)){paramsList$cols_to_remove = cols_to_remove}
  if(!is.null(propExtremesToRemove)){
    paramsList$propExtremesToRemove = propExtremesToRemove}


  if(!is.null(numExtremesToRemove)){
    paramsList$numExtremesToRemove = numExtremesToRemove}
  if(!is.null(removeTail)){paramsList$removeTail = removeTail}
  if(!is.null(extraParam)){ paramsList$extraParam = extraParam}
  if(!is.null(extraParam2)){paramsList$extraParam = extraParam2}
  if(!is.null(custom_colFun)){paramsList$custom_colFun = custom_colFun}
  if(!is.null(custom_fun_paramsList)){
    paramsList$custom_fun_paramsList = custom_fun_paramsList}
  if(!is.null(coresAcrossGroups)){
    paramsList$coresAcrossGroups = coresAcrossGroups}
  if(!is.null(coresAcrossCols)){paramsList$coresAcrossCols = coresAcrossCols}
  if(!is.null(returnAs)){paramsList$returnAs = returnAs}
  if(!is.null(returnParams)){paramsList$returnParams = returnParams}
  if(!is.null(progressBar)){paramsList$progressBar = progressBar}


  return(paramsList)
}
#-------------------------------------------------------------------------------






#' Function to Convert a data.table or data.frame or a list of data.tables/frames based on a new
#' statistic in a colum-wise fashion.
#'
#' Function to Convert a data.table or data.frame or a list of data.tables/frames based on a new
#' statistic in a colum-wise fashion. That is, distributions are assumed to be
#' comprised within columns, not rows, and each column is a distinct sample. If
#' a list is provided (or created by setting \code{makeGroups} to TRUE *OR* by
#' using \code{split_to_list_by = "myCol_with_Group_Identifiers"}) then all of
#' the distributions be relative to just the values within that group/list
#' element.  It is usually a good idea to input a data frame and if it needs to
#' be evaluated in chunks, then set \code{makeGroups = TRUE} and fill in
#' \code{makeGroupSize, idCol,makeGroup_by_col, staggerChunk,
#' groupTogetherIfGreaterThanGroupSize}. If this has already been done, and you
#' are, for instance chaining two rounds together, then you can use
#' \code{split_to_list_by = "group"} where the column "group" was produced in
#' the first call to \code{vs.makeGroups} when \code{makeGroups} was set to
#' \code{TRUE}.
#'
#' @param data A data.table (or it will transform into a data.table if not
#'   already) or a list of data.tables, with each column representing the data
#'   to convert. Columns can be included that are not evaluated by passing the
#'   column names to \code{cols_to_not_evaluate} (which by default are
#'   c("id","group","input"). Only specific columns can be evaluated with
#'   inclusion of \code{cols_to_evaluate}. Other columns can just be removed
#'   alltogether with \code{cols_to_remove}.
#'
#' @param paramsList A list of all of the parameters, created using: \code{\link{vs.set_params_convert}} function. Any of the entries to the set_params function can be overridden by inputting them manually here as arguments, but in general, including only the data and the paramsList should suffice.
#' @inheritParams vs.set_params_convert
#'
#' @return Returns a list list(out = the converted data, params = parameters used to convert). If the data is input as a list it will remain as a list within the first element of the returned list (a nested list). If it is a dataframe or data table that is uploaded, then the first element of the returend list will just be that data, but converted. In either case, the second element of the output will be the relevant parameters used to create the conversion.
#'
#' @export
vs.convert <- function(data,
                       paramsList,
                       stat = NULL,
                       idCol = NULL,

                       makeGroups = NULL,
                       makeGroupSize = NULL,
                       makeGroup_by_col = NULL,
                       staggerChunk = NULL,
                       groupTogetherIfGreaterThanGroupSize = NULL,
                       splitHighVarMeanGrps = NULL,

                       eval_by_group_col = NULL,

                       cols_to_evaluate = NULL,
                       cols_to_not_evaluate = NULL,
                       cols_to_remove = NULL,


                       propExtremesToRemove = NULL,
                       numExtremesToRemove = NULL,
                       removeTail = NULL,
                       extraParam = NULL,
                       extraParam2 = NULL,
                       custom_colFun = NULL,
                       custom_fun_paramsList = NULL,
                       coresAcrossGroups = NULL,
                       coresAcrossCols = NULL,
                       returnAs = NULL,
                       returnParams = NULL,
                       progressBar = NULL,
                       ...){
  # stat = NULL
  # idCol = NULL
  # 
  # makeGroups = NULL
  # makeGroupSize = NULL
  # makeGroup_by_col = NULL
  # staggerChunk = NULL
  # groupTogetherIfGreaterThanGroupSize = NULL
  # splitHighVarMeanGrps = NULL
  # eval_by_group_col = NULL
  # 
  # cols_to_evaluate = NULL
  # cols_to_not_evaluate = NULL
  # cols_to_remove = NULL
  # propExtremesToRemove = NULL
  # numExtremesToRemove = NULL
  # removeTail = NULL
  # extraParam = NULL
  # extraParam2 = NULL
  # custom_colFun = NULL
  # custom_fun_paramsList = NULL
  # coresAcrossGroups = NULL
  # coresAcrossCols = NULL
  # returnAs = NULL
  # returnParams = NULL
  # progressBar = NULL


  #Read in paramsList
  #------------------------------------------------------------------------
  if(is.null(stat)){stat = paramsList$stat}

  if(is.null(makeGroups)){makeGroups = paramsList$makeGroups}
  if(is.null(makeGroupSize)){makeGroupSize = paramsList$makeGroupSize}
  if(is.null(idCol)){idCol = paramsList$idCol}
  if(is.null(makeGroup_by_col)){makeGroup_by_col = paramsList$makeGroup_by_col}
  if(is.null(staggerChunk)){staggerChunk = paramsList$staggerChunk}
  if(is.null(groupTogetherIfGreaterThanGroupSize)){
    groupTogetherIfGreaterThanGroupSize =
      paramsList$groupTogetherIfGreaterThanGroupSize}

  if(is.null(splitHighVarMeanGrps)){
    splitHighVarMeanGrps = paramsList$splitHighVarMeanGrps}

  if(is.null(eval_by_group_col)){
    eval_by_group_col = paramsList$eval_by_group_col}

  if(is.null(cols_to_evaluate)){cols_to_evaluate = paramsList$cols_to_evaluate}
  if(is.null(cols_to_not_evaluate)){
    cols_to_not_evaluate = paramsList$cols_to_not_evaluate}
  if(is.null(cols_to_remove)){cols_to_remove = paramsList$cols_to_remove}



  if(is.null(propExtremesToRemove)){
    propExtremesToRemove = paramsList$propExtremesToRemove}
  if(is.null(numExtremesToRemove)){
    numExtremesToRemove = paramsList$numExtremesToRemove}
  if(is.null(removeTail)){removeTail = paramsList$removeTail}
  if(is.null(extraParam)){extraParam = paramsList$extraParam}
  if(is.null(extraParam2)){extraParam2 = paramsList$extraParam2}
  if(is.null(custom_colFun)){custom_colFun = paramsList$custom_colFun}
  if(is.null(custom_fun_paramsList)){
    custom_fun_paramsList = paramsList$custom_fun_paramsList}
  if(is.null(coresAcrossGroups)){
    coresAcrossGroups = paramsList$coresAcrossGroups}
  if(is.null(coresAcrossCols)){coresAcrossCols = paramsList$coresAcrossCols}
  if(is.null(returnAs)){returnAs = paramsList$returnAs}
  if(is.null(returnParams)){returnParams = paramsList$returnParams}
  if(is.null(progressBar)){progressBar = paramsList$progressBar}
  #------------------------------------------------------------------------
  # END reading in paramsList

  tryParall_pbapply = FALSE
  if(progressBar & coresAcrossCols >1){
    if(require("pbmcapply",quietly = TRUE) == FALSE){
      tryParall_pbapply = TRUE
    } 
  }
  
  if((progressBar & coresAcrossCols == 1) |
     tryParall_pbapply){
    if(require("pbapply",quietly = TRUE) == FALSE){
      progressBar = FALSE
      tryParall_pbapply = FALSE
    }
  }
  
    
  
  
  if(class(data)[1] == "data.table"){
    data <- data.table::copy(data)
  }
  
  if(!is.null(eval_by_group_col)){
    if(eval_by_group_col == FALSE){
      eval_by_group_col = NULL
    }
  }
  
  
  if(is.null(makeGroups)){
    makeGroups == FALSE
  }
  
  
  if(length(stat)>1) {
    stat = stat[1]
    sprintf("Multiple entries for 'stat' listed. Please pipe distinct operations together using vs.update_params_convert. Using the first entry: stat = %s.",stat)
  }


  if(stat == "Z_score_rowWise"){
    makeGroups = FALSE
    eval_by_group_col = NULL
    if("list" %in% class(data)){
      stop("data must be a single data.table or data.frame, not a list object, if using 'stat = Z_score_rowWise'")
    }
  }
  
  if(makeGroups == FALSE & (!"list" %in% class(data)) & is.null(eval_by_group_col)){
    makeGroupSize = nrow(data)
    splitHighVarMeanGrps = FALSE
    staggerChunk = FALSE
    eval_by_group_col = NULL
    makeGroups = TRUE
  }
  


  #if it is already a list, this supercedes any other grouping.
  if("list" %in% class(data)){
    if(length(data)>1){
      if(makeGroups == TRUE){
        makeGroups = FALSE
        print("NOTE: Using the input list as groups. If a different grouping structure is desired, bind the list into a data.table first using data.table::rbindlist().")
      }
      if(!is.null(eval_by_group_col)){
        eval_by_group_col = NULL
        print("NOTE: Using the input list as groups. If a different grouping structure is desired, bind the list into a data.table first.")
      }

    } else {
      data = data[[1]] #if list of only one element, clean up to a single data.table.
    }
  }



  originalOrder = NULL

  namesData <- names(data)

  #Prioritize eval_by_group_col over makeGroups
  if(!is.null(eval_by_group_col)){
    if(makeGroups == TRUE & (eval_by_group_col %in% namesData)){
      makeGroups = FALSE #use already present eval_by_group_col for grouping
      print("WARNING: makeGroups is TRUE buy eval_by_group_col was found in the column names.  Prioritizing eval_by_group_col for grouping. To prevent this, set eval_by_group_col to NULL")
    }
  }

  #Make Groups
  #------------------------------------------------------------------------
  if(makeGroups == TRUE){
    if(!idCol %in% namesData){
      stop("idCol must be specified and must exist in the column names of the supplied data")
    }


    if(class(data)[1] != "data.table"){data <- data.table::setDT(data)}

    if("group" %in% namesData){
      names(data)[which(names(data)=="group")] <- "group.x"
    }

    originalOrder <- data[,..idCol,with = FALSE]


    data <- vs.makeGroups(dataToGroup = data,
                          groupSize = round(makeGroupSize,digits = 0),
                          idCol = idCol,
                          groupingCol = makeGroup_by_col,
                          staggerChunk = staggerChunk,
                          groupTogetherIfGreaterThanGroupSize =
                            groupTogetherIfGreaterThanGroupSize,
                          splitHighVarMeanGrps = splitHighVarMeanGrps,
                          returnData = TRUE,
                          returnAs = "data.table",
                          returnAsList = TRUE)


      cols_to_not_evaluate <- unique(c("group",makeGroup_by_col,cols_to_not_evaluate))

    eval_by_group_col = NULL
  }
  #------------------------------------------------------------------------
  #end makeGroups


  #Split Into Groups
  #------------------------------------------------------------------------
  if((!is.null(eval_by_group_col)) ){
    if(!idCol %in% namesData){
      stop("idCol,specifying the meaning of each row (i.e. epitope ID) must be specified and must exist in the column names of the supplied data")
    }


    if(class(data)[1] != "data.table"){data <- data.table::setDT(data)}
    originalOrder <- data[,..idCol,with = FALSE]
    data <- mmR::mm.split_to_list(data,by = eval_by_group_col)
    cols_to_not_evaluate <- unique(c(eval_by_group_col,cols_to_not_evaluate))
  }
  #------------------------------------------------------------------------
  #end splitting into a list by group.


  if(max(("data.table" %in% class(data)) | ("data.frame" %in% class(data)))==1){
    Xlength = 1
  } else {
    Xlength <- length(data)
  }




    if(coresAcrossGroups >1){
      if(progressBar){
        out <- pbmcapply::pbmclapply(
          #X=1,
          X = c(1:Xlength),
          FUN <- vs.convert_parallel.int,
          data = data,
          stat = stat,
          cols_to_evaluate = cols_to_evaluate,
          cols_to_not_evaluate =   cols_to_not_evaluate,
          cols_to_remove = cols_to_remove,
          propExtremesToRemove = propExtremesToRemove,
          numExtremesToRemove = numExtremesToRemove,
          removeTail = removeTail,
          extraParam = extraParam,
          extraParam2 = extraParam2,
          custom_colFun = custom_colFun,
          custom_fun_paramsList = custom_fun_paramsList,
          coresAcrossCols = coresAcrossCols,
          returnParams = returnParams,
          mc.cores = coresAcrossGroups)  
      } else if(tryParall_pbapply){
        out <- 
          pbapply::pblapply(
          #X=1,
          X = c(1:Xlength),
          FUN <- vs.convert_parallel.int,
          data = data,
          stat = stat,
          cols_to_evaluate = cols_to_evaluate,
          cols_to_not_evaluate =   cols_to_not_evaluate,
          cols_to_remove = cols_to_remove,
          propExtremesToRemove = propExtremesToRemove,
          numExtremesToRemove = numExtremesToRemove,
          removeTail = removeTail,
          extraParam = extraParam,
          extraParam2 = extraParam2,
          custom_colFun = custom_colFun,
          custom_fun_paramsList = custom_fun_paramsList,
          coresAcrossCols = coresAcrossCols,
          returnParams = returnParams,
          cl = coresAcrossGroups)
      } else {
        out <- parallel::mclapply(
          #X=1,
          X = c(1:Xlength),
          FUN <- vs.convert_parallel.int,
          data = data,
          stat = stat,
          cols_to_evaluate = cols_to_evaluate,
          cols_to_not_evaluate =   cols_to_not_evaluate,
          cols_to_remove = cols_to_remove,
          propExtremesToRemove = propExtremesToRemove,
          numExtremesToRemove = numExtremesToRemove,
          removeTail = removeTail,
          extraParam = extraParam,
          extraParam2 = extraParam2,
          custom_colFun = custom_colFun,
          custom_fun_paramsList = custom_fun_paramsList,
          coresAcrossCols = coresAcrossCols,
          returnParams = returnParams,
          mc.cores = coresAcrossGroups)
      }
    } else {
      if(progressBar){
        out <- pbapply::pblapply(
          X = c(1:Xlength),
          FUN <- vs.convert_parallel.int,
          data = data,
          stat = stat,
          cols_to_evaluate = cols_to_evaluate,
          cols_to_not_evaluate =   cols_to_not_evaluate,
          cols_to_remove = cols_to_remove,
          propExtremesToRemove = propExtremesToRemove,
          numExtremesToRemove = numExtremesToRemove,
          removeTail = removeTail,
          extraParam = extraParam,
          extraParam2 = extraParam2,
          custom_colFun = custom_colFun,
          custom_fun_paramsList = custom_fun_paramsList,
          coresAcrossCols = coresAcrossCols,
          returnParams = returnParams)
      } 
      else {
        out <- lapply(
          X = c(1:Xlength),
          FUN <- vs.convert_parallel.int,
          data = data,
          stat = stat,
          cols_to_evaluate = cols_to_evaluate,
          cols_to_not_evaluate =   cols_to_not_evaluate,
          cols_to_remove = cols_to_remove,
          propExtremesToRemove = propExtremesToRemove,
          numExtremesToRemove = numExtremesToRemove,
          removeTail = removeTail,
          extraParam = extraParam,
          extraParam2 = extraParam2,
          custom_colFun = custom_colFun,
          custom_fun_paramsList = custom_fun_paramsList,
          coresAcrossCols = coresAcrossCols,
          returnParams = returnParams)
      }
    }

    if(returnParams == TRUE){
      paramsList <- sapply(out,function(x) x["params"])
      #i=1

      for(i in 1:length(paramsList)){
        paramsList[[i]]$group = i
        paramsList[[i]] <-

          paramsList[[i]][, c("parameter","group",names(paramsList[[i]]) [-c(1,  ncol(paramsList[[i]])) ])]
      }
    }


    #Merge back with original Order
    if(!is.null(originalOrder)){
      if(returnParams) {params <- data.table::rbindlist(paramsList)}
      out <- data.table::rbindlist(sapply(out,function(x) x["out"]))
      out <- out[originalOrder,on = idCol]
    } else {
      returnAs = "data.table" #do this to prevent a list from attempting to convert to a single data frame.
      if(returnParams){ params <- paramsList}
    }



    if(returnAs == "data.frame"){
      out <- data.table::setDF(out)
      if(returnParams) {params <- data.table::setDF(params)}

    } else if (returnAs %in% c("data_frame","tbl_df","tbl","tibble")){
      out <- dplyr::as_tibble(out)
      if(returnParams) {params <- dplyr::as_tibble(params)}
    }

  
    if(returnParams){
      return(list(out = out,
                  params = params))
    } else {
      return(out = out)
    }

}






#-------------------------------------------------------------------------------
#Simple function to allow lapply or mclapply on vs.convert_one_DT
#-------------------------------------------------------------------------------
#' Internal function to allow parallel processing of vs.convert. Essentially
#' runs vs.convert_one_DT().
vs.convert_parallel.int <-
  function( X,
            data = NULL,
            stat = NULL,
            cols_to_evaluate = NULL,
            cols_to_not_evaluate =   NULL,
            cols_to_remove = NULL,
            propExtremesToRemove = NULL,
            numExtremesToRemove = NULL,
            removeTail = NULL,
            extraParam = NULL,
            extraParam2 = NULL,
            custom_colFun = NULL,
            custom_fun_paramsList = NULL,
            coresAcrossCols = NULL,
            ...){

    
    #X=4
    if(max((class(data) == "data.table") | (class(data) == "data.frame"))==1){
      data.table::setDT(data)
      dataX <- data.table::copy(data)
    } else {
      data.table::setDT(data[[X]])
      dataX <- data.table::copy(data[[X]])
    }

    #cols_to_remove <- "group"
    if(!is.null(cols_to_remove)){
      toRemove <- names(dataX)[which(names(dataX) %in% cols_to_remove)]
      suppressWarnings(try(dataX[,(toRemove) := NULL],silent = TRUE))
    }

    namesToReturn <- as.character(as.data.frame(names(dataX))[,1])

    #cols_to_evaluate <- c("BL1.9","BL1.10","BL1.11","BL1.12","BL1.13","BL1.14")
    #cols_to_not_evaluate <- c("BL1.11","BL1.12")

    if(!is.null(cols_to_not_evaluate) & !is.null(cols_to_evaluate)){

      removeFromEvaluate <-
        which(cols_to_evaluate %in% cols_to_not_evaluate)
      if(length(removeFromEvaluate)>0){
        cols_to_evaluate <- cols_to_evaluate[-removeFromEvaluate]  
      }
      
      if(length(cols_to_evaluate) == 0){
        cols_to_evaluate = NULL
      }
    }

    noEvalDT <- data.table::data.table()
    #cols_to_evaluate <- c("BL1.9","BL1.11")
    if(!is.null(cols_to_not_evaluate)){
      noEval <- as.vector(names(dataX))[which(names(dataX) %in% cols_to_not_evaluate)]
      if(length(noEval)>0){
        
        noEvalDT <- data.table::copy(dataX)[, noEval,with = FALSE]
        
        dataX[, (noEval) := NULL]
      }

    }

    if(!is.null(cols_to_evaluate)){
      toEval <- as.vector(names(dataX))[which(names(dataX) %in% cols_to_evaluate)]
      if(length(toEval) < length(names(dataX))){
        noEval <- as.vector(names(dataX))[which(!names(dataX) %in% cols_to_evaluate)]
        if(length(noEval)>0){
          if(ncol(noEvalDT)>0){
            noEvalDT <-
              data.table::data.table(
                cbind(data.table::copy(dataX)[, noEval,with = FALSE],
                      noEvalDT))
          } else {
            noEvalDT <- data.table::copy(dataX)[, noEval,with = FALSE]
          }
          dataX[, (noEval) := NULL]
        }
      }
    }



    converted_list <-
      vs.convert_one_DT(
        data = dataX,
        stat = stat,
        propExtremesToRemove = propExtremesToRemove,
        numExtremesToRemove = numExtremesToRemove,
        removeTail = removeTail,
        extraParam = extraParam,
        extraParam2 = extraParam2,
        custom_colFun = custom_colFun,
        custom_fun_paramsList = custom_fun_paramsList,
        cores = coresAcrossCols)


    if(ncol(noEvalDT)==0){ noEvalDT <- NULL}

    if("out" %in% names(converted_list)){
      out=
        dplyr::bind_cols(
          noEvalDT,
          converted_list$out)
      data.table::setcolorder(out, namesToReturn)
    } else {out = data.table()}

    if("params" %in% names(converted_list)){
      params <- converted_list$params
    } else {params = data.frame()}

    return(list(out = out, params = params))

  }
#-------------------------------------------------------------------------------





#data <- ln_fold_enrich_list[[1]] %>% dplyr::select(-group)
#parameters <- paramsList[[1]] %>% dplyr::select(-group)
#type = "ln_fold_enrich"
#stat = "NLP_norm"
#full_name = NULL
#cores = parallel::detectCores()

#Requires a data DF with id as first col and samples after
#Requires a parameters DF with 'parameter' as first column and samples after
#vs.convert_one_df(data = data,parameters = parameters,stat = "NLP_nBinom",dataType = "counts")
#' Convert a data.table or data.frame object where each column is a sample.
#' 
#' 
#' @param data A data.table (or it will transform into a data.table if not
#'   already) with each column representing the data to convert. All columns
#'   will be evaluated. TIP: Usually it is best to use \code{\link{vs.convert}} if
#'   there exist any identifying columns to not be evaluated.
#'
#'
#' @param cores Number of cores to run over. Will run different columns in
#'   parallel.  Default is parallel::detectCores(). If set to 1, will use
#'   lapply() if set to >1 will use parallel::mclapply(). TIP: If only have a couple
#'   of samples, might want to save the parallel core use for the function that
#'   is calling this function, if for example it is working over many different
#'   groups and only a few columns.
#'
#' @inheritParams vs.convert
#' @importFrom magrittr %>%
#' @importFrom data.table :=
#' @export


vs.convert_one_DT <-
  function(data,
           stat = "Z_score",
           propExtremesToRemove = .1,
           numExtremesToRemove = NULL,
           removeTail = "both",
           extraParam = 6,
           extraParam2 = NULL,
           custom_colFun = NULL,
           custom_fun_paramsList = NULL,
           cores = parallel::detectCores(),
           ...){

    #make sure it's a data.table format
    if(!class(data)[1] == "data.table"){
      data <- data.table::setDT(data)
    }
    data <- data.table::copy(data)

    if(is.null(numExtremesToRemove)){
      nrows <- data[,.N]
      nrowsRemove <- round(nrows * propExtremesToRemove, digits = 0)
    } else {
      nrowsRemove <- numExtremesToRemove
    }

    if(removeTail == "both"){
      rowsTrimmed <- c((nrowsRemove+1):(nrows-nrowsRemove))
    } else if(removeTail == "lower"){
      rowsTrimmed = c((nrowsRemove+1):nrows)
    } else if(removeTail == "upper"){
      rowsTrimmed <- c(1:(nrows-nrowsRemove))
    } else {
      rowsTrimmed <- c(1:nrows)
    }



    paramsList <- list()

    if(stat == "ihs_transform"){
      colFun <- vs.colFun.ihs_transform
      if(is.null(extraParam)){
        extraParam <- 2
        print(paste("Warning: 'stat = ihs_transform' requires a theta (akin to ",
                    "a base in a log transformation) and theta was not set.",
                     "Defaulting to 2. To set it, use 'extraParam', which ",
                     "will be passed in as theta to the function."))
      }
      paramsList <-
          list(theta = extraParam)


    } else if (stat == "exp_transform"){
      colFun <- vs.colFun.exp_transform

    } else if (stat == "nlp_to_p_transform"){
      colFun <- vs.colFun.NLP_to_p_transform

    } else if (stat == "log1p_transform"){
      colFun <- vs.colFun.log1p_transform

    } else if (stat == "sqrt_transform"){
      colFun <- vs.colFun.sqrt_transform

    } else if (stat == "fold_enrich"){
      colFun <- vs.colFun.fold_enrich
      paramsList <- list(rowsTrimmed = rowsTrimmed)

    } else if(stat == "log_transform"){
      colFun <- vs.colFun.log_transform
      if(is.null(extraParam) & is.null(extraParam2)){
        print(paste("Warning: when using 'stat= log_transform' you should ",
                    "set either extraParam or extraParam2. See the parameter ",
                    "description. DEFAULT: Setting log(0) zeros to 2"))
        extraParam = 2
      }
      paramsList <-
        list(rowsTrimmed = rowsTrimmed,
             val = extraParam,
             sd = extraParam2)

    } else if(stat == "NLP_norm"){
      colFun <- vs.colFun.NLP_norm
      paramsList <- list(rowsTrimmed = rowsTrimmed)

    } else if(stat == "NLP_pois"){
      colFun <- vs.colFun.NLP_pois
      paramsList <- list(rowsTrimmed = rowsTrimmed)

    } else if(stat == "NLP_nBinom"){
      colFun <- vs.colFun.NLP_nBinom
      paramsList <- list(rowsTrimmed = rowsTrimmed)

    } else if(stat == "NLP_zinBinom"){
      colFun <- vs.colFun.NLP_zinBinom
      paramsList <- list(rowsTrimmed = rowsTrimmed)

    } else if(stat == "Z_score"){
      colFun <- vs.colFun.Z_score
      paramsList <- list(rowsTrimmed = rowsTrimmed)

    } else if(stat == "Z_score_rowWise"){
      colFun <- vs.Fun_rowWise_Z
      paramsList <- list(rowsTrimmed = rowsTrimmed,
                         beads_meanRows = extraParam,
                         beads_sdRows = extraParam2)
      
    } else if(stat == "custom"){
      colFun <- custom_colFun
      paramsList <-
        append(custom_fun_paramsList,
               list(rowsTrimmed = rowsTrimmed))
    } else {
      stop("Must accurately specify 'stat' parameter")
    }

      #---------------------------------------------------------------------------
    #Run the stats in parallel over the number of samples and
    #COMBINE ALL OF THE SAMPLE  COLUMNS BACK TOGETHER
    #---------------------------------------------------------------------------
    if(cores >1){

      statList <-
        parallel::mclapply(X = c(1:(ncol(data))),
                           FUN = colFun,
                           data = data,
                           paramsList = paramsList,
                           mc.cores = cores)
    } else {
      statList <-

        lapply(X = c(1:(ncol(data))),
               FUN = colFun,
               data = data,
               paramsList = paramsList)
    }



    params <- data.frame(statList[[1]]["params"])
    params[,1] <- rownames(params)
    names(params) <- "parameter"

    paramsList <- sapply(statList,function(x) x["params"])
    statList <- sapply(statList,function(x) x["temp"])


    if(length(paramsList)==0){ paramsList <- NULL}
    if(length(statList)==0){ statList <- NULL}

    out=
      dplyr::bind_cols(statList)

    params <- dplyr::bind_cols(
      params,paramsList
    )



    return(
      list(out = out,
        params = params)
      )
  }









#---------------------------------------------------------------------------
#---------------------------------------------------------------------------
# The rest of the script is all of the column-wise functions used in the
# transformations.
#---------------------------------------------------------------------------
#---------------------------------------------------------------------------


#set Function to return log+1 transform
#---------------------------------------------------------------------------
vs.colFun.log1p_transform <- function(X, #X is full_name
                                  data,
                                  ...){

  colName <- names(data)[X]

  temp <- data.table::copy(data[,.(data[[colName]])]) #isolate column

  #calculate pvalues against the normal distribution
  temp[, V1 := log1p(V1)]

  names(temp) <- c(colName) #rename column
  params <- data.frame(temp = NA)
  names(params) <- colName
  rownames(params) <- c("log1p")

  return(list(temp = temp,params=params))
}




#set Function to return exponential transform
#---------------------------------------------------------------------------
vs.colFun.exp_transform <- function(X, #X is full_name
                                     data,
                                     ...){

  colName <- names(data)[X]

  temp <- data.table::copy(data[,.(data[[colName]])]) #isolate column

  #calculate pvalues against the normal distribution
  temp[, V1 := exp(V1)]

  names(temp) <- c(colName) #rename column
  params <- data.frame(sqrt = NA)
  names(params) <- colName
  rownames(params) <- c("exp")

  return(list(temp = temp,params=params))
}



#set Function to return 1/exponential transform
#---------------------------------------------------------------------------
vs.colFun.NLP_to_p_transform <- function(X, #X is full_name
                                    data,
                                    ...){

  colName <- names(data)[X]

  temp <- data.table::copy(data[,.(data[[colName]])]) #isolate column

  #calculate pvalues against the normal distribution
  temp[, V1 := 1/exp(V1)]

  names(temp) <- c(colName) #rename column
  params <- data.frame(sqrt = NA)
  names(params) <- colName
  rownames(params) <- c("exp")

  return(list(temp = temp,params=params))
}






#set Function to return sqrt transform
#---------------------------------------------------------------------------
vs.colFun.sqrt_transform <- function(X, #X is full_name
                                      data,
                                      ...){

  colName <- names(data)[X]

  temp <- data.table::copy(data[,.(data[[colName]])]) #isolate column

  #calculate pvalues against the normal distribution
  temp[, V1 := sqrt(V1)]

  names(temp) <- c(colName) #rename column
  params <- data.frame(sqrt = NA)
  names(params) <- colName
  rownames(params) <- c("sqrt")

  return(list(temp = temp,params=params))
}

#set Function to return Inverse Hyperbolic sine transform
#---------------------------------------------------------------------------
vs.colFun.ihs_transform <- function(X, #X is full_name
                                     data,
                                     paramsList,
                                     ...){

  theta <- paramsList$theta

  colName <- names(data)[X]

  temp <- data.table::copy(data[,.(data[[colName]])]) #isolate column

  ihs <- function(y,theta){
    return(log( (theta*y) + ((theta*theta*y*y+1)^.5)  )/theta)
  }

  #calculate pvalues against the normal distribution
  temp[, V1 := ihs(V1,theta)]

  names(temp) <- c(colName) #rename column
  params <- data.frame(sqrt = NA)
  names(params) <- colName
  rownames(params) <- c("sqrt")

  return(list(temp = temp,params=params))
}


#set Function to return fold_enrich
#---------------------------------------------------------------------------
vs.colFun.fold_enrich <- function(X, #X is full_name
                               data,
                               paramsList,
                               ...){
  rowsTrimmed <- paramsList$rowsTrimmed
  colName <- names(data)[X]

  temp <- data.table::copy(data[,.(data[[colName]])]) #isolate column
  params <- temp[order(V1)][rowsTrimmed,][,.(mean = mean(V1))]

  #calculate pvalues against the normal distribution
  temp[, V1 := V1/params[,mean]]

  names(temp) <- c(colName) #rename column
  params <- data.frame(data.table::transpose(params))
  names(params) <- colName
  rownames(params) <- c("mean")

  return(list(temp = temp,params=params))
}


#Function to return log_transform
#---------------------------------------------------------------------------
vs.colFun.log_transform <- function(X, #X is full_name
                                 data,
                                 paramsList,
                                 ...){

  rowsTrimmed <- paramsList$rowsTrimmed
  sd <- paramsList$sd
  val <- paramsList$sd

  colName <- names(data)[X]

  temp <- data.table::copy(data[,.(data[[colName]])]) #isolate column
  #Need to get rid of zeros in order to log_transform
  #we will log transform, and then convert all those that failed to
  #log transform into
  #mean(log(counts[rowsTrimmed])) - 6*sd(log(counts[rowsTrimmed]))

  temp[V1 != 0, V3 := log(V1)]

  if(!is.null(val)){

    temp[V1 == 0, V3 := val]
  } else if(!is.null(sd)) {

    mean_sd<-temp[order(V1)][rowsTrimmed,][V1 != 0,][,c(mean = mean(V3),sd = sd(V3))]

    if(!is.null(sd)){
      if(!is.na(sd)){
        temp[V1 == 0,V3 := mean_sd["mean"] - sd * mean_sd["sd"]]
      } else { temp[V1 == 0,V3 := NA] }
    } else { temp[V1 == 0,V3 := NA] }

  }


  colsToDelete <- c("V1")
  temp[,(colsToDelete) := NULL]
  names(temp) <- c(colName) #rename column

  if(!is.null(sd)){
    if(!is.na(sd)){
      params <- data.frame(colName = mean_sd["mean"] - sd * mean_sd["sd"])
    } else { params <- NA }
  } else { params <- NA }




  names(params) <- colName
  rownames(params) <- c("setLog0sTo")

  return(list(temp = temp,params=params))
}


#Function to return negative log P value from normal distribution
#---------------------------------------------------------------------------
vs.colFun.NLP_norm <- function(X, #X is full_name
                               data,
                               paramsList,
                               ...){

  rowsTrimmed <- paramsList$rowsTrimmed

  colName <- names(data)[X]
  temp <- data.table::copy(data[,.(data[[colName]])]) #isolate column
  params <- temp[order(V1)][rowsTrimmed,][,.(mean = mean(V1),sd = sd(V1))]

  #calculate pvalues against the normal distribution
  temp[, V1 := -stats::pnorm(q=V1,
                             mean = params[,mean],
                             sd = params[,sd],
                             lower.tail = FALSE,log.p = TRUE)]

  names(temp) <- c(colName) #rename column
  params <- data.frame(data.table::transpose(params))
  names(params) <- colName
  rownames(params) <- c("mean","sd")

  return(list(temp = temp,params=params))
}


#set Function to get the negative lop p values of poisson
#---------------------------------------------------------------------------
vs.colFun.NLP_pois <- function(X, #X is full_name
                               data,
                               paramsList,
                               ...){

  rowsTrimmed <- paramsList$rowsTrimmed

  colName <- names(data)[X]

  temp <- data.table::copy(data[,.(data[[colName]])]) #isolate column
  lambda <- mean(temp[order(V1)][rowsTrimmed,][,V1],na.rm = TRUE)

  temp[, V1 := -stats::ppois(q=V1,
                             lambda = lambda,
                             lower.tail = FALSE,log.p = TRUE)] #calculate Z scores
  names(temp) <- c(colName) #rename column

  params <- data.frame(colName = c(lambda))
  names(params) <- colName
  rownames(params) <- c("lambda")

  return(list(temp = temp,params=params))
}

#set Function to get the negative lop p values of negative binomial
#---------------------------------------------------------------------------
vs.colFun.NLP_nBinom <- function(X, #X is full_name
                                 data,
                                 paramsList,
                                 ...){

  rowsTrimmed <- paramsList$rowsTrimmed

  colName <- names(data)[X]

  temp <- data.table::copy(data[,.(data[[colName]])]) #isolate column

  nBinomFit = NULL
  try(
    nBinomFit <-
    coef(
      fitdistrplus::fitdist(
        data = temp[order(V1)][rowsTrimmed,][,V1],
        distr = "nbinom")),
    silent = TRUE)

  #IF THIS DOESN"T  FAIL
  if(!is.null(nBinomFit)){

    size = nBinomFit["size"]
    mu = nBinomFit["mu"]

    #calculate negative log P for neg binomial
    temp[, V1 := -stats::pnbinom(q=V1,
                                 size = size,
                                 mu = mu,
                                 lower.tail = FALSE,
                                 log.p = TRUE)]

    names(temp) <- c(colName)  #rename column
    params <- data.frame(colName = c(size,mu))
    names(params) <- colName
    rownames(params) <- c("size","mu")

    return(list(temp = temp,params=params))
  } else { #if it failed
    temp[,V1 := NA]
    names(temp) <- c(colName)  #rename column
    params <- data.frame(colName = c(NA,NA))
    names(params) <- colName
    rownames(params) <- c("size","mu")
    return(list(temp = temp,params=params))
  }
}

#set Function to get the negative lop p values of Zero inflated negative binomial
#---------------------------------------------------------------------------
vs.colFun.NLP_zinBinom <- function(X, #X is full_name
                                   data,
                                   paramsList,
                                   ...){

  rowsTrimmed <- paramsList$rowsTrimmed

  colName <- names(data)[X]

  temp <- data.table::copy(data[,.(data[[colName]])]) #isolate column

  fit = VGAM::vglm(temp[order(V1)][rowsTrimmed,][,V1] ~ 1,
                   zinegbinomial(zero=NULL), trace=TRUE)

  nbCoefs <- stats::coef(fit, matrix=TRUE)


  #calculate negative log P for neg binomial
  pstr0 <- boot::inv.logit(nbCoefs[1])
  munb <- exp(nbCoefs[2])
  size <- exp(nbCoefs[3])
  temp[, V1 := -vs.pzinegbin(q=V1,
                             pstr0 = pstr0,
                             mu = munb,
                             size = size,
                             log.p = TRUE,
                             lower.tail = FALSE)]


  names(temp) <- c(colName) #rename column
  params <- data.frame(colName = c(pstr0,munb,size))
  names(params) <- colName
  rownames(params) <- c("pstr0","munb","size")

  return(list(temp = temp,params=params))
}

# Function to return Zscore
#---------------------------------------------------------------------------
vs.colFun.Z_score <- function(X, #X is full_name
                              data,
                              paramsList,
                              ...){

  rowsTrimmed <- paramsList$rowsTrimmed

  colName <- names(data)[X]

  temp <- data.table::copy(data[,.(data[[colName]])]) #isolate column
  params <- temp[order(V1)][rowsTrimmed,][,.(mean = mean(V1,na.rm = TRUE),
                                             sd = sd(V1,na.rm = TRUE))]
  temp[, V1 := ((V1-params[,mean])/params[,sd])] #calculate Z scores

  names(temp) <- c(colName) #rename column
  params <- data.frame(data.table::transpose(params))
  names(params) <- colName
  rownames(params) <- c("mean","sd")

  return(list(temp = temp,params=params))
}

#-------------------
#Function to return row wise Z scores.
vs.Fun_rowWise_Z <- function(X,data,paramsList,...){
  colName <- names(data)[X]
  temp <- data.table::copy(data[,.(data[[colName]])]) #isolate column
  temp[,V1 := (V1 - paramsList$beads_meanRows)/paramsList$beads_sdRows]
  names(temp) <- c(colName) #rename column
  return(list(temp = temp,params = "rowWise"))
}



