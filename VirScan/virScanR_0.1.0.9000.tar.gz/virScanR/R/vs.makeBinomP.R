#------------------------------------------------------------------------------#
#makeBinomP.wide function
#------------------------------------------------------------------------------#
#' Takes a dataframe of pvals
#' and returns a same sized dataframe but with zeros and ones
#' with ones for anything significant (default is greater Than 2.3)
#'
#'
#' @param pVals A data frame or tbl_df or matrix of PValues to convert to 0,1
#'
#' @param pThresh The threshold above or below which to consider significant (1)
#'   or not (0)
#'
#' @param greaterThan If FALSE (DEFAULT) looks for p-values less than
#'   \code{pThresh} and makes them 1 and others 0. If True, calls p-values that
#'   are greater than the \code{pThres} one and others zero.
#'
#' @param nonSampleCols A vector of identifying
#'
#' @param colNamesToReturn Optional vector of names for the columns that are
#'   returns. This is particularly useful if feeding it a single vector from a
#'   data frame using myDF[,x] because in R, myDF[,x], where x is a single
#'   integer, is interpreted as an unnamed vector. Therefore, it can be useful
#'   to supply, for example, \code{colNamesToReturn = names(myDF)[x]}.
#'
#' @importFrom magrittr %>%
#'
#' @examples
#' set.seed(1001)
#' myDat <-
#' data.frame(id = c(1:20)) %>%
#' mutate(input = id*4) %>%
#' mutate(samp1 = runif(n = nrow(.),0,1),
#' samp2 = runif(n = nrow(.),0,1),
#' samp3 = runif(n = nrow(.),0,1),
#' samp4 = runif(n = nrow(.),0,1))
#'
#'
#' binom = vs.makeBinomP(pVals = myDat,
#'            pThresh = .1,
#'            greaterThan=TRUE,
#'            nonSampleCols = c("id","input"))
#'
#' binom2 = vs.makeBinom(pVals = myDat[,4],
#'                       colNamesToReturn = names(myDat)[4])
#'
#' @export
vs.makeBinomP <- function(pVals,
                          pThresh = 2.3,
                          greaterThan = FALSE,
                          nonSampleCols = "id",
                          colNamesToReturn = NULL){

  #make sure it's a DF. this is particularly needed if a vector is supplied.
  pVals <- data.frame(pVals)

  # check to see if here is some column that matches the the nonSampleCols
  # This is needed to not throw an error if trying to negatively select 0 columns
  # If there isn't, then add a temporary one as the first column.
  addedID = FALSE
  if(length(which(names(pVals) %in% nonSampleCols))==0){
    pVals <- cbind("tempID" = rep(1,nrow(pVals)), pVals)
    nonSampleCols = "tempId"
    addedID = TRUE
  }

  allNames <- names(pVals)
  pValNames <- names(pVals)[-which(names(pVals) %in% nonSampleCols)]


  #Define vectorized Functions to supply to apply, to be run over the columns.
  if(greaterThan == TRUE){

    makeBinFxn1 <- function(vec,pThresh){as.integer(ifelse(vec > pThresh,1,0))}
    changeNAFxn <- function(vec){ ifelse(is.na(vec),1,vec) }

  } else {

    makeBinFxn1 <- function(vec,pThresh){as.integer(ifelse(vec < pThresh,1,0))}
    changeNAFxn <- function(vec){ ifelse(is.na(vec),0,vec) }

  }

  #Combine the two functions
  makeBinFxn <- function(vec,pThesh){
    return(changeNAFxn(makeBinFxn1(vec, pThresh = pThresh)))
  }


  idCols <- data.frame(pVals[,nonSampleCols])
  names(idCols) <- nonSampleCols

  toReturn <-
    data.frame(
        apply(X = data.frame(pVals[,-which(names(pVals) %in% nonSampleCols)]),
              MARGIN = 2,
              FUN = makeBinFxn1,
              pThresh = pThresh
              )
        )
  names(toReturn) <- pValNames
  toReturn <-
    data.frame(
      cbind(idCols,toReturn)
    )[,allNames] #return back with columns in proper order.


  if(addedID == TRUE){
    toReturn = data.frame(toReturn[,-1])
    names(toReturn) <- pValNames
  }

  if(!is.null(colNamesToReturn)){
    if(length(colNamesToReturn) == ncol(toReturn)){
      names(toReturn) = colNamesToReturn
    }
  }

  return(toReturn)
}




 # set.seed(1001)
 # myDat <-
 # data.frame(id = c(1:20)) %>%
 # mutate(input = id*4) %>%
 # mutate(samp1 = runif(n = nrow(.),0,1),
 # samp2 = runif(n = nrow(.),0,1),
 # samp3 = runif(n = nrow(.),0,1),
 # samp4 = runif(n = nrow(.),0,1))
 #
 #
 # binom = vs.makeBinomP(pVals = myDat,
 #            pThresh = .1,
 #            greaterThan=TRUE,
 #            nonSampleCols = c("id","input","samp4"))
