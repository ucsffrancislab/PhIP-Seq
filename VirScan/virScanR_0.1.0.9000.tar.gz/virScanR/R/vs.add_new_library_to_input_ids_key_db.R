#' Convenience function to add a new library to the existing database of epitope
#' libraries.
#'
#' Convenience function to add a new library to the existing database of epitope
#' libraries. This requires a current database to have an "id" column as the
#' first column, which contains the ids, or set 'ids_col_name' to something
#' besides 'id' if needed. The next columns have headers which are the
#' 'input_name's and contain 1's if the id is part of that input_name library and 0
#' or NA if not. For the package to work properly, the input_name needs to be
#' specified correctly. See "inputLibKey" in the SamplesMetaData excel sheet for
#' formatting... or if you don't have that worksheet, run
#' \link{virScanR::vs.create_example_sampleMetaData} to create an example
#' worksheet to fill in the meta data for the samples and for the input library
#' (specifically, see 'inputLibKey' worksheet. Once you fill out the inputLibKey
#' it will give you the appropriate name for the input_name.
#'
#' @param current_ids_key_db_path The full or relative  path to where the
#'   currently existing ids data base is. If this is not specified, then this
#'   function will create a new one at the location of 'savePath' or just in the
#'   working directory.
#' @param new_ids_vec A vector of the new ids to add or a one column df
#' @param new_library_input_name the name of the new library. WARNING,
#'   'input_name' is not the same as the input_id. input_name is general to the
#'   peptides and not the amplification (i.e. vir3 or pep2). See "inputLibKey"
#'   in the SamplesMetaData excel sheet for formatting... or if you don't have
#'   that worksheet, run \link{virScanR::vs.create_example_sampleMetaData} to
#'   create an example worksheet to fill in the meta data for the samples and
#'   for the input library (specifically, see input_name of the 'inputLibKey'
#'   worksheet. Once you fill out the inputLibKey it will give you the
#'   appropriate name for the input_id given the input_name(s) and amplification
#'   date(s) that you provide. But aain, here you only need the input_name.
#' @param overwrite_existing_input_name_col DEFAULT FALSE. If TRUE, the new
#'   input id being added will replace any existing input library that shares
#'   the same 'input_name' name. If FALSE but the new_library_input_name already
#'   exists
#' @param ids_col_name DEFAULT "id". The name of the column that contains the
#'   actual ids. This is usually "id" but can be specified differently here.
#' @param append_current_date_time,replace_prior_date_time DEFAULT TRUE FOR BOTH. if TRUE, the current
#'   date and time will be appended to the end of the file name. If the file
#'   replacing the current database, and you wish to overwrite the prior date
#'   and time, rather than just appending it to the end of the file name, then
#'   set replace_prior_date_time to true (DEFAULT). replace_prior_date_time =
#'   TRUE won't work if 'savePath' is specified however.
#' @param saveType Choices are NULL, "xlsx","csv". The file type to save as. If
#'   default (NULL) and a current_ids_key_db_path is provided, then the saved
#'   file type will take the type of current_ids_key_db_path. Otherwise, if left
#'   to default (NULL), saved file will be "csv". If "xls" will become "xlsx".
#' @param savePath,overwrite The path/file (i.e.
#'   ./input_ids_dir/new_input_ids_key.csv)name where to save the new or
#'   appended data base. If not specified, then it will default to saving at the
#'   same location as 'current_ids_key_db_path' but will append the current date
#'   and time. Or if current_ids_key_db_path is NULL, then will save a new
#'   database to a folder in the the working directory called
#'   './input_ids_keys/'. If you wish to have this behavior but not append the
#'   current date and time to the file name, then set overwrite to TRUE and
#'   savePath to NULL - and it will just replace the existing database with the
#'   new one but without the date and time. But be careful, this will
#'   effectively overwrite your current database. No guarantee that everything
#'   will be in tact.
#' @param archiveExisting,archiveWithCompression if TRUE (Default) the existing file at current_ids_key_db_path will be archived into a new folder called './zArchive_input_id_key. If archiveWithCompression (Default is TRUE) then the old file will be gzipped.
#' @param compress If TRUE, the written file will be compressed to a fileName.saveType.gz.
#'   writing, if false (default) will be written as a .csv.
#'
#' @importFrom magrittr %>%
#' @export


# current_ids_key_db_path = "~/Desktop/test1.xlsx"
# new_ids_vec = c(3:2000)
# new_library_input_name = "newNameTest3"
# overwrite_existing_input_name_col = FALSE
# ids_col_name = "id"
# append_current_date_time = TRUE
# replace_prior_date_time = TRUE
# saveType = NULL
# savePath = NULL
# overwrite = FALSE
# compress = TRUE
# archiveExisting = TRUE
# archiveWithCompression = TRUE
# write_to_disk = TRUE
#rm(list = ls())
#mmR::mm.R.restart()

# vs.add_new_library_to_input_ids_key_db(
#                                        current_ids_key_db_path = current_ids_key_db_path,
#                                        new_ids_vec = new_ids_vec,
#                                        new_library_input_name = new_library_input_name,
#                                        ids_col_name = ids_col_name,
#                                        replace_prior_date_time = replace_prior_date_time,
#                                        archiveExisting = archiveExisting,
#                                        archiveWithCompression = archiveWithCompression)


vs.add_new_library_to_input_ids_key_db <-
                               function(
                                 current_ids_key_db_path = NULL,
                                 new_ids_vec,
                                 new_library_input_name,
                                 overwrite_existing_input_name_col = FALSE,
                                 ids_col_name = "id",
                                 append_current_date_time = TRUE,
                                 replace_prior_date_time = TRUE,
                                 saveType = NULL,
                                 savePath = NULL,
                                 overwrite = FALSE,
                                 compress = TRUE,
                                 archiveExisting = FALSE,
                                 forceArchive = FALSE,
                                 archiveWithCompression = TRUE,
                                 write_to_disk = TRUE,
                                 ...){

  if(is.null(new_library_input_name)){
    stop("A name for the new input library must be provided. See ?vs.add_new_library_to_inputs_db for help and instructions on how this particular parameter should be named. In general it must be the same input_name that is in the inputsLibKey and the base of 'input_id' in virScanKey... see, vs.create_example_sampleMetaData()")
  }


  if(write_to_disk == TRUE){
    if(!is.null(savePath)){
      if(mmR::mm.fileType(savePath, requireFile = FALSE) == "directory"){
        stop("savePath specifies a directory. Please finish the directory by adding the 'filename.csv' as well")
      }
      if(file.exists(savePath) & overwrite == FALSE & append_current_date_time == FALSE){
        stop("savePath is specified but the file at that location already exists. To overwrite that file, set overwrite = TRUE or set 'append_current_date_time = TRUE' to append the date/time to the file name, or provide a new savePath to create a new file")
      }
      
      if(!base::dir.exists(base::dirname(savePath))){
        stop("savePath attempts to create a new file in a nonexistent directory. Please check the savePath argument again and ensure that the full path leading up to the new name actually exists.")
      }
    }  
  }
  


  if(!is.null(current_ids_key_db_path) &
     is.null(savePath) &
     overwrite == FALSE &
     append_current_date_time == FALSE & 
     write_to_disk == TRUE){
    stop(paste0("File already exists and Overwrite = FALSE, append_current_date_time = FALSE, and savePath = NULL. To overwrite the current_ids_db at: ",get("current_ids_key_db_path"), ", set overwrite to TRUE. Else, if want to place in a new location, set to 'savePath', or set 'append_current_date_time = TRUE' to make a new file with date time as part of the file name and it will save to the same location but new name."))
  }




  if(!is.vector(new_ids_vec)){
    if(!"data.frame" %in% class(new_ids_vec)){
      stop("new_ids_vec must be suppled as a vector or a single column data frame")
    } else if("data.frame" %in% class(new_ids_vec)){
      if(ncol(new_ids_vec) != 1){
        stop("new_ids_vec must be suppled as a vector or a single column data frame")
      } else {
        names(new_ids_vec) <- "id"
        new_ids_vec <- new_ids_vec$id
      }
    }
  }



  newIDs <- dplyr::tbl_df(data.frame("id" = new_ids_vec))
  newIDs$tempName <- 1
  names(newIDs) <- c(get("ids_col_name"),get("new_library_input_name"))

  if(is.null(current_ids_key_db_path)){
    toReturn <- newIDs
  } else {
    
    
    #If the current_ids_key_db_path actually holds a data frame of ids... 
    if("data.frame" %in% class(current_ids_key_db_path)) {
      currentLibDB <- current_ids_key_db_path
      current_ids_key_db_path = NULL
    
      
    #Otherwise, read the current_ids_key_db_path  
    } else { 
      try(currentLibDB <- mmR::mm.fastread(current_ids_key_db_path,nrows = 1),
          silent = TRUE)
      
      if(class(.Last.value)[1] == "try-error"){
        print("DIDNT READ current_ids_key_db_path")
        stop(paste0("No file at ",get("current_ids_key_db_path")," found, or file not readable. Please ensure this is the location of the current database of ids, or set 'current_ids_key_db_path' parameter to NULL to start a new database."))
      }
      
      if(!ids_col_name %in% names(currentLibDB)){
        stop(paste0("current input id database read in at ",get("current_ids_key_db_path"), " does not contain an ids_col_name (i.e. 'id') column. The database must contain an 'id' column or 'ids_col_name' must be specified if using a different name than 'id'. Please check to ensure that 'current_ids_key_db_path' is pointing to the currect file, or specify 'ids_col_name' or, to create a new database, set 'current_ids_key_db_path = NULL'"))
      }
      
      if(new_library_input_name  %in% names(currentLibDB) & overwrite_existing_input_name_col == FALSE){
        stop(paste0("The supplied 'new_library_input_name' ('", get("new_library_input_name"),"') already exists as a column header in the current provided ids database. Perhaps this library has already been added? If not, please provide a unique library 'input_name' to serve as the header of the column or, if desiring to replace the current column that shares the same name, set 'overwrite_existing_input_name_col = TRUE'"))
      }
      
      #read in current database
      currentLibDB <- mmR::mm.fastread(current_ids_key_db_path)  
    }
    
    

    #if the ids (which they'll be joined by) are characters or factors,
    #make them both characters

      startNames1 <- names(newIDs)
      tempNames <- c("tempIDmjm123abczek0sa",startNames1[2])
      names(newIDs) <- tempNames

      startNames2 <- names(currentLibDB)
      indexToChange <- which(startNames2 == get("ids_col_name"))
      changeNames <- startNames2
      changeNames[indexToChange] <- "tempIDmjm123abczek0sf"
      names(currentLibDB) <- changeNames

      if(is.factor(newIDs$tempIDmjm123abczek0sa) |
         is.character(newIDs$tempIDmjm123abczek0sa) |
         is.factor(currentLibDB$tempIDmjm123abczek0sf) |
         is.character(currentLibDB$tempIDmjm123abczek0sf)){

        newIDs <- newIDs %>% dplyr::mutate(tempIDmjm123abczek0sa = as.character(tempIDmjm123abczek0sa))
        currentLibDB <-
          currentLibDB %>%
          dplyr::mutate(tempIDmjm123abczek0sf = as.character(tempIDmjm123abczek0sf))
      }
      names(newIDs) <- startNames1
      names(currentLibDB) <- startNames2



    #replace an existing input_name
    if(new_library_input_name %in% names(currentLibDB) & overwrite_existing_input_name_col == TRUE){
      originalCols <- names(currentLibDB)
      replaceIndex <- which(originalCols == new_library_input_name)
      currentLibDB <- currentLibDB[,-replaceIndex]
      currentLibDB <- currentLibDB %>% dplyr::full_join(newIDs, by = get("ids_col_name"))
      toReturn <- currentLibDB %>% dplyr::select(originalCols)
    } else {
      toReturn <- currentLibDB %>% dplyr::full_join(newIDs, by = get("ids_col_name"))
    }
  }

  if(write_to_disk == FALSE){
    return(toReturn)
  } else {
    #-----------------------------------------------------------------------------
    #-----------------------------------------------------------------------------
    #Section to determine how to save the data.
    #-----------------------------------------------------------------------------
    #-----------------------------------------------------------------------------


    if(!is.null(savePath) & replace_prior_date_time == FALSE){

      savePath = savePath

    } else if((is.null(savePath) &
              !is.null(current_ids_key_db_path)) |
              (!is.null(savePath) & replace_prior_date_time == TRUE)) {

      if(is.null(savePath)){
        savePath <- current_ids_key_db_path #<- "~/Desktop/test_190102_03_36.xls.gz"  
      } 
      

      if(replace_prior_date_time == TRUE){

        append_current_date_time = TRUE

        #attempt to identify the file type so we can remove it
        savePath_fileType <- mmR::mm.getFileExt(savePath)
        savePath_fileTypeNchars <- base::nchar(savePath_fileType)

        #In case it's a compressed file type, see if we can recognize the actual file type
        if(!savePath_fileType %in% c("csv","xls","xlsx")){
          savePathTemp <-
            mmR::mm.stringRightRemove(savePath,
                                      (savePath_fileTypeNchars + 1))
          savePathTemp_fileType <- mmR::mm.getFileExt(savePathTemp)

          if(savePathTemp_fileType %in% c("csv","xls","xlsx")){
            savePath <- savePathTemp
            savePath_fileType <- savePathTemp_fileType
            savePath_fileTypeNchars <- base::nchar(savePath_fileType)
          }
        }


        if(savePath_fileTypeNchars > 0){
          lr <- savePath_fileTypeNchars + 1
        } else {
          lr <- 0
        }

        #Check to see if it is the right format to remove the dat and time
        if(mmR::mm.stringRight(mmR::mm.stringRightRemove(savePath,2 + lr),1) == "_" &
           mmR::mm.stringRight(mmR::mm.stringRightRemove(savePath,5 + lr),1) == "_" &
           mmR::mm.stringRight(mmR::mm.stringRightRemove(savePath,8 + lr),1) == "_" &
           mmR::mm.stringRight(mmR::mm.stringRightRemove(savePath,15 + lr),1) == "_"){
          savePath <- paste0(mmR::mm.stringRightRemove(savePath,16+lr),".",savePath_fileType)
        } else if(
          mmR::mm.stringRight(mmR::mm.stringRightRemove(savePath,2 + lr),1) == "_" &
          mmR::mm.stringRight(mmR::mm.stringRightRemove(savePath,5 + lr),1) == "_" &
          mmR::mm.stringRight(mmR::mm.stringRightRemove(savePath,12 + lr),1) == "_") {
          savePath <- paste0(mmR::mm.stringRightRemove(savePath,13+lr),".",savePath_fileType)
        } else {
          warning("Did not remove prior date_time. Keeping ending in tact. Possible that file name did not end in a date_time. Must be in yymmdd_hh_mm_ss.xxx or yymmdd_hh_mm.xxx format. To prevent this warning, set 'replace_prior_date_time' to FALSE and append_current_date_time to TRUE if desired.")
        }
      }

    } else { #if both savePath and current_ids_key_db_path are both NULL

      if(!dir.exists("./input_ids_keys")){
        dir.create("./input_ids_keys")
        print("creating new directory: './input_ids_keys' in working directory for new input_ids_key file")
      }
      savePath <- file.path(".","input_ids_keys","input_ids_key.csv") #this will be appended with the date.time down below
    }

    #DONE FIGURING OUT savePath.
    #Now we have to figure out adding dates and extensions.



    if(append_current_date_time == TRUE){
      savePath_fileType <- mmR::mm.getFileExt(savePath)
      savePath_fileTypeNChars <- base::nchar(savePath_fileType)
      if(savePath_fileTypeNChars >0){
        lr <- savePath_fileTypeNChars+1
      } else {
        lr <- 0
        savePath_fileType <- "csv"
      }
      savePath_noExt <- mmR::mm.stringRightRemove(savePath,nChars = lr)
      savePath <- paste0(savePath_noExt,"_",format(Sys.time(), "%y%m%d_%H_%M_%S"),".",savePath_fileType)
    }


    #-----------------------------------------------------------------------------
    #Tidy up saveType in case it is not Null
    #-----------------------------------------------------------------------------
    #But first, need to ensure that saveType is not listed as NA
    suppressWarnings(
      try(
        if(is.na(saveType)) saveType = NULL,
        silent = TRUE
      )
    )


    if(is.null(saveType)){
      saveType <- mmR::mm.getFileExt(savePath)
      if(!saveType %in% c("csv","xls","xlsx")){
        saveType = "csv"
      }
    }


    if(saveType %in% c("xlsx","xls")){
      if(requireNamespace("writexl")==FALSE){
        saveType = "csv"
        warning("Saving a file as xlsx or xls requires 'writexl' package. Saving as .csv instead")
      } else {
        saveType = "xlsx"
      }
    } else {
      saveType = "csv"
    }



    savePath_fileType <- mmR::mm.getFileExt(savePath)
    if(saveType != savePath_fileType){
      if(savePath_fileType %in% c("csv","xls","xlsx")){
        savePath_fileTypeNChars <- base::nchar(savePath_fileType)
        lr <- savePath_fileTypeNChars+1

        savePath_noExt <- mmR::mm.stringRightRemove(savePath,nChars = lr)
        savePath <- paste0(savePath_noExt,".",saveType)
      } else {
        savePath <- paste0(savePath,".",saveType)
      }
    }



    #-----------------------------------------------------------------------------
    #Make sure it's a unique name.
    #-----------------------------------------------------------------------------

    if(overwrite == FALSE){
      savePath <- mmR::mm.update_filename_if_existing(savePath)
    }

    #-----------------------------------------------------------------------------
    #Write the file
    #-----------------------------------------------------------------------------
    #will write either csv or xlsx
    mmR::mm.fastwrite(data = toReturn,
                      path = savePath,
                      overwrite = overwrite,
                      keep_uncompressed = FALSE,
                      show_progress = TRUE,
                      compress = compress)
  
  print(sprintf("New input library key written to %s",base::normalizePath(savePath)))
  on.exit(return(base::normalizePath(savePath)))
    





    if(!is.null(current_ids_key_db_path)){
      if(!is.null(savePath)){
        if(base::dirname(current_ids_key_db_path) !=
           base::dirname(savePath)){
          if(forceArchive == FALSE){
            if(archiveExisting == TRUE){
              archiveExisting = FALSE
              warning("savePath points to a different directory than current_ids_key_db_path. Therefore, not archiving original database. If archiving is desired even though savePath is a different location, set forceArchive to TRUE.")
            }
          }
        }
      }
    }


    if(archiveExisting){
      if(requireNamespace("fs",quietly = TRUE)==FALSE){
        warning("Unable to archive or delete existing db. Please install package 'fs' to use this functionality")
      } else {
        existingDir <- 
          try(fs::path_dir(current_ids_key_db_path),silent = TRUE)
        
        if(class(.Last.value)[1] != "try-error"){
          zArchive <- base::file.path(existingDir,"zArchive_ids_key_db")
          if(!dir.exists(zArchive)){
            base::dir.create(zArchive)
          }
          if(archiveWithCompression){
            try(R.utils::gzip(current_ids_key_db_path),silent = TRUE)
            if(class(.Last.value)[1] == "try-error"){
              print("could not gzip file using R.utils::gzip(). Archiving without compression")
            } else {
              current_ids_key_db_path <- paste0(current_ids_key_db_path,".gz")
            }
          }
          if(requireNamespace("fs")){
            try(fs::file_move(path = current_ids_key_db_path,new_path = zArchive),silent = TRUE)  
          } else {
            warning("Unable to move original file to archive. Requires pkg 'fs'")
          }  
        }
      }
    } #end archiving
  }
}


#' Function to create a template input_ids_key database. 
#' 
#' This is useful for tracking which epitope ids are in each data base and, later,for capturing specific epitope ids easily for analysis - for example a specific library or a specific virus. Can update the output files using vs.add_new_library_to_input_ids_key_db().
#' @export
vs.create_example_input_ids_key_db <- function(path = "."){
  
  if(dir.exists(path)){
    path <- file.path(path,"input_ids_key")
  } else {
    path = "./input_ids_key"  
  }
  
  
  if(dir.exists(path)){
    path = path
  } else {
    dir.create(path)
  }
  
  savePath <- file.path(path,"input_id_key.csv")
  
  mmR::mm.quiet(
    a1<-vs.add_new_library_to_input_ids_key_db(
      current_ids_key_db_path = NULL,
      new_library_input_name = "myLibraryName_v1", 
      new_ids_vec = c(1:100),
      append_current_date_time = TRUE,
      replace_prior_date_time = FALSE,
      saveType = "csv",
      overwrite_existing_input_name_col = FALSE,
      ids_col_name = "id",
      savePath = savePath,
      compress = FALSE,
      archiveWithCompression = TRUE,
      write_to_disk = TRUE))
  
  Sys.sleep(time = 1.1)
  
  mmR::mm.quiet(
    a2<- vs.add_new_library_to_input_ids_key_db(
      current_ids_key_db_path = a1,
      savePath = NULL,
      new_ids_vec = c(10:35,55:85,90:110, 
                      paste0(LETTERS[1:26],1:26)),
      new_library_input_name = "myLibraryName_v2", 
      ids_col_name = "id",
      append_current_date_time = TRUE,
      replace_prior_date_time = TRUE,
      overwrite = FALSE,
      compress = FALSE, 
      saveType = "csv", 
      archiveExisting = TRUE,
      archiveWithCompression = TRUE,
      write_to_disk = TRUE))
  
  Sys.sleep(time = 1.1)
  
  mmR::mm.quiet(
    a3<-vs.add_new_library_to_input_ids_key_db(
      current_ids_key_db_path = a2,
      savePath = NULL,
      new_ids_vec = c(1:110,200:400),
      new_library_input_name = "myLibraryName_v3", 
      ids_col_name = "id",
      append_current_date_time = TRUE,
      overwrite = FALSE,
      compress = FALSE,
      archiveExisting = TRUE,
      archiveWithCompression = TRUE,
      replace_prior_date_time = TRUE,
      saveType = "csv"))
  
  print("Created Example directory of input_ids_key databases in the working directory. NEXT: Use vs.add_new_library_to_input_ids_key_db() to add new libraries to this.")
  
  return(a3)
  
}







vs.add_new_libraries_to_input_ids_key_db <- function(
                                current_ids_key_db_path = NULL,
                                new_ids_vec_list,
                                new_library_input_names,
                                overwrite_existing_input_name_col = FALSE,
                                ids_col_name = "id",
                                append_current_date_time = TRUE,
                                replace_prior_date_time = TRUE,
                                saveType = NULL,
                                savePath = NULL,
                                overwrite = FALSE,
                                compress = FALSE,
                                archiveExisting = TRUE,
                                forceArchive = FALSE,
                                archiveWithCompression = TRUE,
                                write_to_disk = TRUE,
                                ...){
  
  
  
  if(class(new_ids_vec_list)[1] != "list"){
    new_ids_vec_list <- list(new_ids_vec_list)
  }
  
  if(length(new_ids_vec_list) != length(new_library_input_names)){
    stop("new_ids_vec_list must have the same number of list elements as new_library_input_names")
  }
  
  
  
  
  
  if(is.null(savePath)){
    savePath <- current_ids_key_db_path
  }
    
  
  write_to_disk_original <- write_to_disk
  #i =3
  for(i in seq_along(new_ids_vec_list)){
    
    
    if(i < max(seq_along(new_ids_vec_list))){
      write_to_disk = FALSE
    } else { 
      write_to_disk = write_to_disk_original 
    }
    
    
    if(i >1){
      archiveExisting = FALSE
    }
    
    
    current_ids_key_db_path <- 
      vs.add_new_library_to_input_ids_key_db(
        current_ids_key_db_path = current_ids_key_db_path,
        new_ids_vec = new_ids_vec_list[[i]],
        new_library_input_name = new_library_input_names[[i]],
        overwrite_existing_input_name_col = overwrite_existing_input_name_col,
        ids_col_name = ids_col_name,
        append_current_date_time = append_current_date_time,
        replace_prior_date_time = replace_prior_date_time,
        saveType = saveType,
        savePath = savePath,
        overwrite = overwrite,
        compress = compress,
        archiveExisting = archiveExisting,
        forceArchive = forceArchive,
        archiveWithCompression = archiveWithCompression,
        write_to_disk = write_to_disk
      )  
  }
  
  return(current_ids_key_db_path)
}


