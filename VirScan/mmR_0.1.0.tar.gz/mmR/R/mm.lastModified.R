#' Function to get the time of last modification to a file.
#'
#' Function to provide either the mtime or the md5Sum hash. These are useful to
#' determine if a file has been modified since last use, for example if caching
#' results and you need to know if a file has been updated and thus rerun the
#' analysis.
#'
#' @param pathVec a path or vector of paths to files or folders to check on.
#' @param mtime,md5Sum if mtime is TRUE, the function will provide the last
#'   modified time of the file. If md5Sum is TRUE, the function will return the
#'   md5Sum Hash calculated for the file. This can take some time for large
#'   data, but provides an accurate estimate of whether two files are identical.
#'   Of note, neither consider changes to the file name. If neither are set to
#'   TRUE, the function will default to providing mtime. if both is TRUE, then
#'   both will be return as a list of mtimes and then md5Sums
#' @param both if set to TRUE, will provide both the mtime and the md5Sum as two
#'   elements, in that order.
#' @export

mm.lastModified <- function(pathVec, mtime = FALSE, md5Sum = FALSE, both = FALSE){
  if(mtime == FALSE & md5Sum == FALSE & both == FALSE){
    mtime = TRUE; md5Sum = FALSE; both = FALSE
  } else if(both == TRUE){
    mtime = TRUE; md5Sum = TRUE
  } else if(mtime == TRUE & md5Sum == TRUE){
    both = TRUE
  } 
  
  mttimes <- NULL
  md5sums <- NULL
  if(mtime == TRUE) mtimes <- base::file.info(pathVec)$mtime
  if(md5Sum == TRUE) md5sums <- tools::md5sum(pathVec)
    
  if(both){
      return(list(modified = mtimes,md5Sum = md5sums))    
  } else if(mtime){
    return(mtimes)
  } else if(md5Sum == TRUE){
    return(md5sums)
  } else {
    return(base::file.info(pathVec)$mtime)
  }
}