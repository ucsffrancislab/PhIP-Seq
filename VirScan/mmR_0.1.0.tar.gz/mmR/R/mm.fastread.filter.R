#------------------------------------------------------------------------------#
#mm.fastread
#------------------------------------------------------------------------------#
#' Read in and filter a .gz or .csv file (automatic detection of .gz vs. csv)
#'
#' \code{mm.fastread} This function uses \code{fread()} to read in a .gz or a .csv file. It
#' automatically detects whether the file is a .csv or a .gz file and reads it
#' in appropriately. To read in a .gz file, it uses fread("gunzip -c /path"))
#'
#' @family database connections
#'
#' @inheritParams mm.fastread
#'
#' @param filterByCol Column name that will be the column filtered on.
#'
#' @param filterKeep,filterDrop The values to keep or drop
#'
#' @param filterType How to evaluate filterKeep and filterDrop. Select one of
#'   "equal","lt","gt","lte","gte","character","pattern","string". The first 5
#'   will filter as ==, <,>,<=,>=.  If "character" will look for an exact match
#'   of the character or vector of characters that are included in filterKeep or
#'   filterDrop. If "pattern" will grep for that pattern - so can be a few
#'   letters within a word, for example. if "string" will look for an exact
#'   match of an entire string. Default is "equal"
#'
#' @return Returns the read in data
#''
#' @importFrom magrittr %>%
#' @export
mm.fastread.filter <- function(path,
                              table = NULL,
                              xl_sheet = 1,
                              header = TRUE,
                              nrows = NULL,
                              allRows = TRUE,
                              specificRows = NULL,
                              columns = NULL,
                              filterByCol = NULL,
                              filterKeep = NULL,
                              filterDrop = NULL,
                              filterType = "equal",#"lt","gt","lte","gte"  #"character","pattern","string",
                              preserveSpecificRowOrder = TRUE,
                              returnColsNotAvailable = FALSE,
                              type = NULL,...){





    if(is.null(filterByCol)){
      stop("Cannot perform filtering. filterByCol is NULL. Do you want to use mm.fastread() instead")
    }

    if(is.null(filterKeep) & is.null(filterDrop)){
      stop("Did not perform any filtering. filterKeep and filterDrop are both NULL. Do you want to use mm.fastread() instead")
    }


    if(!filterType %in% c("equal","lt","lte","gt","gte","character","string","pattern")){

      stop("Did not perform any filtering, filterType must be one of: equal, lt, lte, gt, gte, character, string, pattern")
    }


  temp <- mm.fastread(path = path,
                      table = table,
                      xl_sheet = xl_sheet,
                      header = header,
                      allRows = TRUE,
                      columns = filterByCol,
                      return_as.data.frame = TRUE,
                      type = NULL)




    temp$rowNum <- c(1:nrow(temp))

    if(!is.null(specificRows)){
      temp <- temp[temp$rowNum[temp$rowNum %in% specificRows],]
    }

    #Coerce column type to match filter type
    if(filterType %in% c("equal","lt","gt","lte","gte")){

      temp[,1] <- as.numeric(temp[,1])

    } else if(filterType %in% c("character","string","pattern")) {

      temp[,1] <- as.character(temp[,1])

    }


    if(filterType %in% c("equal", "character","string")){

      if(!is.null(filterKeep)){
        temp <- temp[which(temp[,1] %in% filterKeep),]
      }

      if(!is.null(filterDrop)){
        temp <- temp[!which(temp[,1] %in% filterDrop),]
      }
    }



    if(filterType == c("lt")){

      if(!is.null(filterKeep)){
        temp <- temp[which(temp[,1] < min(filterKeep)),]
      }

      if(!is.null(filterDrop)){
        temp <- temp[!which(temp[,1] < min(filterDrop)),]
      }
    }




    if(filterType == c("lte")){

      if(!is.null(filterKeep)){
        temp <- temp[which(temp[,1] <= min(filterKeep)),]
      }

      if(!is.null(filterDrop)){
        temp <- temp[!which(temp[,1] <= min(filterDrop)),]
      }
    }


    if(filterType == c("gt")){

      if(!is.null(filterKeep)){
        temp <- temp[which(temp[,1] > max(filterKeep)),]
      }

      if(!is.null(filterDrop)){
        temp <- temp[!which(temp[,1] > max(filterDrop)),]
      }
    }


    if(filterType == c("gte")){

      if(!is.null(filterKeep)){
        temp <- temp[which(temp[,1] >= max(filterKeep)),]
      }

      if(!is.null(filterDrop)){
        temp <- temp[!which(temp[,1] >= max(filterDrop)),]
      }
    }



    if(filterType == "pattern"){


      if(!is.null(filterKeep)){


        rowsKeep <- (grep(paste(filterKeep,collapse="|"),
                                temp[,1], value=FALSE))

        temp <- temp[rowsKeep,]
      }


      if(!is.null(filterDrop)){


        rowsKeep <- (grep(paste(filterDrop,collapse="|"),
                          temp[,1], value=FALSE))

        temp <- temp[-rowsKeep,]
      }
    }



    if(!is.null(nrows)){
      temp <- temp[nrows,]
    }


    rowsToKeep <- temp$rowNum



    return(
    mm.fastread(path = path,
                       table = table,
                       xl_sheet = xl_sheet,
                       header = header,
                       nrows = nrows,
                       allRows = allRows,
                       specificRows = rowsToKeep,
                       columns = columns,
                       type = NULL))


  }
