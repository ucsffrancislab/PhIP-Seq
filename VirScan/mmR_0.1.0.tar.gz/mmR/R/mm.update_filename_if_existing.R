#' Function to check if a file exists in a given directory and, if so, updates
#' the name sequentially or with current date_time to find a unique name.
#'
#' Function to check if a file exists in a given directory and, if so, updates
#' the name sequentially or with current date_time to find a unique name. Of
#' note, this will make every attempt to place the sequential numbering or the
#' date and time before the file extension and, if it's compressed, before the
#' true file type extension. For example, myFile_v1.csv.gz and not
#' myFile.csv_v1.gz. The returned object is the full file path of the new file
#' name and the potential directory it will live in, or, just the file name if
#' return_full_path = FALSE.
#'
#' @param file Full or relative path to the file or just the file name, in which
#'   case a directory should be supplied.
#' @param directory The directory to look in to see if the file name is unique.
#'   If NULL, then the function will assume that either the file is a full path
#'   and the path is the potential new directory, or will look in the current
#'   working directory if file represents only a file name without the full
#'   path.
#' @param type If use_data_time is FALSE, type is what will preface the value
#'   that is ticked up. For example, if type = "_v" (the Default), the results will be
#'   myFile_v1.csv, myFile_v2.csv,,,, until a unique name is found.
#' @param use_date_time if this is set to TRUE, will use the date and time to
#'   create a unique name
#' @param date_time_format The format for the date and time. DEFAULT is
#'   %y%m%d_%H_%M_%S (yymmdd_hh_mm_ss)
#' @param return_full_path if TRUE (DEFAULT) THE full (relative) path will be
#'   returned. if FALSE, just the name is returned
#' @export
mm.update_filename_if_existing <- function(file,
                                           directory = NULL,
                                           type = "_v",
                                           use_date_time = FALSE,
                                           date_time_format = "%y%m%d_%H_%M_%S",
                                           return_full_path = TRUE){
  
  fileName <- basename(file)
  if(is.null(directory)) directory <- base::dirname(file)
  path <- file.path(directory,fileName)

  compressed = FALSE
  versionTry <- path
  tick = 0

  savePath_fileType <- mmR::mm.getFileExt(path)

  if(savePath_fileType %in% c("gz","bz2","zip","gzip","tgz")){
    compressed = TRUE
    compressedType <- savePath_fileType
    savePath_fileTypeNChars <- base::nchar(savePath_fileType)
    path <- mmR::mm.stringRightRemove(path, savePath_fileTypeNChars + 1)
  }

  savePath_fileType <- mmR::mm.getFileExt(path)
  savePath_fileTypeNChars <- base::nchar(savePath_fileType)
  if(savePath_fileTypeNChars>0){
    lr <- savePath_fileTypeNChars+1  
  } else {
    lr <- 0
  }
  
  
  
  
  baseTry <- savePath_noExt <- mmR::mm.stringRightRemove(path,nChars = lr)

  if(use_date_time){
    while(file.exists(versionTry)){
      versionTry <- paste0(baseTry,"_",format(Sys.time(), date_time_format),".",savePath_fileType)
      if(compressed){versionTry <- paste0(versionTry,".",compressedType)}
    }
  }

  while(file.exists(versionTry)){
    tick <- tick + 1
    if(savePath_fileType == ""){
      versionTry <- paste0(baseTry,type,tick)
    }
    else{
      versionTry <- paste0(baseTry,type,tick,".",savePath_fileType)  
    }
    if(compressed){versionTry <- paste0(versionTry,".",compressedType)}
  }

  if(base::basename(versionTry) != fileName){
    print(sprintf("Potential filename updated to %s",base::basename(versionTry)))
  }
  if(return_full_path){
    return(versionTry)
  } else {
    return(base::basename(versionTry))
  }

}
