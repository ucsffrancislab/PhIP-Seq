#' A function to get the right most or ending characters of a string
#'
#' Same as \code{stringEnd}
#'
#' @param x A String to evaluate
#' @param n The number of characters to get from the end of the string
#'
#' @examples
#' stringLeft("hello123",2)
#' stringRight("hello123",2)
#' stringMiddle("hello123",2,5)
#' getStringChars("hello1234", n_left = 3)
#' getStringChars("hello1234", n_right = 3)
#' getStringChars("hello1234", n_left = 3)
#' getStringChars("hello1234", n1 = 2, n2 = 5)
#' getStringChars("hello1234", n_middle1 = 2, n_middle2 = 5)
#' getStringChars("hello1234", n_middle1 = 2, n_middle2 = 5, middle = TRUE)
#'
#' @export
mm.stringRight <- function(x, n){
  substr(x, nchar(x)-n+1, nchar(x))
}

#' A function to get the right most or ending characters of a string
#'
#' Same as \code{stringRight}
#'
#' @inheritParams mm.stringRight
#'
#' @examples
#' stringLeft("hello123",2)
#' stringRight("hello123",2)
#' stringMiddle("hello123",2,5)
#' getStringChars("hello1234", n_left = 3)
#' getStringChars("hello1234", n_right = 3)
#' getStringChars("hello1234", n_left = 3)
#' getStringChars("hello1234", n1 = 2, n2 = 5)
#' getStringChars("hello1234", n_middle1 = 2, n_middle2 = 5)
#' getStringChars("hello1234", n_middle1 = 2, n_middle2 = 5, middle = TRUE)
#'
#' @export
mm.stringEnd <- function(x, n){
  substr(x, nchar(x)-n+1, nchar(x))
}


#' A function to get the right most or ending characters of a string
#'
#' Same as \code{stringBegin}
#'
#' @param x A String to evaluate
#'
#' @param n The number of characters to get from the beginning of the string
#'
#' @examples
#' stringLeft("hello123",2)
#' stringRight("hello123",2)
#' stringMiddle("hello123",2,5)
#' getStringChars("hello1234", n_left = 3)
#' getStringChars("hello1234", n_right = 3)
#' getStringChars("hello1234", n_left = 3)
#' getStringChars("hello1234", n1 = 2, n2 = 5)
#' getStringChars("hello1234", n_middle1 = 2, n_middle2 = 5)
#' getStringChars("hello1234", n_middle1 = 2, n_middle2 = 5, middle = TRUE)
#'
#' @export
mm.stringLeft <- function(x, n){
  substr(x, 1, n)
}


#' A function to get the right most or ending characters of a string
#'
#' Same as \code{stringLeft}
#'
#' @inheritParams mm.stringLeft
#'
#' @examples
#' stringLeft("hello123",2)
#' stringRight("hello123",2)
#' stringMiddle("hello123",2,5)
#' getStringChars("hello1234", n_left = 3)
#' getStringChars("hello1234", n_right = 3)
#' getStringChars("hello1234", n_left = 3)
#' getStringChars("hello1234", n1 = 2, n2 = 5)
#' getStringChars("hello1234", n_middle1 = 2, n_middle2 = 5)
#' getStringChars("hello1234", n_middle1 = 2, n_middle2 = 5, middle = TRUE)
#'
#' @export
mm.stringBegin <- function(x, n){
  substr(x, 1, n)
}

#' A function to pull characters from the middle of a string

#' @param x A string to evaluate
#'
#' @param n1 the character position of the first character to pull
#'
#' @param n2 the character position of the last character to pull
#'
#' @examples
#' stringLeft("hello123",2)
#' stringRight("hello123",2)
#' stringMiddle("hello123",2,5)
#' getStringChars("hello1234", n_left = 3)
#' getStringChars("hello1234", n_right = 3)
#' getStringChars("hello1234", n_left = 3)
#' getStringChars("hello1234", n1 = 2, n2 = 5)
#' getStringChars("hello1234", n_middle1 = 2, n_middle2 = 5)
#' getStringChars("hello1234", n_middle1 = 2, n_middle2 = 5, middle = TRUE)
#'
#' @export
mm.stringMiddle <- function(x, n1, n2){
  substr(x, n1, n2)
}


#' A function to get some number of characters from the left,right or middle of
#' a strong
#'
#' @inheritParams mm.stringMiddle
#'
#' @param n_left The number of characters to get from the beginning of the string
#'
#' @param n_right The number of characters to get from the end of the string
#'
#' @param n1_middle The character position of the first character to pull
#'
#' @param n2_middle The character position of the last character to pull
#'
#' @examples
#' stringLeft("hello123",2)
#' stringRight("hello123",2)
#' stringMiddle("hello123",2,5)
#' getStringChars("hello1234", n_left = 3)
#' getStringChars("hello1234", n_right = 3)
#' getStringChars("hello1234", n_left = 3)
#' getStringChars("hello1234", n1 = 2, n2 = 5)
#' getStringChars("hello1234", n_middle1 = 2, n_middle2 = 5)
#' getStringChars("hello1234", n_middle1 = 2, n_middle2 = 5, middle = TRUE)
#'
#' @export
mm.getStringChars <- function(x,
                           n_left = NULL,
                           n_right = NULL,
                           n1_middle = NULL,
                           n2_middle = NULL,
                           n1 = NULL,
                           n2 = NULL
                           ){

  if(!is.null(n_left)){

    return(stringLeft(x, n_left))

  } else if(!is.null(n_right)){

    return(stringRight(x,n_right))

  } else {
    if(is.null(n1_middle) | is.null(n2_middle)){
      return(stringMiddle(x, n1, n2))
    } else {
      return(stringMiddle(x, n1_middle, n2_middle))
    }

  }
}


#' Removes last nChars (potentially a vector) from a string or vector of strings
#' If string is a vector and nChars is a single digit, then nChars will be removed from each element of the strings vector.
#' If string is a vector and nChars is a vector, they must be the same length the the respective number of characters will be removed from each element of the string vector.
#' If string is a single string and nChars is a vector, only the first element of nChars will be considered.
#' @param string The string or vector of strings to remove the last n characters
#'   from
#' @param nChars The number of characters to remove from the end.
#' @param rmExt if TRUE, will remove just the file extension (i.e.: .gz or
#'   .xlsx, etc.)
#' @export
mm.stringRightRemove <- function(string, nChars = NULL, rmExt = FALSE){
  if(rmExt == TRUE){

    #function to get the extension of a file.
    ext <- getFileExt.Int(string) #exists in mm.getFileExt file

    nCharsLeft <- base::nchar(string) - (base::nchar(ext)+1)
    return(mm.stringLeft(string,n = nCharsLeft))

  } else {
    nInit <- nchar(string)
    return(mm.stringLeft(string,nInit-nChars))
  }

}

#' Removes last nChars (potentially a vector) from a string or vector of strings
#' If string is a vector and nChars is a single digit, then nChars will be removed from each element of the strings vector.
#' If string is a vector and nChars is a vector, they must be the same length the the respective number of characters will be removed from each element of the string vector.
#' If string is a single string and nChars is a vector, only the first element of nChars will be considered.
#' @param string The string or vector of strings to remove the last n characters
#'   from
#' @param nChars The number of characters to remove from the end.
#' @export
mm.stringLeftRemove <- function(string, nChars = 3){
  nInit <- nchar(string)
  return(
    mm.stringRight(string,nInit-nChars)
  )
}




