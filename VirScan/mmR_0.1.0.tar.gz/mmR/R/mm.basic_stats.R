#--------------------------------------------------------------------#
# Calculate Geometric Mean
#--------------------------------------------------------------------#
#'Calculate the geometric mean of a vector.
#'
#' @description Calculates the geometric mean of a vector.
#' @family Random functions
#' @section statistical tools
#'
#' @param vectorToCalculate Vector over which to calculate the geometric mean.
#' @return Returns a double - the geometric mean.
#'
#' @examples
#'  x <- c(1:10)
#'  mean_geom(x)
#'  @export
mm.mean_geom = function(vectorToCalculate){
  a = vector[which(!is.na(vectorToCalculate))]
  b = prod(a)
  c = b^(1/length(a))
  return(c)
}
