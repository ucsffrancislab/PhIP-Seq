#' Returns Tables in a SQLite or XL database.
#'
#' Can accept a path to SQLite, xlsx, xls
#'
#' @param path Path to the database or, if a csv of csv.gz, the file
#'
#' @param type The type of database Will detect automatically if \code{NULL},
#'   the default.
#' @param recursive Should files in sub directories be included
#' @param full.names If pointing to a directory, full.names if set to True will
#'   provide the path and the name, rather than just the name.)
#'
#' @inheritParams mm.fastread
#'
#' @return Returns a vector of table names
#'
#' @export
mm.listTables <- function(path,
                          type = NULL,
                          pattern = NULL,
                          full.names = FALSE,
                          recursive = TRUE,
                          directoryForTempDir = NULL,
                          skipExcel_zip = FALSE,
                          allow_gz_bz2_unzip = FALSE,
                          force_gz_bz2_unzip = FALSE,
                          max_size_for_excel_zip = NULL,
                          ...){


  if(file_test(op = "-d",x = path)){
    return(list.files(path, pattern = pattern, full.names = full.names, recursive = recursive))
  }

  
  #Check if file exists
  if(!file.exists(path)){
    stop("File to read does not exist")
  }
  

  if(
    mm.will_fastread(path = path, 
                     skipExcel_zip = skipExcel_zip, 
                     allow_gz_bz2_unzip = allow_gz_bz2_unzip,
                     force_gz_bz2_unzip = force_gz_bz2_unzip,
                     max_size_for_excel_zip = max_size_for_excel_zip,
                     cores = cores) == FALSE
  ){
    stop("file will not be read with current parameters")
  } 
  

  if(is.null(type)){
    type = mm.fileType(path)
  } else {
    type <- mm.convertUserInput_type.int(type)
  }


  #---------------------------------------------------------------------------#
  #IF type is c_xls or c_xlsx... can open a zip file... but only Zip
  #---------------------------------------------------------------------------#
  #make a temporary directory. Unzip the file to it. Treat it like a regular xls
  #file. On exit, delete that directory and the unzipped file.
  if(type == "c_excel" & !skipExcel_zip){
    if(force_gz_bz2_unzip == TRUE) allow_gz_bz2_unzip = TRUE

    ext <- mm.getFileExt(path)
    
    #make a temporary directory
    pathPath <- base::dirname(path)
    
    if(!is.null(directoryForTempDir)){
      if(base::dir.exists(directoryForTempDir)){
        pathPath <- directoryForTempDir
      }
    }
      
    fileName <- base::basename(path)
    randNamePath <- 
      file.path(
        pathPath,
        paste0("tempZipXL_",
               LETTERS[runif(n = 1,min = 1, max = 20)],
               round(runif(n = 1,min = 1e6, max = 9e6),digits = 0)))
    
    if(dir.exists(randNamePath) == FALSE){
      dir.create(randNamePath)
      on.exit(unlink(randNamePath, recursive = TRUE))
    }
      
    destName <- file.path(randNamePath,
                          mm.stringRightRemove(fileName,rmExt = TRUE))
    if(ext == "zip"){
      utils::unzip(zipfile = path,exdir = randNamePath)  
    } else if(ext == "gz"){
      R.utils::gunzip(filename = path,ext = "gz", remove = FALSE, destname = destName)
    } else if(ext == "bz2"){
      R.utils::bunzip2(filename = path,ext = "bz2",remove = FALSE, destname = destName)
    }

    pathOriginal <- path
    path <- destName
    type = mm.fileType(path)
        
  }
   
  #---------------------------------------------------------------------------#
  #IF type is xls or xlsx
  #---------------------------------------------------------------------------#
  if( type == "excel"){

    return(readxl::excel_sheets(path))

    #---------------------------------------------------------------------------#
    #IF type is csv or gz
    #---------------------------------------------------------------------------#
  } else if(type %in% c("csv","c_csv")){

      return(NA)

    #---------------------------------------------------------------------------#
    #IF TABLE TO READ is SQLite
    #---------------------------------------------------------------------------#
  } else if(type == "SQLite"){

    return(virScanRSQL::sql.listTables(path))

  } else {

    print("Sorry - the file type is not supported. only xls,xlsx, csv.gz, or xls.zip/xlsx.zip or SQLite are supported")

  }

}




