mm.convertUserInput_type.int <- function(type){

  excelTypes <- c("xls",".xls","xlsx",".xlsx",
                  "xlsm",".xlsm","xltx",".xltx","xltm",".xltm")

  csvTypes <- "csv"

  compressionTypes <- c("gz","bz","bz2","gzip","xz","zip")

  c_excelTypes <- c("c_excel")
  for(i in unique(c(1,seq_along(c_excelTypes)))){
    c_excelTypes <- unique(c(c_excelTypes,paste(excelTypes[i],compressionTypes,sep = ".")))
  }

  c_csvTypes <- c("c_csv")
  for(i in unique(c(1,seq_along(c_csvTypes)))){
    c_csvTypes <- unique(c(c_csvTypes,paste(csvTypes[i],compressionTypes,sep = ".")))
  }


  if(type %in% excelTypes) {
    return("excel")
  } else if (type %in% csvTypes) {
    return("csv")
  } else if (type %in% c_csvTypes) {
    return("c_csv")
  } else if(type %in% c_excelTypes) {
    return("c_excel")
  } else if(type %in% c("SQLite", "sqlite", "RSQLite", "rsqlite")) {
    return("SQLite")
  } else {
    warning("Unable to determine type. is not csv or excel or sqlite. Returning the supplied type.")
    return(type)
  }
}
