#------------------------------------------------------------------------------#
# mm.scan_for_strings
#------------------------------------------------------------------------------#
#' Function to scan a file or files in a directory for a string.
#'
#' @inheritParams mm.scan_for_strings.file
#' @inheritParams mm.scan_for_strings.directory
#' @export
mm.scan_for_strings <- function (path,
                                 string,
                                 value = FALSE,
                                 fileExt = NULL,
                                 escapeMetaChars = TRUE, ...) {


  path1 <- path
  if(utils::file_test("-d", path)) {
    class(path1) <- "directory"
    #append(class(path),"directory")
  } else if(utils::file_test("-f", path)) {
    base::class(path1) <- "file"
    #append(class(path),"file")
  } else {
    stop("path must lead to an existing file or directory.")
  }

  UseMethod("mm.scan_for_strings",path1)
}



#------------------------------------------------------------------------------#
# mm.scan_for_strings.file
#------------------------------------------------------------------------------#
#' Scan a file for a string
#'
#' @family package development
#'
#' @param path The path to the file or directory to search in.
#'
#' @param string The string to look for.
#'
#' @param value FALSE (default) to return just the line number, TRUE to return a
#'   data frame with the line number and the text on that line.
#'
#' @param escapeMetaChars Should metacharacters be 'escaped' out of string to
#'   search for. See \code{\link{mm.escape_meta_chars}}
#'
#' @return Returns a data.frame of the string and the line w/wout context.
#'
#' @examples
#' \dontrun{
#' mm.scan_for_strings.file(code_file = "myRcode.R", string = "myString",value =
#' TRUE)
#' }
#'
#' @export
mm.scan_for_strings.file <- function(path,
                                     string,
                                     value = FALSE,
                                     escapeMetaChars = TRUE, ...) {

  #Remove meta characters
  if(escapeMetaChars){ string <- mm.escape_meta_chars(string) }



  if(!value){

    return(data.frame(lineNum = grep(string, readLines(path),value = FALSE)))

  } else {

    return(
      data.frame(lineNum = grep(string, readLines(path),value = FALSE),
               context = grep(string, readLines(path),value = TRUE))
    )

  }
}




#------------------------------------------------------------------------------#
# mm.scan_for_strings.directory
#------------------------------------------------------------------------------#
#' Scan all text files in a directory for a string.
#'
#'
#' @family package development
#' @inheritParams mm.scan_for_strings.file
#'
#' @param fileExt The file extenstion to look for when grabbing files to search.
#'
#' @return Returns a data.frame of the fileName, and the row and context if
#'   Value is TRUE.
#'
#' @examples
#' \dontrun{
#' mm.scan_for_strings.directory(path_to_folder = "./R_code_folder")
#' }
#' @export
mm.scan_for_strings.directory <- function(path,
                                          string,
                                          value = FALSE,
                                          fileExt = NULL,
                                          escapeMetaChars = TRUE, ...){


  allFiles <- list.files(path = path, pattern = fileExt)

  if(length(allFiles) == 0) {

    stop(sprintf("No Files in this directory with file extension %s",fileExt))
  }

  stringList <- list()
  i=1
  for(i in 1:length(allFiles)){

    path1 <- file.path(path,allFiles[i])

    stringList[[i]] <-
      mm.scan_for_strings.file(path = path1,
                               string = string,
                               value = value,
                               escapeMetaChars = escapeMetaChars)

    if(nrow(stringList[[i]])>0){
      stringList[[i]]$file = allFiles[i]
    }
  }
  if(value == TRUE){
    return(dplyr::bind_rows(stringList) %>% select(lineNum,file,context))
  } else {
    return(dplyr::bind_rows(stringList))
  }
}
