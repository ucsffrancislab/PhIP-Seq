#' Evalaute quietly - i.e. suppress printing to console. 
#' 
#' Placing a call to a function inside removes printing to console. 
#' NOTE: use with caution - have not determined if side effects. 
#' @param quiet set to FALSE if don't want it to return quietly. Default is
#'   TRUE.
#' @export
#' 
mm.quiet <- function(f, quiet = TRUE) { 
  if(quiet != TRUE){
    return(f)
  } else {
    sink(tempfile()) 
    on.exit(sink()) 
    invisible(force(f))   
  }
}
