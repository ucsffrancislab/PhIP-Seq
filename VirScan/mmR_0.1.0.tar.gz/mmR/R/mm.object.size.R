#' Function to get an objects size in specific units.
#'
#' @param object The object to get the unit size for.
#' @param units What unit to get (“auto” (DEFAULT) “B”, “kB”, “MB”, “GB”, “TB”, “PB”, “EB”, “ZB”, “YB”, “KiB”, “MiB”, “GiB”, “TiB”, “PiB”, “EiB”, “ZiB”, “YiB”, “b”, “Kb”, “Mb”, “Gb”, “Tb”, “Pb”, “KB”).
#' @param digits WHat digits to round to.
#' @param trueSize Should the actual memory allocation be shown (comes from lobstr package) versus base::object.size
#' @return retuns object size.
#' @export
mm.object.size <- function(object,units = "auto", digits = 2, trueSize = TRUE){
  if(trueSize==TRUE){
    if(requireNamespace("lobstr") ==TRUE){
      return(lobstr::obj_sizes(object))
    }
  } else {
    return(format(object.size(object), units = units, digits = digits))
  }
}

