#------------------------------------------------------------------------------#
# mm.scan_for_functions
#------------------------------------------------------------------------------#
#' Search and list all functions in another function or in a: string,
#' file, or directory
#'
#' @inheritParams mm.scan_for_functions.directory
#' @inheritParams mm.scan_for_functions.character
#' @inheritParams mm.scan_for_functions.function
#' @inheritParams mm.scan_for_functions.file
#'
#' @export
mm.scan_for_functions <- function(x,
                                  fileExt = NULL,
                                  organize = FALSE, ...) {
  x1 <- x

  if(is.character(x)){

    if(file_test("-d", x)) {
      class(x1) <- "directory"
      #append(class(path),"directory")
    } else if(file_test("-f", x)) {
      class(x1) <- "file"
      #append(class(path),"file")
    } else {NULL}

  }


  UseMethod("mm.scan_for_functions",x1)

}




#' Scan a .R file for all functions and what functions use them
#'
#' \code{mm.scan_for_functions} The functions come from dracodoc / mischelper
#' https://github.com/dracodoc/mischelper/blob/master/R/misc.R
#'
#' @family package development
#'
#' @param x Where to search for any functions, this can be a function object, a
#'   path to a file, a path to directory, or just a string to search in
#'
#' @param organize If it should be organized as a table
#'
#' @return Returns a data.table of the function names and usage.
#'
#' @examples
#' \dontrun{
#' mm.scan_all_functions(code_file = "myRcode.R", organize = TRUE)
#' }
#'
#' @export
mm.scan_for_functions.file <- function(x, organize = FALSE) {


  source(x, local = TRUE, chdir = TRUE)

  names_in_fun <- ls(sorted = FALSE)

  funs_in_each_name <- lapply(names_in_fun, function(f_name) {
    obj <- get(f_name, parent.env(environment()))
    if (is.function(obj)) {
      data.frame(fun = f_name,
                 fun_inside = codetools::findGlobals(
                   obj, merge = FALSE)$functions)
    }
  })
  res <- data.table::rbindlist(funs_in_each_name)
  if (organize) {
    organize_fun_table(dt = res)
  } else {
    res
  }
}



#------------------------------------------------------------------------------#
# mm.scan_for_functions_in_string
#------------------------------------------------------------------------------#
#' Scan a code string for all functions and what functions use them.
#'
#' Helpful for figuring out which packages a new package depends on.The
#' functions come from dracodoc / mischelper
#' \link{https://github.com/dracodoc/mischelper/blob/master/R/misc.R}
#'
#' @family package development
#'
#' @param x String: The R code (or variable representing the text or
#'   code string) to check for functions used.
#'
#' @return Returns a data.table of the function names in the quoted and supplied
#'   string
#'
#' @examples
#' a <- "data.frame(X = 1:10, y = 2:11) %>% arrange(x)"
#' mm.scan_for_functions_in_string(a)
#'
#' @export
mm.scan_for_functions.character <- function(x, ...) {


  temp_fun <- eval(parse(text = paste0("function() {\n", x, "\n}")))
  organize_fun_table(data.frame(fun = "code_string (supplied)",
                                fun_inside = codetools::findGlobals(
                                  temp_fun, merge = FALSE)$functions))
}



#' Scan Function Object For External Functions
#'
#' @param x Function object
#'
#' @return result table
#'
#' @export
mm.scan_for_functions.function <- function(x, ...) {
  # function parameter lost its name so have to use generic name

    organize_fun_table(data.frame(fun = "",
                                fun_inside = codetools::findGlobals(
                                  x, merge = FALSE)$functions))
}





#------------------------------------------------------------------------------#
# mm.scan_for_functions
#------------------------------------------------------------------------------#
#' Scan all .R  files in a folder for all functions and what functions use them
#'
#' Note:\code{mm.scan_for_functions_all_files} The functions come from dracodoc
#' / mischelper https://github.com/dracodoc/mischelper/blob/master/R/misc.R
#'
#' @family package development
#'
#' @param x The path to the file or folder containing the R files
#'   (no ending "/")
#'
#' @return Returns a data.frame of the function names and usage.
#'
#' @examples
#' \dontrun{
#' mm.scan_for_functions_all_files(path_to_folder = "./R_code_folder")
#' }
#' @export
mm.scan_for_functions.directory <- function(x, fileExt = NULL,...){


  allFiles <- list.files(x, pattern = fileExt)

  funList <- list()
  i=1
  for(i in 1:length(allFiles)){
    path <- file.path(x,allFiles[i])
    funList[[i]] <- mm.scan_for_functions.file(x=path)
  }

  return(
    organize_fun_table(
      dt = as.data.frame(
        data.table::rbindlist(funList))))
}



#Internal Function
organize_fun_table <- function(dt, ...) {

  new_dt <- dt[!(dt$fun_inside %in% dt$fun),]
  new_dt1 <- unique(new_dt)
  new_dt2 <- data.frame(fun_inside = new_dt1$fun_inside,
                        fun = new_dt1$fun)
  new_dt3 <- new_dt2[order(new_dt2$fun_inside),]
  return(new_dt3)
}















