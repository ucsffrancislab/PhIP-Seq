#' Function to easily sort by a column
#'
#' @importFrom magrittr %>%
#'
#' @export
mm.sort_by_col <- function(data, ...){
  data %>%
    dplyr::arrange_(.dots = lazyeval::lazy_dots(...))
}
