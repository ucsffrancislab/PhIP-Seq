#' Returns broad file type or the extension
#'
#' Returns either 'excel' 'csv', 'c_csv' (i.e. compressed CSV if gz,bz2,xz),
#' 'SQLite' or returns the file extension itself
#'
#' @param path Path or vector of paths to the file ending with the full file name including the
#'   extension after the "."
#'
#' @param returnExtension FALSE (DEFAULT) returns the broad categories including
#'   'excel', 'csv','c_csv (for compressed files if gz,bz2,xz), "SQLite". If
#'   TRUE, returns just the file extension as determined by the last letters
#'   after the last '.' in path.
#'
#' @param requireFile TRUE if it requires that the file actually exists. FALSE
#'   if just inserting a file path that may not lead to an actual file on the
#'   machine.
#' @inheritParams mm.getFileExt
#' @example
#' mm.fileType(file.path("my","file.csv"), requireFile = FALSE)
#' mm.fileType(file.path("my","file.bz2"), requireFile = FALSE)
#' mm.fileType(file.path("my","file.xlsx"), requireFile = FALSE)
#' mm.fileType(file.path("my","file.xlsx"), returnExtension = TRUE,requireFile = FALSE)
#' @export
mm.fileType <- function(path,
                        returnExtension = FALSE,
                        ifCompressedReturnBoth = FALSE,
                        otherCompressedExt = NULL,
                        requireFile = TRUE){
  
  typeVector <- vector()
  for(i in seq_along(path)){
    typeVector[i] <- 
      mm.fileType_oneFile(path = path[i],
                          returnExtension = returnExtension,
                          ifCompressedReturnBoth = ifCompressedReturnBoth,
                          otherCompressedExt = otherCompressedExt,
                          requireFile = requireFile)
  }
  return(typeVector)
}




#' just a single file
mm.fileType_oneFile <- function(path,
                        returnExtension = FALSE,
                        ifCompressedReturnBoth = FALSE,
                        otherCompressedExt = NULL,
                        requireFile = TRUE){

  continueOn <- TRUE

  if(file_test(op = "-d",x = path)){
    return("directory")
  }


  path1 <- path.expand(path)
  if(requireFile){
    if (!file.exists(path1)) {
      stop("No file at the path exists. Change the path, or set 'requireFile' to FALSE")
    }
  }


  if(returnExtension == TRUE){
    return(mm.getFileExt(path1,
                         ifCompressedReturnBoth = ifCompressedReturnBoth,
                         otherCompressedExt = otherCompressedExt))
  }


  #----------------------------------------------------------------------------#
  #CHECK IF SQLite
  #----------------------------------------------------------------------------#
  if(file.exists(path1)){
    stringToUse <- paste0("head -c 16 '", path1, "'")
    a <- capture.output(cat(system(stringToUse, intern = TRUE),
                            sep = "\n"), file = NULL)

    if (TRUE %in% grepl("SQLite", a)) {
      return("SQLite")
    }
  } else if(requireFile == TRUE){
      stop("File does not exist and requireFile is set to TRUE. To get fileType for a file that does not exist (i.e. based on file extension), set requireFile to FALSE")
  }


  #----------------------------------------------------------------------------#
  #Check if XL from signature - only if readxl package exists.
  #----------------------------------------------------------------------------#
  if(mm.isCompressed(path1) == FALSE){

    if(file.exists(path1)){
      try(
        if("readxl" %in% data.frame(installed.packages())$Package){
          if(!is.na(readxl::format_from_signature(path1))){
            return("excel")
          }
        }
        ,silent = TRUE)
    }


    ext <- mm.getFileExt(path1)

    if(ext %in% c("xls","xlsx","xlsm","xltx","xltm")){
      return("excel")
    } else if(ext %in% c("csv")) {
      return("csv")
    } else {
      print("File does not appear to be sqlite, excel,csv,compressed csv, compressed xlsx")
      print("Returning file extension")
      return(ext)
    }

  } else { #if it is compressed
    ext2 <- mm.getFileExt(mm.stringRightRemove(path1,rmExt = TRUE))
    if(ext2 == "csv"){
      return("c_csv")
    } else if(ext2 %in% c("xls","xlsm","xlsx","xltx","xltm")){
      return("c_excel")
    } else {
      print("File is compressed but does not appear to be csv, xls or xlsx, returning first and second file extension")
      return(mm.getFileExt(path1,ifCompressedReturnBoth = TRUE,otherCompressedExt = otherCompressedExt))
    }
  }

}






