#' Remove meta characters from a string
#'
#' Certain characters in R are metacharacters and have special meaning when they
#' are in the middle of a quoted string.  however, sometimes you want them to be
#' just regular characters in your string - such as when you are trying to use
#' grep and look for a string with an opening bracket in it. This function
#' 'escapes' the metacharacters by placing double backslashes before any
#' metacharacters detected in the string.
#'
#' Note: this function was originally in HMISC package
#'
#' @param string String to escape metacharacters
#'
#' @example
#' mm.escape_meta_chars("min(")
#' mm.escape_meta_chars("myDF[")
#'
#' @export
mm.escape_meta_chars <- function(string){
  gsub("([.|()\\^{}+$*?]|\\[|\\])", "\\\\\\1", string)
}
