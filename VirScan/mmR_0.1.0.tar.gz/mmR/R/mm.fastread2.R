#------------------------------------------------------------------------------#
#mm.fastread2
#------------------------------------------------------------------------------#
#' Read in data with automatic very fast searching for data IN AND ACROSS
#' databases, including full directories and any subdirectories. Must add
#' desired data as a vector to 'columns' parameters.
#'
#' @inheritParams mm.fastread,mm.findData
#' @param search,includeSubDirectories If TRUE (Default) a search will be
#'   conducted for the data specified in 'columns'. If \code{path} is a
#'   directory, the search will look through all column names of all csv files,
#'   excel files and their tables, SQL tables and compressed csv files in the
#'   directory (+/- subdirectories; see below). If path goes to a database, it
#'   will search only the tables in that data base This uses
#'   \code{\link{mmR::mm.findData}}. The tables or databases searched through
#'   can be specified or limited by including a vector of table names to
#'   \code{table} parameter. If includeSubDirectories is TRUE (Default) then the
#'   search will keep looking through all subdirectories.
#' @param combineAll If TRUE, will attempt to bind the data by columns. Requires
#'   that the data that is found all comes from data frames with the same number
#'   of rows = unless keyColumn is specified - in which case it will do a
#'   full_join using keyColumn.
#' @param keyColumn If \code{combineAll = TRUE}, keyColumn will be the key for
#'   joining the data using a full_join. This should be a single column name
#'   that is present in all of the datasets being explored. If it can't find
#'   keyColumn column in each of the datasets in which it finds data, it will
#'   return every thing as a list.
#'
#' @param returnDataWithNoKeyCol,returnColNamesWithNoKeyCol If True, if keyColumn is not specified (i.e. set to NULL), then any data that is found but in a dataset without a keyColumn will be returned as an element of a list, with the number of elements equal to the number of keyColumn-less data tables in which data was found. This all will be returned in addition to table data with the keyColumns. if returnColNamesWithNoKeyCol is set to TRUE, will separately return a vector of columns that were found but found in databases without the keyColumn.
#'   
#' @param quiet Should printing to the console be suppressed. Default FALSE.
#' 
# Import package operators
#' @importFrom magrittr "%>%" "%<>%"
#' @importFrom data.table ":=" "%like%" "%between%"
#' 
# Make sure data.table knows we know we're using it
.datatable.aware = TRUE
#' 
#' 
#' @export
mm.fastread2 <- function(path,
                        table = NULL,
                        xl_sheet = 1,
                        columns = NULL,
                        header = TRUE,
                        nrows = NULL,
                        allRows = TRUE,
                        specificRows = NULL,
                        preserveSpecificRowOrder = TRUE,
                        returnColsNotAvailable = FALSE,
                        returnAs = "data_frame",
                        col_type = NULL,
                        col_type_n_guess = 10000,
                        search = TRUE,
                        includeSubDirectories = TRUE,
                        returnOnlyFirstInstance = FALSE,
                        combineAll = FALSE,
                        keyColumn = NULL,
                        returnDataWithNoKeyCol = FALSE,
                        returnColNamesWithNoKeyCol = TRUE,
                        type = NULL,
                        skipExcel_zip = FALSE,
                        allow_gz_bz2_unzip = TRUE,
                        force_gz_bz2_unzip = FALSE,
                        directoryForTempDir = NULL,
                        max_size_for_excel_zip = 300,
                        quiet = FALSE,
                        printFilesNotRead = FALSE,
                        cores = parallel::detectCores()-1,
                        ...){
  

  # path
  # table = NULL
  # xl_sheet = 1
  # columns = NULL
  # header = TRUE
  # nrows = NULL
  # allRows = TRUE
  # specificRows = NULL
  # preserveSpecificRowOrder = TRUE
  # returnColsNotAvailable = FALSE
  # returnAs = "data_frame"
  # col_type = NULL
  # col_type_n_guess = 10000
  # search = TRUE
  # includeSubDirectories = TRUE
  # returnOnlyFirstInstance = TRUE
  # combineAll = FALSE
  # keyColumn = NULL
  # returnDataWithNoKeyCol = TRUE
  # type = NULL
  # skipExcel_zip = FALSE
  # allow_gz_bz2_unzip = TRUE
  # force_gz_bz2_unzip = FALSE
  # directoryForTempDir = NULL
  # max_size_for_excel_zip = 100
  # quiet = FALSE
  # cores = parallel::detectCores()-1
  # printFilesNotRead = FALSE


  if(search == TRUE){
    
    noKeyColProvided = FALSE
    if(is.null(keyColumn) | keyColumn == FALSE | is.na(keyColumn)){
      noKeyColProvided = TRUE
      keyColumn <- paste0(runif(1,1e7,9e7),LETTERS[runif(1,1,26)])
    }
    
    if(noKeyColProvided & returnDataWithNoKeyCol == FALSE){
      stop("no keyColumn is provided and returnDataWithNoKeyCol is set to FALSE. No data to return. Did you mean to set search == FALSE? Otherwise, provide a keyColumn or set returnDataWithNoKeyCol to TRUE")
    }
    
    
    columnsOrig <- columns
    columns <- unique(c(keyColumn,columns))
    
    #columns <-unique( c(columns,"hihihi","mjm.10.A1","mjm.10.A2","poop"))
    #Consider parallelizating mm.findData
    toRead <- mm.findData(path = path,
                colsToFind = columns,
                tablesToLookIn = table,
                includeSubDirectories = includeSubDirectories,
                returnOnlyFirst = FALSE,
                splitToList = FALSE,
                skipExcel_zip = skipExcel_zip,
                directoryForTempDir = directoryForTempDir,
                allow_gz_bz2_unzip = allow_gz_bz2_unzip,
                force_gz_bz2_unzip = force_gz_bz2_unzip,
                max_size_for_excel_zip = max_size_for_excel_zip,
                cores = cores)
    
    noKeyColProvided = FALSE
    if(is.null(keyColumn) | keyColumn == FALSE | is.na(keyColumn)){
      noKeyColProvided = TRUE
      keyColumn <- paste0(runif(1,1e7,9e7),LETTERS[runif(1,1,26)])
    }
    
    
    if(returnOnlyFirstInstance){
      toRead$found <- 
        toRead$found %>% 
        dplyr::filter(colName == keyColumn | countcum ==1) 
    }
    
    #if keycolumn is the only column found in the data set... remove it.
    # 
    if(!is.null(keyColumn)){
      if(!keyColumn %in% columnsOrig){
        toRead$found <- 
          toRead$found %>%
          dplyr::group_by(file,table) %>%
          dplyr::mutate(count2 = 1, count2 = sum(count2)) %>%
          dplyr::filter(!((count2 == 1 & colName == "id"))) %>%
          dplyr::ungroup() %>%
          dplyr::select(-count2)
      }
    }
    
    toRead$found <-
      toRead$found %>%
      dplyr::select(-countcum) %>%
      unique() 
      
    dataUnableToRead <- vector()
    
    if(printFilesNotRead == TRUE){
      print(sprintf("Some files were not read: %s",toRead$files_not_read))
      dataUnableToRead <- toRead$files_not_read
      toRead$files_not_read <- NULL
    } else {
      toRead$files_not_read <- NULL
    }
    

    readList <- mm.split_to_list(toRead$found, by = c("file","table"))
    toReadList_noKey <- list()
    toReadList <- list()
    
    #Remove any list elements that don't have keyColumn
    #... but only if returnDataWithNoKeyCol is set to FALSE by user.
    
    noKeyColumnAvailable <- vector()
    noKeyColAvailableIndex <- vector()
    keyColAvailableIndex <- vector()
    keyColumnAvailable <- vector()
    z=0;p=0
    for(i in seq_along(readList)){
      if(!keyColumn %in% readList[[i]]$colName){
        noKeyColumnAvailable <- unique(c(noKeyColumnAvailable,readList[[i]]$colName))
        noKeyColAvailableIndex <- c(noKeyColAvailableIndex,i)
        if(returnDataWithNoKeyCol == FALSE){
          z=z+1
          toReadList_noKey[[z]] <- readList[[i]]
        } 
      } else {
        p=p+1
        toReadList[[p]] <- readList[[i]]
        keyColAvailableIndex <- c(keyColAvailableIndex,i)
        keyColumnAvailable <- unique(c(keyColumnAvailable,readList[[i]]$colName))
      }
    }
    
    if(length(toReadList_noKey)>0){
      found_but_noKey <- data.table::rbindlist(toReadList_noKey)$colName
    } else {
      found_but_noKey <- vector()
    }
    
    if(returnDataWithNoKeyCol == FALSE){
      toReadList_noKey <- list()
    }
    
    originalColOrder <- columns
    notFound <- toRead$notFound
    
    #---------------------------------------------------------------------------
    #READ DATA HERE
    #---------------------------------------------------------------------------
    
    #J loop with nested i loop read in all of the data.
    #Eventually parallelize this.
    #argsToGive: keyColumn, toReadList, returnDataWithNoKeyCol, combineAll
    readInFxn <- function(X,
                          toReadList, 
                          keyColumn,
                          xl_sheet = xl_sheet,
                          header = header,
                          nrows = nrows,
                          allRows = allRows,
                          specificRows = specificRows,
                          preserveSpecificRowOrder = preserveSpecificRowOrder,
                          col_type = col_type,
                          col_type_n_guess = col_type_n_guess,
                          skipExcel_zip = skipExcel_zip,
                          allow_gz_bz2_unzip = allow_gz_bz2_unzip,
                          force_gz_bz2_unzip = force_gz_bz2_unzip,
                          directoryForTempDir = directoryForTempDir,
                          max_size_for_excel_zip = max_size_for_excel_zip,
                          quiet,...){
      
      #X=4
      tempPath = toReadList[[X]]$file[1]
      tempTable = toReadList[[X]]$table[1]
      #get name for the element of the list
      #namesDatList <- ifelse(tempPath == tempTable,tempPath,paste0(tempPath,"_._",tempTable))
      
      tempColumns = toReadList[[X]]$colName
      if(!is.null(keyColumn)){
        tempColumns <- unique(c(keyColumn,tempColumns))
      }

      #READ IN THE DATA and put into 'datList[[i]]'
      dataRead <-
        suppressMessages(
          mm.quiet(
            try(mm.fastread(path = tempPath,
                  table = tempTable,
                  xl_sheet = xl_sheet,
                  header = header,
                  nrows = nrows,
                  allRows = allRows,
                  specificRows = specificRows,
                  columns = tempColumns,
                  preserveSpecificRowOrder = preserveSpecificRowOrder,
                  returnColsNotAvailable = FALSE,
                  returnAs = "data.table",
                  col_type = col_type,
                  col_type_n_guess = col_type_n_guess, 
                  type = type,
                  skipExcel_zip = skipExcel_zip,
                  allow_gz_bz2_unzip = allow_gz_bz2_unzip,
                  force_gz_bz2_unzip = force_gz_bz2_unzip,
                  directoryForTempDir = directoryForTempDir,
                  max_size_for_excel_zip = max_size_for_excel_zip,
                  quiet = quiet), 
                silent = TRUE)
          )
        )
       #END READING IN DATA.
      return(readIn = dataRead)
    } #END READ IN FUNCTION 
    
    
    allDat <- list()
    allDat[[1]] <- NA
    allDat[[2]] <- NA
    
    for( i in c(1:2)){
      
      if(i ==1)tempReadList <- toReadList
      if(i ==2)tempReadList <- toReadList_noKey
      
      if(length(tempReadList)>0){
        
        if(cores >1){
          allDat[[i]] <- 
            parallel::mclapply(
            X = seq_along(tempReadList), 
            FUN = readInFxn, 
            toReadList = tempReadList,
            keyColumn = keyColumn, 
            combineAll = combineAll,
            xl_sheet = xl_sheet,
            header = header,
            nrows = nrows,
            allRows = allRows,
            specificRows = specificRows,
            preserveSpecificRowOrder = preserveSpecificRowOrder,
            col_type = col_type,
            col_type_n_guess = col_type_n_guess,
            skipExcel_zip = skipExcel_zip,
            allow_gz_bz2_unzip = allow_gz_bz2_unzip,
            force_gz_bz2_unzip = force_gz_bz2_unzip,
            directoryForTempDir = directoryForTempDir,
            max_size_for_excel_zip = max_size_for_excel_zip,
            quiet = quiet, 
            mc.cores = cores)  
        } else {
          allDat[[i]] <- 
            lapply(
            X = seq_along(tempReadList), 
            FUN = readInFxn, 
            toReadList = tempReadList,
            keyColumn = keyColumn, 
            combineAll = combineAll,
            xl_sheet = xl_sheet,
            header = header,
            nrows = nrows,
            allRows = allRows,
            specificRows = specificRows,
            preserveSpecificRowOrder = preserveSpecificRowOrder,
            col_type = col_type,
            col_type_n_guess = col_type_n_guess,
            skipExcel_zip = skipExcel_zip,
            allow_gz_bz2_unzip = allow_gz_bz2_unzip,
            force_gz_bz2_unzip = force_gz_bz2_unzip,
            directoryForTempDir = directoryForTempDir,
            max_size_for_excel_zip = max_size_for_excel_zip,
            quiet = quiet)
        }
      }
    }
    
    noDatList <- FALSE
    if(!is.na(allDat[[1]][1])){
      datList <- allDat[[1]]
      namesDatList <- vector()
      for(X in seq_along(toReadList)){
        tempPath = toReadList[[X]]$file[1]
        tempTable = toReadList[[X]]$table[1]
        #get name for the element of the list
        namesDatList[X] <- ifelse(tempPath == tempTable,tempPath,
                               paste0(tempPath,"_._",tempTable))  
      } 
      names(datList) <- namesDatList
    } else {
      noDatList <- TRUE
      datList <- NULL
    }
    
    
    noDatList_noKey <- FALSE
    if(!is.na(allDat[[2]][1])){
      datList_noKey <- allDat[[2]]
      namesDatList_noKey <- vector()
      for(X in seq_along(toReadList_noKey)){
        tempPath = toReadList_noKey[[X]]$file[1]
        tempTable = toReadList_noKey[[X]]$table[1]
        #get name for the element of the list
        namesDatList_noKey[X] <- ifelse(tempPath == tempTable,tempPath,
                                     paste0(tempPath,"_._",tempTable))  
      }
      names(datList_noKey) <- namesDatList_noKey
    } else {
      noDatList_noKey <- TRUE
      datList_noKey <- NULL
    }
    
    allDat <- NULL
    
    
    #if unable to find the keyColumn requested, but all data was found in a single data table... 
    #return the data table but make it known that the keyColumn was not found.
    length_datList <- ifelse(!is.null(datList),length(datList),0)
    length_datList_noKey <- ifelse(!is.null(datList_noKey),length(datList_noKey),0)
    
    if(combineAll == TRUE){
      #if data was read from at >1 table
      if(length_datList_noKey ==1 & noKeyColProvided == TRUE){
        datList_noKey <- datList_noKey[[1]]
      }
      
      if(length_datList_noKey > 1){
        #Attempt to combine but ONLY if nrows in each element are same
        if(noKeyColProvided == TRUE){
          
          nrVec <- vector()
          for(i in 1:length_datList_noKey){
            nrVec[i] <- nrow(datList_noKey[[i]])
          }
          if(length(unique(nrVec))==1){
            message("DANGER: COMBINING COLUMNS FROM DIFFERENT TABLES WITHOUT A 'keyColumn'. ROWS MAY NOT BE MATCHING AS EXPECTED (ALTHOUGH THEY DO ALL HAVE THE SAME NUMBER OF ROWS. DID YOU INSTEAD MEAN TO SET 'combineAll = FALSE' TO RETURN A LIST OF TABLES?")
            datList_noKey <- data.table::setDT(dplyr::bind_cols(datList_noKey))
            
            namesVec <- vector()
            for(i in 1:length_datList_noKey){
              namesVec <- c(namesVec,names(datList_noKey[[i]]))
            }
            names(datList_noKey) <- namesVec
          } else {
            message("WARNING: no 'keyColumn' provided and 'combineAll' = TRUE but data has differing rows. Cannot combine. Forced to return data as list")
          }
        } #end is.null(keyColumn)
      }

      #------------------------------------------------------------------#
      #Join data sets here!
      #------------------------------------------------------------------#  
      #if data was read from at >1 table
      if(length_datList > 0){
        #seed to start the joined table 
        #convert keyColumn to character to avoid errors in joining.
        data.table::setDT(datList[[1]])[
          ,(keyColumn) := lapply(.SD,as.character), 
          .SDcols = keyColumn]
        
        data.table::setindexv(datList[[1]],keyColumn)
        
        while(length(datList)>1){
        
          data.table::setDT(datList[[2]])[
            ,(keyColumn) := lapply(.SD,as.character), 
            .SDcols = keyColumn]

          #if they are the same n rows... fast merge with data.table
          if(datList[[1]][,.N] == datList[[2]][,.N]){
            datList[[1]][datList[[2]],
                (names(datList[[2]])) := datList[[2]], 
                on = keyColumn]  
          } else { #if different number of rows, use 
            datList[[1]] <- 
              data.table::setDT(
                datList[[1]] %>% 
                  full_join(datList[[2]], 
                            by = get("keyColumn"))
              )
          }
            #str(datList)
          datList[[2]] <- NULL
        }
        datList <- datList[[1]]
      } #end if(combineAll == TRUE)
    }

    #set the column order for those that were found and combined.
    #if the first element is not a list
    if(length_datList > 0){
      namesOrder <- originalColOrder[which(originalColOrder %in% names(datList))]
      data.table::setcolorder(datList,namesOrder)
    }
    
    if(length_datList_noKey > 0){
      #if the first element is a list
      if("data.frame" %in% class(datList_noKey)){
        namesOrder <- originalColOrder[which(originalColOrder %in% names(datList_noKey))]
        data.table::setcolorder(datList_noKey,namesOrder)
      }
      
      if(class(datList_noKey)[1] == "list"){
        for(i in 1:length(datList_noKey)){
          namesOrder <- originalColOrder[which(originalColOrder %in% names(datList_noKey[[i]]))]
          data.table::setcolorder(datList_noKey[[i]],namesOrder)
        }
      }
    }
    
    
    colsNotAvailable <- unique(notFound)
    numColsTotal <- length(columnsOrig)
    
    numColsNotFound <- length(unique(notFound))
    numColsFound <- numColsTotal - numColsNotFound
    message(sprintf("Returning data: nCols Found: %s, nCols notFound %s.",numColsFound,numColsNotFound))
    

    if(noKeyColProvided == TRUE){
      datList <- datList_noKey
      colsNotAvailable <- colsNotAvailable
      datList_noKey <- NULL
      found_but_noKey <- NULL
    }
    
    
    if(is.null(datList)){
      datList <- data.table::data.table()
    }
    
    if(returnDataWithNoKeyCol == FALSE){
      datList_noKey <- NULL
    } else if(is.null(datList_noKey)){
      datList_noKey <- data.table::data.table()
    }
    
    
    if(returnColNamesWithNoKeyCol == FALSE){
      found_but_noKey <- NULL
    } else if(is.null(found_but_noKey)){
      found_but_noKey <- vector()
    }
    
    if(printFilesNotRead == FALSE){
      dataUnableToRead <- NULL
    } else if(is.null(dataUnableToRead)){
      dataUnableToRead <- vector()
    }
    
    if(returnColsNotAvailable == FALSE){
      colsNotAvailable = NULL
    } else if(is.null(colsNotAvailable)){
      colsNotAvailable <- vector()
    }
    
    

    if(returnAs == "data.frame"){
      
      if(length_datList > 0){
        try(data.table::setDF(datList),silent = TRUE)
      }
      
      if(length_datList_noKey > 0){
        if("data.frame" %in% class(datList_noKey)){
          try(data.table::setDF(datList_noKey),silent = TRUE)
        } 
        
        if(class(datList_noKey)[1] == "list"){
          for(i in 1:length(datList_noKey)){
            try(data.table::setDF(datList_noKey[[i]]),silent = TRUE)
          }
        }
      }
    }
    
    if(returnAs %in% c("tbl_df","tibble","tbl","data_frame")){
      
      if(length_datList > 0){
        try(datList <- 
              dplyr::as_tibble(datList),silent = TRUE)
      }
      
      if(length_datList_noKey > 0){
        if("data.frame" %in% class(datList_noKey)){
          try(datList_noKey <- 
                dplyr::as_tibble(datList_noKey),silent = TRUE)
        } 
        
        if(class(datList_noKey)[1] == "list"){
          for(i in 1:length(datList_noKey)){
            try(datList_noKey[[i]] <- 
                  dplyr::as_tibble(datList_noKey[[i]]),silent = TRUE)
          }
        }
      }
    }
      
    if(class(datList)[1] == "list"){
      
      if(class(datList_noKey)[1] == "list"){
        toReturn <- 
          list(table_list = datList,
               columns_not_available = colsNotAvailable,
               table_list_noKey = datList_noKey,
               found_but_noKey = found_but_noKey,
               files_not_read = dataUnableToRead)
      } else {
        toReturn <- 
          list(table_list = datList,
               columns_not_available = colsNotAvailable,
               table_noKey = datList_noKey,
               found_but_noKey = found_but_noKey,
               files_not_read = dataUnableToRead)
      }
    }
    
    
    if("data.frame" %in% class(datList)){
      if(class(datList_noKey)[1] == "list"){
        toReturn <- 
          list(table = datList,
               columns_not_available = colsNotAvailable,
               table_list_noKey = datList_noKey,
               found_but_noKey = found_but_noKey,
               files_not_read = dataUnableToRead)
      } else {
        toReturn <- 
          list(table = datList,
               columns_not_available = colsNotAvailable,
               table_noKey = datList_noKey,
               found_but_noKey = found_but_noKey,
               files_not_read = dataUnableToRead)
      }
    }
  
    for(i in length(toReturn):1){
      if(is.null(toReturn[[i]])) toReturn[[i]] <- NULL
    }
    
    
    return(toReturn)

  } else if(search == FALSE){
    return(mm.quiet(mm.fastread(path = path,
                            table = table,
                            xl_sheet = xl_sheet,
                            header = header,
                            nrows = nrows,
                            allRows = allRows,
                            specificRows = specificRows,
                            columns = columns,
                            preserveSpecificRowOrder = preserveSpecificRowOrder,
                            returnColsNotAvailable = returnColsNotAvailable,
                            returnAs = returnAs,
                            col_type = col_type,
                            col_type_n_guess = col_type_n_guess,
                            skipExcel_zip = skipExcel_zip,
                            allow_gz_bz2_unzip = allow_gz_bz2_unzip,
                            force_gz_bz2_unzip = force_gz_bz2_unzip,
                            directoryForTempDir = directoryForTempDir,
                            max_size_for_excel_zip = max_size_for_excel_zip,
                            type = type), 
                    quiet = quiet))
  }
}

#path <- "./../../00_labAndSampKeys/1_virScanData/counts"
#columns <- c("X54.A1","mjm.8.A1","testCol1","hello","Yippers", "testCol2","testCol5","testCol6")
#mm.findData(path,colsToFind)


# mm.fastread2(path = path, columns = c("mjm.8.A10","mjm.10.B11","mm2.A36","mjm.18.A1","X54.A1","testCol2","Yippers"),keyColumn = "id",includeSubDirectories = TRUE,combineAll = FALSE, returnColsNotAvailable = FALSE, returnAs = "data.table")
