#' grep one or a vector of objects

#' @export
mm.grepVec <- function(toMatch,toLookIn, value = FALSE){
  return(unique (grep(paste(toMatch,collapse="|"),
                      toLookIn, value=value)))
}
