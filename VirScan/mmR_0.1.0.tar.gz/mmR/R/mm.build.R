#' Function to run devtools::document, build, install
#'
#' This function provides a shortcut to run 4 devtools functions at once when
#' developing packages. When in the appropriate working directory of a package
#' being built, type mmR::mm.build() to document(), build(), install() and
#' restart() R. Any of those can be set to FALSE.
#'
#' @param document,build,install,restart Run
#'   \code{devtools::document()},\code{build()},\code{install()} and/or
#'   \code{.rs.restart()}. Default is all set to TRUE. Restart keeps all
#'   variables in environment but restarts the R session.
#'   
#' @param pkgDir Root directory of a package to build. Default (NULL) points to
#'   current working directory
#'
#' @export
mm.build <- function(pkgDir = NULL,
                     document = TRUE,
                     build = TRUE,
                     install = TRUE,
                     restart = TRUE){
  
  
  if(!is.null(pkgDir)){
    if(dir.exists(pkgDir)){
      original_wd <- getwd()
      on.exit(setwd(original_wd))
      setwd(pkgDir)  
    } else {
      stop("Please supply an existing directory to 'pkgDir' or set pkgDir = NULL (DEFAULT)")
    }
  }
  
  if(document) devtools::document()
  if(build) devtools::build()
  if(install) devtools::install()
  if(restart) .rs.restartR()

}


