#' Functino to compress a .csv to a .gz file
#'
#' @param file String: filename of the .csv to compress
#'
#' @param destName The destination file path and name of the written file. If
#'   NULL (Default) will default to the file_name.gz
#'
#' @param keep_original Should the original file be kept or removed after
#'   compressing
#'
#' @param overwrite If there is a current .gz file with the same name,
#'   overwrite?
#'
#' @export
mm.csv_to_gz <- function(file,
                         destName = NULL,
                         keep_original = TRUE,
                         overwrite = FALSE){

  if(is.null(destName)){

     destName = file
  }

  if(mm.stringEnd(destName,3) == ".gz"){
    destName <- mm.stringBegin(destName,nchar(destName)-3)
  }

  if(file.exists(paste0(destName,".gz")) & overwrite == FALSE){

    sprintf("STOP: .gz file already exists and overwrite = FALSE")

  }

  if(keep_original == TRUE){

    #-k keeps copy
    #-f forces to overwrite
    #fullCommand = paste0("gzip -k -f ",file)
    R.utils::gzip(file, destname = sprintf("%s.gz",destName), overwrite = overwrite,remove = FALSE)

  } else {

    #fullCommand = paste0("gzip -f ",file)
    R.utils::gzip(file, destname = sprintf("%s.gz",destName), overwrite = overwrite,remove = TRUE)
  }
#destName = file
    #system(fullCommand)

}

#mm.csv_to_gz(file = file)

# file <- "/Users/michaelmina/Dropbox (Personal)/academic life/1 Research Life/1 Institutions/Harvard/Elledge/myFileTest.csv"
#
# file <- "/Users/michaelmina/Desktop/myFile.csv"
#
# mmR::mm.csv_to_gz(file)
# R.utils::gunzip(file, ext = "gz", overwrite = FALSE, remove = FALSE)
# R.utils::gzip(file, ext = "gz", overwrite = TRUE, remove = TRUE)
#
#
# data <- data.frame(X=1:2e5,Y=1:2e5,X=1:2e5,Y=1:2e5,X=1:2e5,Y=1:2e5,X=1:2e5,Y=1:2e5)
# mmR::mm.write_gz(data = data,file = file,overwrite = TRUE)
# mmR::mm.build()

