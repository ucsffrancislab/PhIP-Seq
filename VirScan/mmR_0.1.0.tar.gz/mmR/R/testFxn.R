#' test new function in pkg
#' @export

testFxn <- function(){
  return("Function exists")
}
