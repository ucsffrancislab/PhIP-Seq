


#' Function to search through a database, including directories of databases, excel files, SQLite databases and return the location of columns.
#'
#' Function to search through a database, including directories of databases,
#' excel files, SQLite databases and return the location of columns/data. This
#' uses mm.findSamplesInDB and searches recursively if 'includeSubDirectories is
#' set to TRUE. In particular, besides just looking at single table databases
#' (like a CSV file), it will look through the various worksheets/tables of an
#' excel or SQL data base and provide back the location of the data base and the
#' table that the data column was discovered in.
#'
#' @importFrom magrittr %>%
#'
#' @inheritParams mm.findSamplesInDB
#' @param includeSubDirectories if path points to a directory, should databases
#'   housed within subdirectories be searched as well.
#' @param returnOnlyFirstInstance if TRUE, will stop searching for a given column as
#'   soon as the first instance is found. If FALSE (DEFAULT) will potentially
#'   return multiple rows so that the user can determine which to use.
#'
#' @export
mm.findData <-
  function(path,
           colsToFind = NULL,
           tablesToLookIn = NULL,
           includeSubDirectories = TRUE,
           returnOnlyFirstInstance = FALSE,
           splitToList = FALSE, 
           directoryForTempDir = NULL,
           skipExcel_zip = FALSE,
           allow_gz_bz2_unzip = TRUE,
           force_gz_bz2_unzip = FALSE,
           max_size_for_excel_zip = 20000,
           cores = parallel::detectCores()-1){
    
    
    pathType <- mm.fileType(path)
    if(pathType == "directory"){
      files <- mm.listTables(path, full.names = TRUE, recursive = includeSubDirectories)
    }
    if(pathType %in% c("csv","c_csv")){
      files = path
    }
    
    if(pathType %in% c("excel", "c_excel","SQlite")){
      files <- path
    }
    
    willRead <- mm.quiet(
      mm.will_fastread(path = files,
                       directoryForTempDir = directoryForTempDir,
                     skipExcel_zip = skipExcel_zip,
                     allow_gz_bz2_unzip = allow_gz_bz2_unzip,
                     force_gz_bz2_unzip = force_gz_bz2_unzip,
                     max_size_for_excel_zip = max_size_for_excel_zip,
                     cores = cores)
      )
    
    
    
    
    files_not_read <- files[which(willRead == FALSE)]
    files <- files[which(willRead == TRUE)]
    
    
    
    if(cores == 1){
      toReturn <-
        mm.findDataSingleCore(files = files,
                              colsToFind = colsToFind,
                              tablesToLookIn = tablesToLookIn,
                              includeSubDirectories = includeSubDirectories,
                              returnOnlyFirstInstance = returnOnlyFirstInstance,
                              directoryForTempDir = directoryForTempDir,
                              skipExcel_zip = skipExcel_zip,
                              allow_gz_bz2_unzip = allow_gz_bz2_unzip,
                              force_gz_bz2_unzip = force_gz_bz2_unzip,
                              max_size_for_excel_zip = max_size_for_excel_zip,
                              splitToList = splitToList)
    } else {
      
      toReturn <-
        mm.findDataMultiCore(files = files,
                             colsToFind = colsToFind,
                             tablesToLookIn = tablesToLookIn,
                             includeSubDirectories = includeSubDirectories,
                             returnOnlyFirstInstance = returnOnlyFirstInstance,
                             directoryForTempDir = directoryForTempDir,
                             skipExcel_zip = skipExcel_zip,
                             allow_gz_bz2_unzip = allow_gz_bz2_unzip,
                             force_gz_bz2_unzip = force_gz_bz2_unzip,
                             max_size_for_excel_zip = max_size_for_excel_zip,
                             splitToList = splitToList,
                             cores = cores)
      
    }
    
    toReturn[[3]] <- files_not_read
    names(toReturn) <- c(names(toReturn)[1:2],"files_not_read")
    return(toReturn)
}
    

mm.findDataMultiCore <-
  function(files,
           colsToFind,
           tablesToLookIn = NULL,
           includeSubDirectories = TRUE,
           returnOnlyFirstInstance = FALSE,
           directoryForTempDir = NULL,
           skipExcel_zip = FALSE,
           allow_gz_bz2_unzip = TRUE,
           force_gz_bz2_unzip = FALSE,
           max_size_for_excel_zip = 20000,
           splitToList = TRUE, 
           cores = parallel::detectCores()-1){
    
    
    #FUN for mclapply
    internalApplyFun_findSamplesInDB <- 
      function(X,
             files,
             tablesToLookIn,
             colsToFind,
             directoryForTempDir = directoryForTempDir,
             skipExcel_zip = skipExcel_zip,
             allow_gz_bz2_unzip = allow_gz_bz2_unzip,
             force_gz_bz2_unzip = force_gz_bz2_unzip,
             max_size_for_excel_zip = max_size_for_excel_zip,
             cores){
      i = X
      temp <- 
        mm.findSamplesInDB(
          path = files[i],
          tablesToLookIn = tablesToLookIn,
          colsToFind = colsToFind, 
          directoryForTempDir = directoryForTempDir,
          skipExcel_zip = skipExcel_zip,
          allow_gz_bz2_unzip = allow_gz_bz2_unzip,
          force_gz_bz2_unzip = force_gz_bz2_unzip,
          max_size_for_excel_zip = max_size_for_excel_zip,
          cores = 1)
      
      temp$found <- 
        temp$found %>% 
        dplyr::mutate(file = files[i])
      
      return(temp$found)
    }
    
    
    
    foundList <- 
      parallel::mclapply(
        X = seq_along(files), 
        FUN = internalApplyFun_findSamplesInDB,
        files = files,
        tablesToLookIn = tablesToLookIn,
        colsToFind = colsToFind, 
        directoryForTempDir = directoryForTempDir,
        skipExcel_zip = skipExcel_zip,
        allow_gz_bz2_unzip = allow_gz_bz2_unzip,
        force_gz_bz2_unzip = force_gz_bz2_unzip,
        max_size_for_excel_zip = max_size_for_excel_zip,
        mc.cores = cores) #end foundList <- mclapply...
    
    
    found <- 
      data.table::rbindlist(foundList)  %>%
      data.frame() %>%
      dplyr::group_by(colName) %>%
      dplyr::mutate(count = 1, countcum = cumsum(count)) %>%
      dplyr::mutate(count = sum(count)) %>%
      dplyr::ungroup() %>%
      dplyr::select(colName,count,file,table,countcum)
      
      notFound <- colsToFind[which(!colsToFind %in% found$colName)]
      
      if(returnOnlyFirstInstance == TRUE){
        if(length(unique(found$countcum))>1){
          print("Found multiple data columns with the same name. Returning only the first. To return all, set 'returnOnlyFirstInstance to FALSE")
          found <- found %>% dplyr::filter(countcum ==1)
        }
      }
    
    
    if(splitToList == TRUE){
      found <- mm.split_to_list(found, by = c("file","table"))
    }
    
    
    return(list(found = found,notFound = notFound))
  }


#path <- "./../../00_labAndSampKeys/1_virScanData/counts"
#columns <- c("X54.A1","mjm.8.A1","testCol1","hello","Yippers", "testCol2","testCol5","testCol6")
#mm.findData(path,colsToFind)


#Original version - allows to actually only search for the first instance

mm.findDataSingleCore <-
  function(files,
           colsToFind,
           tablesToLookIn = NULL,
           includeSubDirectories = TRUE,
           returnOnlyFirstInstance = FALSE,
           directoryForTempDir = NULL,
           skipExcel_zip = FALSE,
           allow_gz_bz2_unzip = TRUE,
           force_gz_bz2_unzip = FALSE,
           max_size_for_excel_zip = 20000,
           splitToList = TRUE){

    FINISHED = FALSE
    foundList <- list()
    
    for(i in seq_along(files)){
      #i=1
      if(FINISHED == FALSE){

        temp <- mm.findSamplesInDB(path = files[i],
                                   tablesToLookIn = tablesToLookIn,
                                   colsToFind = colsToFind, 
                                   directoryForTempDir = directoryForTempDir,
                                   skipExcel_zip = skipExcel_zip,
                                   allow_gz_bz2_unzip = allow_gz_bz2_unzip,
                                   force_gz_bz2_unzip = force_gz_bz2_unzip,
                                   max_size_for_excel_zip = max_size_for_excel_zip,
                                   cores = 1)

        temp$found <- 
          temp$found %>% 
          dplyr::mutate(file = files[i])
       
         foundList[[i]] <- temp$found

        if(returnOnlyFirstInstance == TRUE){
          colsToFind <- temp$notFound
          if(length(colsToFind) == 0){
            FINISHED = TRUE
            print("Found All data. Stopped Searching Early. To search all, including duplicates, set 'returnOnlyFirstInstance = FALSE")}

        }
      }
    }

    

    found <- data.table::rbindlist(foundList)  %>%
      data.frame() %>%
      dplyr::group_by(colName) %>%
      dplyr::mutate(count = 1, countcum = cumsum(count)) %>%
      dplyr::mutate(count = sum(count)) %>%
      dplyr::ungroup() %>%
      dplyr::select(colName,count,file,table,countcum)
    notFound <- colsToFind[which(!colsToFind %in% found$colName)]

    if(splitToList == TRUE){
      found <- mm.split_to_list(found, by = c("file","table"))
    }


    return(list(found = found,notFound = notFound))
}











