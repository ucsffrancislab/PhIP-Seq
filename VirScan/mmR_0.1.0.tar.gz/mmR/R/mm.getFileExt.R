#' Function to return the extension of a file
#'
#' Used within mm.fileType()
#'
#' @param x Path to a file
#' @param ifCompressedReturnBoth If the file appears to be a compressed file (i.e.ends in: gz,gzip,bz,bz2,zip,tgz)
#' @param otherCompressedExt can add other newer or custom compression extensions to look out for besides: c("gz","gzip","bz","bz2","zip","tgz".
#' @export
mm.getFileExt <- function(x,ifCompressedReturnBoth = FALSE,otherCompressedExt = NULL){

  toReturn <- getFileExt.Int(x)

  if(ifCompressedReturnBoth){

    if(mm.isCompressed(x,otherCompressedExt = otherCompressedExt)){
      x_noExt <- mm.stringRightRemove(x,rmExt = TRUE)
      toReturn2 <- getFileExt.Int(x_noExt)
    }
    toReturn <- paste0(toReturn,".",toReturn2)
  }
  return(toReturn)
}





#' Function to check if a file is compressed or not
#'
#' Used within mm.getFileExt() and can be used alone
#'
#' @param x Path to a file
#' @param otherCompressedExt can add other newer or custom compression extensions to look out for besides: c("gz","gzip","bz","bz2","zip","tgz".
#' @export
mm.isCompressed <- function(x,otherCompressedExt = NULL){
  compressedOptions <- unique(c("gz","gzip","bz","bz2","zip","tgz",otherCompressedExt))

  if(getFileExt.Int(x) %in% compressedOptions){return(TRUE)}else{return(FALSE)}
}

#path <- "/users/michaelmina/Dropbox (Personal)/academic life/1 Research Life/1 Institutions/Harvard/Elledge/1 virScan/00 labAndSampKeys/SQLdatabases/virScanData.sqlite"
#path <- "./../../11 Tomasz Work/vir2 Everything from Orchestrat/vir2.count.csv.gz"
#path <- "./../../11 Tomasz Work/vir2 Everything from Orchestrat/metadata.xlsx"


#' Internal function to get file extension
getFileExt.Int <- function(x){
  pos <- regexpr("\\.([[:alnum:]]+)$", x)
  ifelse(pos > -1L, substring(x, pos + 1L), "")
}
