#' mmR: A package with various useful tools.....
#'
#' The mmR package provides random tools including various basic statistical
#' algorithms, methods to read files quickly, etc...
#'
#' @section statistical tools
#'
#' @section read write tools
#'
#' @docType package
#'
#' @name mmR
NULL
