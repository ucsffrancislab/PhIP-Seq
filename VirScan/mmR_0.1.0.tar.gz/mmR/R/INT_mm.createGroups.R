


#path <- "./../../00 labAndSampKeys/sampMetaData/allSamplesMeta.xlsx"
#xl_sheet <- "VirScanKey"
#columns <- mm.listTableCols(path,table = xl_sheet)[c(4:25,28:32,38,39)]
#specicRows <- NULL
#specificRows <- c(120:126,110:112,116:118,1668:1666,1669)





# minNonConsec =3
#
# seqle <- function(x,incr=1) {
#   if(!is.numeric(x)) x <- as.numeric(x)
#   n <- length(x)
#   y <- x[-1L] != x[-n] + incr
#   i <- c(which(y|is.na(y)),n)
#   list(lengths = diff(c(0L,i)),
#        values = x[head(c(0L,i)+1L,-1L)])
# }
#
#
# specificRowsOrdered <- sort(specificRows)
#
#
#
# consecLengths <- seqle(specificRowsOrdered, incr=1)
#
# newVals <- consecLengths$lengths + consecLengths$values
#
#
# group <- rep(1:length(consecLengths$lengths),consecLengths$lengths)
#
# rowDF <-
#   data.frame(rows = specificRowsOrdered,
#              group = group) %>%
#   mutate(diff = c(1,diff(rows))) %>%
#   mutate(originalRows = specificRows) %>%
#   group_by(group) %>%
#   mutate(newGrp = ifelse(max(diff)>minNonConsec,0,-1),
#          newGrp = group + newGrp) %>%
#   ungroup()
#
# rowGrpsList <- split( rowDF , f = rowDF$newGrp )
#
#
# rowsToGet <- list()
# for(i in 1:length(rowGrpsList)){
#   rowsToGet[[i]] <-
#     data.frame(rows = c(min(rowGrpsList[[i]]$rows):max(rowGrpsList[[i]]$rows))) %>%
#     left_join(rowGrpsList[[i]] %>% select(rows, group, originalRows), by = "rows") %>%
#     mutate(internalRowNum = 1,internalRowNum = cumsum(internalRowNum))
# }
#
