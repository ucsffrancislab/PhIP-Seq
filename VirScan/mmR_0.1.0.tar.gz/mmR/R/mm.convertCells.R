#' Convert specific values in a data frame to new values
#'
#' Good for getting rid of NAs or converting NULL cells to zero etc
#'
#' @param data a data frame to convert cells in
#'
#' @param nonSampleCols A vector of column positions or names that denote
#'   columns that should not be evaluated
#'
#' @param originalVal The value that you want to change. This can be NA,NULL, or
#'   a value to match exactly
#'
#' @param newVal The value to change the originalVal cells to
#'
#' @param byCols TRUE, will look down columns, FALSE will look across rows. Should
#'   have same effect
#'
#' @return The data frame in a tbl_df() with values changed.
#'
#' @export
mm.convertCells <- function(data,
                            nonSampleCols,
                            originalVal,
                            newVal,
                            byCols = TRUE) {

  direction = ifelse(byCols,2,1)
  originalNames <- colnames(data)

  if(!is.numeric(nonSampleCols)){
    nonSampleDataIndex <- which(colnames(data) %in% nonSampleCols)
  } else {
    nonSampleDataIndex <- nonSampleCols
  }

  nonSampleDataNames <- colnames(data)[nonSampleDataIndex]
  nonSampleData <- data.frame(data[,nonSampleDataIndex])
  colnames(nonSampleData) <- nonSampleDataNames

  dataNames <- colnames(data)[-nonSampleDataIndex]
  data <- data[,-nonSampleDataIndex]
  colnames(data) <- dataNames

  if(is.na(originalVal)){
    toReturn <- apply(data,
                      direction,
                      FUN = function(X){
                        X[which(is.na(X))] = newVal;
                        return(X)})
  } else if(is.null(originalVal)) {
    toReturn <- apply(data,
                      direction,
                      FUN = function(X){
                        X[which(is.null(X))] = newVal;
                        return(X)})
  } else {
    toReturn <- apply(data,
                      direction,
                      FUN = function(X){
                        X[which(X %in% originalVal)] = newVal;
                        return(X)})

  }

  return(dplyr::tbl_df(cbind(nonSampleData, toReturn)) %>%
           select(originalNames))

}
