#' Automatically detect file type and read it in very quickly. Note:
#' \link{mmR::mm.fastread2} is more advanced and, given a directory or parent
#' database, will search for all supplied columns across the databases. See
#' \link{mmR::mm.fastread2} for more information. Back to the current
#' function... it reads csv,xlsx,csv.gz,sqlite database (automatic detection of
#' file type). Can supply particular rows and columns. Can specify particular
#' tables in databases or, if reading in excel workbooks, can specify either the
#' number or name of the worksheet either using table or xl_sheet parameter.
#' Will also provide back, if desired, a data frame with all of the columns that
#' were requested but not found. To read in a .gz file, it uses
#' data.table::fread("gunzip -c /path"))
#'
#' @family database connections
#'
#' @param path String: The path to the .gz or .csv file, including the name plus
#'   extension
#' @param table Table or number of the table to collect - only used if path
#'   leads to a SQL DB or the table name or numer to collect from if this is an
#'   Excel workbook
#'
#' @param xl_sheet Like \code{table} can be a string or a sheet number for the
#'   actual worksheet in an excel file. If path leads to a SQL DB and xl_sheet
#'   is specified but table remains \code{NULL} then this will specificy which
#'   table to pull from the SQL DB
#'
#' @param header Should the first row of the data be the column names. Defaults
#'   to TRUE. Only used for file types of csv, csv.gz, xls, xlsx
#'
#' @param nrows,allRows,specificRows,preserveSpecificRowOrder Number of rows to
#'   return, or allRows, or a vector of specific rows. Default is to return all
#'   unless nrows or specificRows is specified. If specificRows and nRows are
#'   both specified, then it will do nrows of the specificRows. If
#'   'specificRows' are specified (i.e. c(1,5,11,12,2,45)), should the returned
#'   rows be in the same order?
#'
#' @param columns Vector of specific columns to return. If not \code{NULL} will
#'   only return those columns that exist.
#'
#' @param returnColsNotAvailable Should columns requested but not available be
#'   returned as a vector in the second element of a returned list. Of note,
#'   this causes the behavior of what is returned to be a list and not a
#'   data.frame object
#' @param type The type of file to be found at \code{path}. Not necessary but
#'   could potentially be helpful. Options are: "SQLite","csv","xls","xlsx","gz","xz","bz2"
#'
#' @param returnAs What type of data structure to return. Choose from:
#'   "data.table" (DEFAULT),"data.frame" or a tibble - any of:
#'   "tbl_df","data_frame","tibble","tbl".
#'
#' @param col_type,col_type_n_guess Specify the column types. if automatic
#'   col_type selection desired, tell it how many rows to scan for guessing.
#'   Default is col_type = NULL and col_type_n_guess = 1e5.
#'
#' @param allow_gz_bz2_unzip,force_gz_bz2_unzip If a file is .gZipped with .gz
#'   extension, the only way to open it currently is to uncompress it without
#'   copy. This can be useful but comes with risk - the actual file is being
#'   unzipped and kept in place (and then .gz zipped again at the end). THis has
#'   obvious risks. Of note, the function will not allow it IF the same root
#'   file name exists in that directory but already uncompressed, unless
#'   force_gunzip is TRUE, then it will attempt to write over the uncompressed
#'   file already existing.  By Default both of these are FALSE. Of note, this
#'   is different than skipExcel_zip. skipExcel_zip, if set to TRUE, will just
#'   not unzip any files. It is important to note that .zip files will not be
#'   unzipped in place, Instead, a temp directory will be created, the file will
#'   be 'safely' unzipped into that directory, and removed afterwards.This
#'   therefore makes a full copy of the uncompressed file, along with the
#'   compressed .zip file.
#'
#' @param skipExcel_zip,max_size_for_excel_zip Should excel files that are
#'   .zip,.gz,.bz2 be read? The reason is that the files have to be unzipped,
#'   placed in a temporary directory if .zip (see \code{directoryForTempDir}) or
#'   replace the compressed file altogether (.gz,.bz2) and then read before
#'   being removed again. So for big files, this can take quite some time. that
#'   said, max size allowable (in Mb) can also be specified using
#'   max_size_for_excel_zip in Mbs.

#' @param directoryForTempDir If opening xlsx.zip files, need to place them
#'   somewhere temporarily. by Default, NULL will place the temporary files into
#'   a temporary directory in the same location as the file path. However, this
#'   may not be desireable... for example if decompressing a large file which is
#'   inside a dropbox folder.. instead can specificy the directory into which
#'   the temporary directories should be placed and removed from.
#'
#' @inheritParams mm.listTables
#'
#' @return Returns the read in data either as a data.frame() or, if
#'   \code{returnColsNotAvailable = TRUE} then as a list with the data in the
#'   first element called "data" and any columns that were requested but not
#'   available as the second element.
#'
#' @examples
#' \dontrun{
#' myData <- mm.fastread(path = "./my.csv")
#' myData2 <- mm.frastread(path = "my.csv.gz")
#' myData3 <- mm.fastread(path = "my.csv.gz", as.data.frame = TRUE)
#' myData3 <- mm.fastread(path = "my.csv.gz", as.data.table = TRUE)
#' myData4 <- mm.fastread(path = "./../../00 labAndSampKeys/SQLdatabases/virScanData.sqlite", table = "meta",nrows = 7, as.data.frame= TRUE)
#' }
#'
#' @importFrom magrittr %>%
#' @export
mm.fastread <- function(path,
                        table = NULL,
                        xl_sheet = 1,
                        header = TRUE,
                        nrows = NULL,
                        allRows = TRUE,
                        specificRows = NULL,
                        columns = NULL,
                        preserveSpecificRowOrder = TRUE,
                        returnColsNotAvailable = FALSE,
                        returnAs = "data_frame",
                        col_type = NULL,
                        col_type_n_guess = 10000,
                        type = NULL,
                        skipExcel_zip = FALSE,
                        allow_gz_bz2_unzip = FALSE,
                        force_gz_bz2_unzip = FALSE,
                        directoryForTempDir = NULL,
                        max_size_for_excel_zip = 2000,
                        ...){




  #Open connectino to file at 'path'
  if(!file.exists(path)){
    stop("File to read does not exist")
  }

  
  if(
    mm.will_fastread(path = path, 
                      skipExcel_zip = skipExcel_zip, 
                      allow_gz_bz2_unzip = allow_gz_bz2_unzip,
                      force_gz_bz2_unzip = force_gz_bz2_unzip,
                      max_size_for_excel_zip = max_size_for_excel_zip,
                      cores = cores) == FALSE
    ){
    stop("file will not be read with current parameters")
    } 
    
    

  if(is.null(type)){
    type = mm.fileType(path)
  } else {
    type <- mm.convertUserInput_type.int(type)
  }
  toReturn <- NULL

  if(is.null(xl_sheet)){xl_sheet =1}


  originalColumnsRequested = NULL
  if(!is.null(columns)){
    if(returnColsNotAvailable){
      originalColumnsRequested = columns
    }
  }





  #---------------------------------------------------------------------------#
  #IF type is xls or xlsx
  #---------------------------------------------------------------------------#
  if(type %in% c("excel","c_excel")){
    if(type == "c_excel" & !skipExcel_zip){
      if(force_gz_bz2_unzip == TRUE) {
        allow_gz_bz2_unzip = TRUE
      }
      
      ext <- mm.getFileExt(path)
      #make a temporary directory
      pathPath <- base::dirname(path)
      
      if(!is.null(directoryForTempDir)){
        if(base::dir.exists(directoryForTempDir)){
          pathPath <- directoryForTempDir
        }
      }
        
      fileName <- base::basename(path)
      randNamePath <- 
        file.path(
          pathPath,
          paste0("tempZipXL_",
                 LETTERS[runif(n = 1,min = 1, max = 20)],
                 round(runif(n = 1,min = 1e6, max = 9e6),digits = 0)))
        
      if(dir.exists(randNamePath) == FALSE){
        dir.create(randNamePath)
        on.exit(unlink(randNamePath, recursive = TRUE))
      }
        
      destName <- file.path(randNamePath,
                            mm.stringRightRemove(fileName,rmExt = TRUE))
      
      if(ext == "zip"){
        utils::unzip(zipfile = path,exdir = randNamePath)  
      } else if(ext == "gz"){
        R.utils::gunzip(filename = path,ext = "gz", remove = FALSE, destname = destName)
      } else if(ext == "bz2"){
        R.utils::bunzip2(path,ext = "bz2",remove = FALSE, destname = destName)
      }
      
      pathOriginal <- path
      path <- destName
      type = mm.fileType(path)
        
      
    }
  
    if(!is.null(table) & xl_sheet ==1){
      xl_sheet = table
    }
    table = xl_sheet

    row_min = NA
    row_max = NA
    col_min = NA
    col_max = NA

    keepIndex_rows = NULL
    keepIndex_cols = NULL

    if(!is.null(nrows)){
      row_max = nrows
    }

    if(is.numeric(specificRows)){
        row_min <- min(specificRows)
        row_max <- max(specificRows)
        keepIndex_rows <- specificRows - row_min + 1

        if(header == TRUE){
          row_min = row_min + 1
          row_max = row_max + 1
        }
    } else {
      row_min = 1
    }

    suppressMessages(
      suppressWarnings(
        tableColsOriginal <- mm.listTableCols(path,table = table, type = type)
      ))


    #Set up to append header
    #If pulling from the middle of a chunk - need to get column headings and
    #change header to FALSE, else it will make
    appendHeader = FALSE
    if(row_min >1 & header == TRUE){
      header = FALSE
      appendHeader = TRUE
      #and grab table Cols to reinsert after
      appendHeader_names <- tableColsOriginal
    }


    #convert Character to
    if(is.character(columns)){

      columns <- columns[columns %in% tableColsOriginal]
      colNumeric <- vector(length = length(columns))

      for(i in 1:length(columns)){
        colNumeric[i] <- which(tableColsOriginal==columns[i])
      }

      columns = colNumeric
    }



    #If Numeric column list provided, get column min and max
    if(is.numeric(columns)){
      col_min <- min(columns)
      col_max <- max(columns)

      #Since pulling c(min:max), keep  vector of those cols to keep afterwards
      columns <- columns[columns <= length(tableColsOriginal)]
      keepIndex_cols <- columns - col_min + 1


      if(appendHeader){
        appendHeader_names <- tableColsOriginal[columns]
      }
    }



    ul = c(row_min,col_min)
    lr = c(row_max,col_max)
    xl_range = cellranger::cell_limits(ul = ul,lr = lr)

    sprintf("Connecting to '%s' sheet in the excel file.",xl_sheet)

    #IF col_type is supplied, check to see that it is correct
    suppressWarnings(
      try(
        toReturn <- readxl::read_excel(path = path,
                                       sheet = xl_sheet,
                                       range = xl_range,
                                       col_names = header,
                                       col_type = col_type,
                                       guess_max = col_type_n_guess)

      )
    )

    if(class(.Last.value)[1] == "try-error"){
      stop("Can't establish that this file is a .xls or .xlsx file")
    }


    if(!is.null(keepIndex_cols)){
      toReturn <- toReturn[,keepIndex_cols]
    }

    if(!is.null(keepIndex_rows)){
      toReturn <- toReturn[keepIndex_rows,]
    }

    if(appendHeader){
      names(toReturn) <- appendHeader_names
    }



  #---------------------------------------------------------------------------#
  #IF type is csv or gz etc.
  #---------------------------------------------------------------------------#
  }


  #---------------------------------------------------------------------------#
  #IF type is csv or compressed csv
  #---------------------------------------------------------------------------#
  if(type %in% c("csv","c_csv")){

    

    filetype <- mm.getFileExt(path)
    
    if(filetype == "gz"){
      path1 <- paste0("gunzip -c ",path)
    } else if(filetype == "zip"){
      path1 <- paste0("unzip -c ",path)
    } else if(filetype == "bz2"){
      path1 <- paste0("bunzip2 -c ",path)
    } else {
      path1 <- path
    }




    #path <- "./../zz_test_data/virScan_Data/CSVs/counts.csv"
    #columns = c("id","input","L2.A303","L2.A302", "hello")
    #specicRows <- NULL
    #specificRows <- c(3,5:10,15,12)
    #header = TRUE
    row_min = 1
    row_max = Inf

    keepIndex_rows = NULL
    keepIndex_cols = NULL

    if(allRows == TRUE){
      row_max = Inf
    }

    if(!is.null(nrows)){
      row_max = nrows
    }


    if(is.numeric(specificRows)){
      row_min <- min(specificRows)
      row_max <- max(specificRows)-row_min

      keepIndex_rows <- specificRows - row_min + 1
    } else {
      row_min = 1
    }


    if(header == TRUE){
      row_min = row_min + 1
      row_max = row_max + 1
    }


    skip = row_min-1


    #tableColsOriginal = NULL
    #Collect original columns from table
    #if(!is.null(columns) | (row_min >1 & header == TRUE)){
    tableColsOriginal <- NULL

    if((skip>0 & header == TRUE) | !is.null(columns)){
      suppressMessages(
      tableColsOriginal <- mm.listTableCols(path,
                                            table = table,
                                            type = type)
      )
    }


    if(is.null(columns) & !is.null(tableColsOriginal)){
      columns <- tableColsOriginal
    }
    #Set up to append header
    #If pulling from the middle of a chunk - need to get column headings and
    #change header to FALSE, else it will make
    header_userInput <- header
    appendHeader = FALSE
    appendHeader_names <- NULL

    if(skip > 0 & header == TRUE){
      header = FALSE
      appendHeader = TRUE
      appendHeader_names <- tableColsOriginal
    }


    #convert Character to Numeric
    if(is.character(columns)){

      columns <- columns[columns %in% tableColsOriginal]
      colNumeric <- vector(length = length(columns))

      for(i in 1:length(columns)){
        colNumeric[i] <- which(tableColsOriginal==columns[i])
      }

      columns = colNumeric
    }



    #If Numeric column list provided, get column min and max
    if(is.numeric(columns)){

      columns <- columns[columns <= length(tableColsOriginal)]

    }

    if(appendHeader){
      if(is.null(tableColsOriginal)){
        tableColsOriginal <-  mm.listTableCols(path,
                                               table = table,
                                               type = type)
      }
      if(is.null(columns)){
        appendHeader_names <- tableColsOriginal
      } else {
        appendHeader_names <- tableColsOriginal[columns]
      }
    }

    errorWithData.table <- FALSE
    errorWith_read_csv <- FALSE
    errorWith_read.csv <- FALSE



    #IF col_type is supplied, check to see that it is correct
    if(!is.null(col_type)){
      if(length(col_type) != length(columns)){
        stop("col_type vector is specified, but supplied vector is not same length as the number of columns requested. Either set col_type to NULL or ensure that the vector length fits the requested data")
      }
    }

    #--------------------------------------------------------------------------#
    #TRY data.table::fread()
    #--------------------------------------------------------------------------#
    #if(FALSE){
    print("trying data.table::fread()")
    try(toReturn <-
          data.frame(data.table::fread(path1,
                                       select =columns,
                                       nrows = row_max,
                                       skip = skip,
                                       header = header,
                                       stringsAsFactors = FALSE,
                                       colClasses = col_type
                                       )),
        silent = TRUE
    )


    #Move on to read_csv if that didn't work
    if(class(.Last.value)[1] == "try-error"){
      errorWithData.table <- TRUE
    }
    if(is.null(toReturn)) { errorWithData.table <- TRUE }

    #errorWithData.table <- TRUE
    #}


    #--------------------------------------------------------------------------#
    #TRY readr::read_csv
    #--------------------------------------------------------------------------#
    if(errorWithData.table){
      print("reading with fread failed. Perhaps special characters in the path")
      print("trying readr::read_csv")


      if(!is.null(appendHeader)){
        column_names <- appendHeader_names
      }

      if(skip > 0){
        suppressMessages(
        column_names <-
          names(readr::read_csv(path,
                                col_names = FALSE,
                                skip = 1,
                                n_max = 0))[columns]
        )
      }

      # create named list of column type specifications ("collectors" in readr-speak)
      cols_to_get <- rep(list(readr::col_guess()), length(column_names))
      names(cols_to_get) <- column_names

      # use do.call() to provide my named list to readr's cols_only() function



      try(toReturn <-
            data.frame(readr::read_csv(path,
                            col_names = header,
                            col_types = do.call(readr::cols_only, cols_to_get),
                            guess_max = col_type_n_guess,
                            skip = skip,
                            n_max = row_max)),
          silent = TRUE
        )

      if(class(.Last.value)[1] == "try-error"){
        errorWith_read_csv <- TRUE
      }

      if(is.null(toReturn)){
        errorWith_read_csv <- TRUE
      }
    } #End error with data.table

    #--------------------------------------------------------------------------#
    #TRY read.csv
    #--------------------------------------------------------------------------#
    if(errorWith_read_csv){
      #stop("NO NO NO read_csv")
      print("readr::read_csv failed, trying base R read.csv")
      try(toReturn <-
            utils::read.csv(path,
                            header = header,
                            stringsAsFactors = FALSE,
                            skip = skip,
                            nrows = row_max,
                            colClasses = col_type),
          silent = TRUE
        )

      if(class(.Last.value)[1] == "try-error"){
        errorWith_read.csv <- TRUE
        print("read.csv failed")
        stop("unable to read csv or compressed csv files")
      } else {

        toReturn <- toReturn[columns,]
        if(skip >0 ) {
          names(toReturn) <- column_names
        }
      }
    }

    #--------------------------------------------------------------------------#
    #Done trying
    #--------------------------------------------------------------------------#


    if(is.numeric(keepIndex_rows)){
      tempNames <- names(toReturn)
      toReturn <- data.frame(toReturn[keepIndex_rows,])
      names(toReturn) <- tempNames
    }

    if(appendHeader){
      names(toReturn) <- appendHeader_names
    }

  }


  #---------------------------------------------------------------------------#
  #IF TABLE TO READ is SQLite
  #---------------------------------------------------------------------------#
  if(type == "SQLite"){

    tableNames <- virScanRSQL::sql.listTables(path)

    if(is.null(table) & (!xl_sheet %in% tableNames)){
      table = tableNames[1]
    } else if(is.null(table) & (xl_sheet %in% tableNames)) {
      table = xl_sheet
    } else {
      table = table
    }

    if(is.integer(table) | is.numeric(table)){
      table = tableNames[table]
    }



    if(is.null(nrows)){
      allRows = TRUE
    } else {
      nrows = nrows
      allRows = FALSE
    }


    if(allRows == TRUE){
      print(sprintf("Setting up to return all rows from SQLite DB: %s",table))
    } else if(allRows == FALSE){
      print(sprintf("Setting up to return %s rows from SQLite DB: %s ",nrows,table))
    }

    if(!is.null(columns)){
      sprintf("Setting up to return requested columns. Input of type %s",typeof(columns))
    } else {
      print("Returning all Columns")
    }

    if(is.numeric(columns)){
      columns = mm.listTableCols(path, table = table, type = "SQLite")[columns]
    }

    specificRowPreserved = NULL
    if(preserveSpecificRowOrder == TRUE & (!is.null(specificRows))){
      specificRowPreserved <- specificRows
      specificRows <- NULL

    }

    if("ids" %in% names(list(...))) {
      ids = list(...)$ids
    } else { ids = NULL}

    toReturn <-
      virScanRSQL::sql.pullTable(path = path,
                                 table = table,
                                 nrows = nrows,
                                 allRows = allRows,
                                 columns = columns,
                                 ids = ids,
                                 rows = specificRows,
                                 return_id_col = TRUE,
                                 returnColsNotAvailable = FALSE,
                                 type = "SQLite")[[1]]

    if(preserveSpecificRowOrder & !is.null(specificRowPreserved)){
      toReturn <- toReturn[specificRowPreserved,]
    }

  }





  print(sprintf("Returning data: nCols: %s, nRows %s.",ncol(toReturn),nrow(toReturn)))

  if(returnAs == "data.frame"){
    toReturn <- data.frame(toReturn)
  } else if(returnAs == "data.table"){
    toReturn <- data.table::data.table(toReturn)
  } else if(returnAs %in% c("tbl_df","tibble","tbl","data_frame")){
    toReturn <- dplyr::as_tibble(toReturn)
  } else {
    toReturn <- data.frame(toReturn)
  }




  if(!is.null(originalColumnsRequested)){
    colsNotFound <-
      originalColumnsRequested[which(!originalColumnsRequested %in%
                                        colnames(toReturn))]

  return(list(table = toReturn,columns_not_available = colsNotFound))

  } else {
    return(toReturn)
  }


}






#' Determine if mm.fastread will be able to read the file. 
#' 
#' Convenience function to help determine if a file is going to be able to be 
#' read in based on the parameters set for mm.fastread
#' Note this is mm.will_fastread1, but we actually run mm.will_fastread which
#' has the quiet option to suppress printing.
#' @param path path to a specific file.
#' @inheritParams mm.fastread
#' @inheritParams mm.quiet 
#' @export
mm.will_fastread <-  function(path,
                              skipExcel_zip = FALSE,
                              allow_gz_bz2_unzip = FALSE,
                              force_gz_bz2_unzip = FALSE,
                              max_size_for_excel_zip = 2000,
                              quiet = TRUE,
                              cores = parallel::detectCores()-1,
                              ...){
  
  if(length(path) == 1){
    return(
       mm.will_fastread1(path = path,
                          skipExcel_zip = skipExcel_zip,
                          allow_gz_bz2_unzip = allow_gz_bz2_unzip,
                          force_gz_bz2_unzip = force_gz_bz2_unzip,
                          max_size_for_excel_zip = max_size_for_excel_zip)
    
    )
  }
  
  
  if(length(path)>1) {
    
    will_fastread_applyFun <- 
      function(X,
               pathVec,
               skipExcel_zip,
               allow_gz_bz2_unzip,
               force_gz_bz2_unzip,
               max_size_for_excel_zip){
        return(
          mm.will_fastread1(path = pathVec[X],
                          skipExcel_zip = skipExcel_zip,
                          allow_gz_bz2_unzip = allow_gz_bz2_unzip,
                          force_gz_bz2_unzip = force_gz_bz2_unzip,
                          max_size_for_excel_zip = max_size_for_excel_zip)
          )
      }
    
    
    
    if(cores ==1 | !requireNamespace("parallel")){
      willReadVecList <-
        lapply(X = 1:length(path),
               FUN = will_fastread_applyFun,
               pathVec = path,
               skipExcel_zip = skipExcel_zip,
               allow_gz_bz2_unzip = allow_gz_bz2_unzip,
               force_gz_bz2_unzip = force_gz_bz2_unzip,
               max_size_for_excel_zip = max_size_for_excel_zip)
    } else {
      willReadVecList <-
        parallel::mclapply(X = 1:length(path),
               FUN = will_fastread_applyFun,
               pathVec = path,
               skipExcel_zip = skipExcel_zip,
               allow_gz_bz2_unzip = allow_gz_bz2_unzip,
               force_gz_bz2_unzip = force_gz_bz2_unzip,
               max_size_for_excel_zip = max_size_for_excel_zip)
    }
    
    willReadVec <- vector()
    for(i in 1:length(willReadVecList)){
      willReadVec[i] <- willReadVecList[[i]]
    }
  
    return(willReadVec)
  }
}








mm.will_fastread1 <- function(path,
                                skipExcel_zip = FALSE,
                                allow_gz_bz2_unzip = FALSE,
                                force_gz_bz2_unzip = FALSE,
                                max_size_for_excel_zip = NULL,
                                ...){
  #Open connectino to file at 'path'
  if(!file.exists(path)){
    print("File to read does not exist")
    return(FALSE)
  }
   type = mm.fileType(path)
  if(type == "directory"){
    stop("Path must be the path to a file, not a directory.")
  }
  
  #---------------------------------------------------------------------------#
  #IF type is xls or xlsx
  #---------------------------------------------------------------------------#
  if(type %in% c("excel","c_excel")){
    
    if(type == "c_excel" & skipExcel_zip){
      print("compressed excel file will not be read in: skipExcel_zip is set to TRUE set to FALSE to try.")
      return(FALSE)
    }
    
    
    if(type == "c_excel" & !skipExcel_zip){
      
      if(force_gz_bz2_unzip == TRUE) allow_gz_bz2_unzip = TRUE
      
      ext <- mm.getFileExt(path)
      if(!ext %in% c("zip","gz","bz2")){
        print(sprintf("Won't be able to open compressed xls/xlsx when compressed with %s . Please decompress XLS/XLSX or zip them using gz or reguar zip. ",path,ext))
        return(FALSE)
      } else if(ext %in% c("gz","bz2") & allow_gz_bz2_unzip == FALSE){
        print(sprintf("Skipped: %s. xls/xlsx file compressed with 'gz/bz2' but 'allow_gz_bz2_unzip' = FALSE. Please either: set to TRUE, which will TEMPORARILY REPLACE the compressed file with the uncompressed file, or decompress the XLS/XLSX manually or if not wanting to uncompress with bz2/gunzip (see parameter explanation), rezip them using reguar .zip - which will unzip and make a temporary copy - safer than gunzip",path))
        return(FALSE)
      } else {
        
        #if it's a xls.zip or xlsx.zip or gz or bz2
        
        continueOn = TRUE
        if(!is.null(max_size_for_excel_zip) & is.numeric(max_size_for_excel_zip)){
          if(base::file.size(path) <= max_size_for_excel_zip * 1e6){
            continueOn = TRUE
          } else {
            print(sprintf("Skipped %s... file.size (Mb) > max_size_for_excel_zip. Can increase max_size_for_excel_zip if desired.",path))
            return(FALSE)
          }
        }
        
        if(continueOn & ext %in% c("zip","gz","bz2")){
          return(TRUE)
        }
      }
    }
    return(TRUE)
  }
  
  #---------------------------------------------------------------------------#
  #IF type is csv or compressed csv
  #---------------------------------------------------------------------------#
  if(type %in% c("csv","c_csv")){
    
    filetype <- mm.getFileExt(path)
    if(filetype == "csv"){
      return(TRUE)
    } else if(filetype %in% c("gz", "zip", "bz2")){
      return(TRUE)
    } else {
      print("Cannot determine type of CSV compression.")
      return(FALSE)
    }
  }
  #---------------------------------------------------------------------------#
  #IF TABLE TO READ is SQLite
  #---------------------------------------------------------------------------#
  if(type == "SQLite"){
    return(TRUE)
  } else {
    print("Cannot determine file type")
    return(FALSE)
  }
}





#mm.willFastreadRead("./25_plato-56-mer.Rproj")
