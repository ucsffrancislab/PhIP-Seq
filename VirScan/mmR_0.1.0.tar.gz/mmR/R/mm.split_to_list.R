#' Split a data frame into a list by one or more grouping variables
#'
#' @export
mm.split_to_list <- function(x, by){
  
  initClass <- class(x)[1]
  if(initClass == "list"){
    stop("Do not know how to split. mm.split_to_list requires a data frame type object.")
  }
  
  if(initClass != "data.frame") data.table::setDF(x)
  
  if(length(by) ==1 ){
    toReturn <-
      split(x = x,f = as.factor( data.frame(x[,by])[,1]))
      #split(x = x,f = as.factor(x[,groupingVar]))
  }

  if(length(by) >1){

      colIndexToGroup <- which(names(x) %in% by)
      tempList <- list()
      for(i in 1:length(colIndexToGroup)){
        tempList[[i]] <- as.factor( data.frame(x[,colIndexToGroup[i]])[,1])
        #tempList[[i]] <- as.character(x[,colIndexToGroup[i]])
      }

      toReturn <- split(x = x, tempList, drop = TRUE)
  }
  
  if(initClass != "data.frame"){
    if(class(toReturn) == "list"){
      for(i in 1:length(toReturn)){
        if(initClass == "data.table"){
          try(data.table::setDT(toReturn[[i]]),silent = TRUE)
        } else {
          try(toReturn[[i]] <- dplyr::as_tibble(toReturn[[i]]),silent = TRUE)
        }
      }
    } else {
      if(initClass == "data.table"){
        try(data.table::setDT(toReturn),silent = TRUE)
      } else {
        try(toReturn <- dplyr::as_tibble(toReturn),silent = TRUE)
      }
    }
  }
  return(toReturn)


}


