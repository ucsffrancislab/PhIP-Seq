#------------------------------------------------------------------------------#
#mm.fastwrite
#------------------------------------------------------------------------------#
#'
#'
#' This function uses \code{data.table::fwrite()} or \code{readr::write_csv} to
#' write a csv file.
#'
#' @family database connections
#' @param data The data.frame to write to csv.
#' @param path The full path to the output file, ending with the filename.csv
#' @param overwrite Should it overwrite a preexisting file with the same name
#' @param compress Should the file be compressed to a gz file (TRUE) or not (FALSE, DEFAULT)
#' @param keep_uncompressed If writing gz, should the csv also be kept? (DEFAULT = FALSE)
#' @param logical01 Should logical vectors be returned as 0,1 (TRUE, defautlt) or FALSE,TRUE (FALSE)
#' @param buffMB MB memory for buffering. Default is 8MB.
#' @param nThread number of threads to use. Default is 8.
#' @return outputs the csv and/or csv.gz file
#'
#' @examples
#' \dontrun{
#'
#' mm.fastwrite(
#' data = data.frame(x = 1:10000000,y=1),
#' file = "~/Desktop/myTest.csv", overwrite = TRUE, compress = TRUE, keep_csv = FALSE)
#'
#' mm.fastwrite(
#' data = data.frame(x = 1:10000000,y=1),
#' file = "~/Desktop/myTest.csv", overwrite = TRUE, compress = TRUE, keep_csv = FALSE)
#' }
#' @export

mm.fastwrite <- function(data,
                         path,
                         overwrite = FALSE,
                         compress = FALSE,
                         keep_uncompressed = FALSE,
                         logical01 = TRUE,
                         buffMB=8,
                         nThread=8,
                         show_progress = TRUE,
                         ...){
  #data = data.frame(X=1:10,Y=1:10, Z = 1:10)

  data = data.table::setDT(data)
  exists.compression <- FALSE

  if(mm.isCompressed(path)){
    exists.compression <- file.exists(path)
    compress = TRUE
    compressionType <- mm.getFileExt(path)
    path <- mm.stringRightRemove(path,rmExt = TRUE)
  }

  type <- mm.fileType(path, requireFile = FALSE)

  exists.original <- file.exists(path)

  compressionType = "gz"

  if(exists.original == TRUE | exists.compression == TRUE){
    exists = TRUE
  } else {
    exists = FALSE
  }

  if(exists == TRUE & overwrite == FALSE){

    "STOP! FILE (either the file or a compressed version of it) ALREADY EXISTS and overwrite = FALSE. Set overwrite = TRUE to overwrite"

  } else { #WRITE FILES HERE

    if(type != "excel"){
      ext <- mm.getFileExt(path)
      if(ext != "csv") path <- paste0(path,".csv")
      if(ncol(data) >1){
        data.table::fwrite(x = data,
                           file = path,
                           showProgress = show_progress,
                           logical01 = logical01,
                           buffMB = buffMB,
                           nThread = nThread)
      } else if(ncol(data) == 1){
        readr::write_csv(x = data, path = path)
      }

    } else if(type == "excel"){
      
      

      if(requireNamespace("writexl",quietly = TRUE)==TRUE){
        writexl::write_xlsx(x = data,
                            path = path,
                            col_names = TRUE)
      } else {
        stop("Cannot write xlsx file. Requires package 'writexl'. Please install writexl or change the path to .csv")
      }
    } else {
      stop("Unable to write file. ")
    }

    if(compress == TRUE){
      R.utils::gzip(path,
                    destname = sprintf("%s.%s", path,compressionType),
                    overwrite = overwrite,
                    remove = !keep_uncompressed)

      print(sprintf("Zipped File: %s.%s", path,compressionType))
    }
  } #Stop writing here
}