#-------------------------------------------------------------------------------
#mm.findSamplesIndb
#-------------------------------------------------------------------------------
#' Function to look for sample names in a SQLite,xls,xlsx,csv,gz db
#'
#' Searches across all the tables in a database for a given vector of column
#' names. This is the base function used in mm.findData()
#' @param path Path to the database
#'
#' @param tablesToLookIn The tables of the DB to search in. If NULL, will search all of them.
#'
#' @param allTables if TRUE (Default) will search all the tables in the DB
#'
#' @param colsToFind A vector of the columns to look for.
#' @param cores = if set to >1, will run in parallel using mclapply
#'
#' @importFrom magrittr %>%
#' @export
#'

mm.findSamplesInDB <- function(path = NULL,
                               tablesToLookIn = NULL,

                               allTables = TRUE,
                               colsToFind = NULL,
                               directoryForTempDir = NULL,
                               skipExcel_zip = FALSE,
                               allow_gz_bz2_unzip = FALSE,
                               force_gz_bz2_unzip = FALSE,
                               max_size_for_excel_zip = NULL,
                               cores = parallel::detectCores()-1,
                               ...){


  if(is.null(tablesToLookIn)){
    tablesToLookIn <- 
      mm.listTables(path, 
                    directoryForTempDir = directoryForTempDir,
                    skipExcel_zip = skipExcel_zip,
                    allow_gz_bz2_unzip = allow_gz_bz2_unzip,
                    force_gz_bz2_unzip = force_gz_bz2_unzip,
                    max_size_for_excel_zip = max_size_for_excel_zip,
                    full.names = FALSE)
  }

  if(mm.fileType(path) %in% c("csv","c_csv")){
    tablesToLookIn = path
  }


  #Interna function to run apply or mclapply to list tables in multiple files in
  #parallel when cores set to >1
  ##----------------------------------------
  listTableParallelFxn <- function(X, 
                           path,
                           tablesToLookIn, 
                           directoryForTempDir = NULL,
                           skipExcel_zip = FALSE,
                           allow_gz_bz2_unzip = FALSE,
                           force_gz_bz2_unzip = FALSE,
                           max_size_for_excel_zip = NULL,
                           colsToFind){
    
    columnNames <- mm.listTableCols(path = path, 
                                    table = tablesToLookIn[X],
                                    skipExcel_zip = skipExcel_zip,
                                    allow_gz_bz2_unzip = allow_gz_bz2_unzip,
                                    force_gz_bz2_unzip = force_gz_bz2_unzip,
                                    directoryForTempDir = directoryForTempDir,
                                    max_size_for_excel_zip = max_size_for_excel_zip)
    
    if(is.null(colsToFind)) {colsToFind = columnNames}
    
    tempDF <- data.frame(colName = colsToFind)
    existsIndex <- which(colsToFind %in% columnNames)
    tempDF$DB = 0
    tempDF[existsIndex,"DB"] = tablesToLookIn[X]
    tempDF <- tempDF[existsIndex,]
    return(tempDF)
  }
  
  
  if(is.null(cores) | !is.numeric(cores)  | cores < 2){
    cores = 1
  } 
  
  if(cores ==1) {
    tempList <- lapply(X = seq_along(tablesToLookIn), 
                       FUN = listTableParallelFxn, 
                       path = path, 
                       tablesToLookIn = tablesToLookIn, 
                       directoryForTempDir = directoryForTempDir,
                       colsToFind = colsToFind,
                       skipExcel_zip = skipExcel_zip,
                       allow_gz_bz2_unzip = allow_gz_bz2_unzip,
                       force_gz_bz2_unzip = force_gz_bz2_unzip,
                       max_size_for_excel_zip = max_size_for_excel_zip)
  } else {
    tempList <- 
      parallel::mclapply(X = seq_along(tablesToLookIn), 
                         FUN = listTableParallelFxn, 
                         path = path, 
                         tablesToLookIn = tablesToLookIn, 
                         directoryForTempDir = directoryForTempDir,
                         colsToFind = colsToFind, 
                         skipExcel_zip = skipExcel_zip,
                         allow_gz_bz2_unzip = allow_gz_bz2_unzip,
                         force_gz_bz2_unzip = force_gz_bz2_unzip,
                         max_size_for_excel_zip = max_size_for_excel_zip,
                         mc.cores = cores)  
  }
  
  ##----------------------------------------
  
  
  
  # tempList <- list()
  # x=1
  # for(x in seq_along(tablesToLookIn)){
  # 
  #   columnNames <- mm.listTableCols(path = path, table = tablesToLookIn[x])
  # 
  #   if(is.null(colsToFind)) {colsToFind = columnNames}
  # 
  #   tempDF <- data.frame(colName = colsToFind)
  #   existsIndex <- which(colsToFind %in% columnNames)
  #   tempDF$DB = 0
  #   tempDF[existsIndex,"DB"] = tablesToLookIn[x]
  #   tempList[[x]] <- tempDF
  # }
  
  existsDF <-
    data.table::rbindlist(tempList) %>%
    dplyr::mutate(count = 1) %>%
    dplyr::group_by(colName) %>%
    dplyr::mutate(ones = count) %>%
    dplyr::mutate(count = sum(ones)) %>%
    dplyr::mutate(countcum = cumsum(ones)) %>%
    dplyr::arrange(colName,dplyr::desc(count)) %>%
    dplyr::select(-ones) %>%
    dplyr::ungroup()

  foundDF <-
    existsDF %>%
    #dplyr::filter(count >0) %>%
    dplyr::select(colName, table = DB, count,countcum) %>%
    dplyr::filter(table != 0) %>%
    unique() %>%
    dplyr::mutate(colName = as.character(colName))

  notFound <- colsToFind[which(!colsToFind %in% foundDF$colName)]
  notFoundDF <- (data.frame(colName = notFound) %>%
    dplyr::mutate(colName = as.character(colName)))$colName

  return(list(found = foundDF, notFound = notFoundDF))
}

#EXAMPLE
# if(FALSE){
#   fullNameToFind <- data2$pValsNotAvailable
#   path = path
#   tablesToLookIn <-
#     c("pValInputLibCombined",
#       "pValInputLibCombined_4_fold_reduction")
#
#
#   sampsLocation <- vs.findSamplesInSQL(path = path,
#                                        fullNameToFind = data2$pValsNotAvailable,
#                                        tablesToLookIn = tablesToLookIn)
# }
