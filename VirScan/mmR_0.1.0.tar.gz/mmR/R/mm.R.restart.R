#' Function to restart R, retains all ls()
#'
#' @export
mm.R.restart <- function(){.rs.restartR()}
