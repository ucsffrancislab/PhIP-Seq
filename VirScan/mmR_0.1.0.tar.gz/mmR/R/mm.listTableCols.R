#' Returns column names of a table or file
#'
#' Can accept a path to SQLite, xlsx, xls, csv of gz files
#'
#' @param path Path to the database or, if a csv of csv.gz, the file
#'
#' @param table Name of the table inside the database to look at. If an Excel
#'   sheet, this can be the number of the excel sheet inside the workbook, or
#'   the name. If a SQLite, must be the name of the table
#' @param xl_sheet Can be the name or the number of the excel sheet if path leads to an excel workbook.
#'
#' @param type Type of database to be found at path. Not necessary to input,
#'    but should be one of "SQLite","csv","gz","xlsx","xls" (if .gz, should be a
#'    csv that is compressed.)
#'
#' @param header Should the header be the first row for an excel or csv file.
#'   DEFAULT is TRUE.
#' @inheritParams mm.fastread
#'
#' @export
mm.listTableCols <- function(path,
                             table = NULL,
                             xl_sheet = 1,
                             header = TRUE,
                             type = NULL,
                             skipExcel_zip = FALSE,
                             allow_gz_bz2_unzip = FALSE,
                             force_gz_bz2_unzip = FALSE,
                             directoryForTempDir = NULL,
                             max_size_for_excel_zip = NULL,
                             ...){


  if(file_test(op = "-d",x = path)){
    
    #check to see if table was actually a path to the table within a directory.
    #if so, then the directory given to path should be the same as directory name
    #of the table path... if they are the same, then make path == table, else
    #combine them
    if(normalizePath(path) == base::dirname(normalizePath(table))){
      path = table
    } else {
      path <- file.path(path,table)  
    }
    
    
    mm.lastModified(base::dirname(table))
    
    pathWasDirectory = TRUE
  } else {pathWasDirectory = FALSE}

  #Check if file exists
  if(!file.exists(path)){
    stop("File to read does not exist")
  }

  
  if(
    mm.will_fastread(path = path, 
                     skipExcel_zip = skipExcel_zip, 
                     allow_gz_bz2_unzip = allow_gz_bz2_unzip,
                     force_gz_bz2_unzip = force_gz_bz2_unzip,
                     max_size_for_excel_zip = max_size_for_excel_zip,
                     cores = cores) == FALSE
  ){
    stop("file will not be read with current parameters")
  } 
  
  
  if(is.null(type)){
    type = mm.fileType(path)
  } else {
    type <- mm.convertUserInput_type.int(type)
  }

  #---------------------------------------------------------------------------#
  #IF type is c_xls or c_xlsx... can open a zip file... but only Zip
  #---------------------------------------------------------------------------#
  if(type == "c_excel" & !skipExcel_zip){


    ext <- mm.getFileExt(path)
    
    #make a temporary directory
    pathPath <- base::dirname(path)

    if(!is.null(directoryForTempDir)){
      if(base::dir.exists(directoryForTempDir)){
        pathPath <- directoryForTempDir
      }
    }

    fileName <- base::basename(path)
    randNamePath <- 
      file.path(
        pathPath,
        paste0("tempZipXL_",
               LETTERS[runif(n = 1,min = 1, max = 20)],
               round(runif(n = 1,min = 1e6, max = 9e6),digits = 0)))
      
    if(dir.exists(randNamePath) == FALSE){
      dir.create(randNamePath)
      on.exit(unlink(randNamePath, recursive = TRUE))
    }

    destName <- file.path(randNamePath,mm.stringRightRemove(fileName,rmExt = TRUE))
    
    if(ext == "zip"){
      utils::unzip(zipfile = path,exdir = randNamePath)  
    } else if(ext == "gz"){
      R.utils::gunzip(filename = path,ext = "gz", remove = FALSE, destname = destName)
    } else if(ext == "bz2"){
      R.utils::bunzip2(path,ext = "bz2",remove = FALSE, destname = destName)
    }
    
    pathOriginal <- path
    path <- destName
    type = mm.fileType(path)
        
      
  }
  

  #---------------------------------------------------------------------------#
  #IF type is xls or xlsx
  #---------------------------------------------------------------------------#
  if(type == "excel"){

    if(pathWasDirectory){
      table = xl_sheet
    }

    if(!is.null(table)){
      if(is.null(xl_sheet) & is.null(table)){
        xl_sheet = 1
        table = 1
      }
      if(is.null(xl_sheet)){
        xl_sheet = table
      } else if(xl_sheet ==1){
        xl_sheet = table
      }
    }


    return(
      suppressMessages(
          names(readxl::read_excel(path = path,
                                   sheet = xl_sheet,
                                   col_names = TRUE,
                                   n_max = 0))))

    if(class(.Last.value)[1] == "try-error"){
      stop("Can't establish that this file is a .xls or .xlsx file")
    }
  }


  #---------------------------------------------------------------------------#
  #IF type is csv or gz
  #---------------------------------------------------------------------------#
  if(type %in% c("csv","c_csv")){
    
    filetype <- mm.getFileExt(path)
    
    if(filetype == "gz"){
      path1 <- paste0("gunzip -c ",path)
    } else if(filetype == "zip"){
      path1 <- paste0("unzip -c ",path)
    } else if(filetype == "bz2"){
      path1 <- paste0("bunzip2 -c ",path)
    } else {
      path1 <- path
    }
    
    if(path1 == path){
      try(
        return(
          names(
            data.table::fread(
              path1,
              nrows = 0,
              header = header,
              stringsAsFactors = FALSE
            ))),
        silent = TRUE
      )  
    }
    
    #if its a system command... using cmd = ....
    if(path != path1)
    try(
      return(
        names(
          data.table::fread(
            cmd = path1,
            nrows = 0,
            header = header,
            stringsAsFactors = FALSE
          ))),
        silent = TRUE
    )
    
  
    suppressMessages(
    return(names(readr::read_csv(file = path,
                                col_names = header,
                                n_max = 0))))
      print("returned from read_csv")
  }


#---------------------------------------------------------------------------#
#IF TABLE TO READ is SQLite
#---------------------------------------------------------------------------#
  if(type == "SQLite"){

    if(pathWasDirectory){
      table = xl_sheet
    }


  if(is.null(table)){
    if(is.null(xl_sheet)){
      stop("DB is SQLite... Please provide table name")
    } else {
      table = xl_sheet
    }
  }

  if(!table %in% virScanRSQL::sql.listTables(path)){
    stop(
      sprintf("Table %s not found from which to read column names",
              table))
  }

    return(virScanRSQL::sql.listTableCols(path, table))

  }

}




#mm.listTableCols(path = "./../../00_labAndSampKeys/1_virScanData/sampleData/", table = "allSamplesMeta.v3.xlsx")





# Returns column names of a table or file
#
# Can accept a path to SQLite, xlsx, xls, csv of gz files
#
# @param path Path to the database or, if a csv of csv.gz, the file
#
# @param table Name of the table inside the database to look at. If an Excel
#   sheet, this can be the number of the excel sheet inside the workbook, or
#   the name. If a SQLite, must be the name of the table
# @param xl_sheet Can be the name or the number of the excel sheet if path leads to an excel workbook.
#
# @param type Type of database to be found at path. Not necessary to input,
#    but should be one of "SQLite","csv","gz","xlsx","xls" (if .gz, should be a
#    csv that is compressed.)
#
# @param header Should the header be the first row for an excel or csv file.
#   DEFAULT is TRUE.
#
# @return Returns a vector of column names
# zz_archive_mm.listTableCols <- function(path,
#                                         table = NULL,
#                                         xl_sheet = 1,
#                                         header = TRUE,
#                                         type = NULL){
#
#
#   #Check if file exists
#   if(!file.exists(path)){
#     stop("File to read does not exist")
#   }
#
#   if(is.null(type)){
#     type = mm.fileType(path)
#   } else {
#     type <- mm.convertUserInput_type.int(type)
#   }
#
#   #---------------------------------------------------------------------------#
#   #IF type is xls or xlsx
#   #---------------------------------------------------------------------------#
#   if(type == "excel"){
#
#     if(!is.null(table)){
#       if(is.null(xl_sheet)){
#         xl_sheet = table
#       } else if(xl_sheet ==1){
#         xl_sheet = table
#       }
#     }
#
#
#     try(toReturn <-
#           names(readxl::read_excel(path = path,
#                                    sheet = xl_sheet,
#                                    col_names = TRUE,
#                                    n_max = 0)))
#
#     if(class(.Last.value)[1] == "try-error"){
#       stop("Can't establish that this file is a .xls or .xlsx file")
#     }
#
#
#     #---------------------------------------------------------------------------#
#     #IF type is csv or gz
#     #---------------------------------------------------------------------------#
#   } else if(type %in% c("csv","c_csv")){
#
#
#     data.tableFailed <- TRUE
#     read_csvFailed <- FALSE
#     read.csvFailed <- TRUE
#
#
#     try(toReturn <- data.frame(data.table::fread(path,nrows = 0)))
#
#
#     if(class(.Last.value)[1] == "try-error"){
#       data.tableFailed <- TRUE
#     }
#
#     if(data.tableFailed==TRUE){
#       # suppressWarnings(
#       #  suppressMessages(
#       try(toReturn <-
#             names(readr::read_csv(file = path, col_names = header, n_max = 0)))
#       #))
#
#       if(class(.Last.value)[1] == "try-error"){
#         read_csvFailed <- TRUE
#       }
#
#     }
#
#
#
#     if(read_csvFailed == TRUE){
#       print("WARNING: Could not read in with data.table or readr.")
#       print("Attempting to read in with read.csv(), which may be very slow.")
#
#       try(
#         toReturn <-
#           names(read.csv(file = path,
#                          header = header,
#                          nrows = 0)))
#
#       if(class(.Last.value)[1] == "try-error"){
#         read.csvFailed <- TRUE
#       }
#     }
#
#
#     if(read.csvFailed == TRUE){
#       stop("Error reading file.")
#     }
#
#
#
#     #---------------------------------------------------------------------------#
#     #IF TABLE TO READ is SQLite
#     #---------------------------------------------------------------------------#
#   } else if(type == "SQLite"){
#
#     if(is.null(table)){
#       if(is.null(xl_sheet)){
#         stop("DB is SQLite... Please provide table name")
#       } else {
#         table = xl_sheet
#       }
#     }
#
#     if(!table %in% virScanRSQL::sql.listTables(path)){
#       stop(
#         sprintf("Table %s not found from which to read column names",
#                 table))
#     }
#
#     toReturn <- virScanRSQL::sql.listTableCols(path, table)
#
#   }
#
#   return(toReturn)
#
# }
#
#
#
#
#
#
#
#
#
#
#
